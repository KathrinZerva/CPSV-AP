/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.common;

/**
 *
 * @author Administrator
 */
public class PagerResults {

    int totalItems;            // Συνολικό πλήθος στοιχείων
    int itemsStart;             // Έναρξη στοιχείων για ανάκτηση
    int itemsFinish;            // Τέλος στοιχείων για ανάκτηση
    int currentPage = 1;        // Τρέχουσα σελίδα
    int pageItems=10;              // Πλήθος στοιχείων ανά σελίδα
    int pages;                  // Συνολικό πλήθος σελίδων με βάση το Συνολικό πλήθος στοιχείων
    int pagerStart;            // Αριθμός αρχικής σελίδας που εμφανίζεται
    int pagerFinish;            // Αριθμός τελικής σελίδας που εμφανίζεται
    int pagesDisplay = 5;       // Πλήθος σελίδων που θα εμφανίζονται στον pager
    


    public PagerResults() {
        this(Constants.PAGER_PAGE_ITEMS.intValue());
    }

    public PagerResults(int pageItems) {
        this.pageItems = pageItems;
        computeItemsRange();
    }    

    public PagerResults(int currentPage, int pagesAvailable) {
        this(currentPage, Constants.PAGER_PAGE_ITEMS.intValue(), pagesAvailable);
    }    
    
    public PagerResults(int currentPage, int pageItems, int pages) {
        this.currentPage = currentPage;
        this.pageItems = pageItems;
        this.pages = pages;
        computePages();
        computeItemsRange();
    }

    

    public int getPageItems() {
        return pageItems;
    }

    public void setPageItems(int pageItems) {   
        this.pageItems = pageItems;
        computePages();
   //     computeCurrentPage();
        computeItemsRange();
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
        if(this.currentPage <= 0){
            this.currentPage = 1;
        }

        computeItemsRange();
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }



    public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
        computePages();
        computeItemsRange();
    }

    public int getPagerFinish() {
        return pagerFinish;
    }

    public void setPagerFinish(int pagerFinish) {
        this.pagerFinish = pagerFinish;
    }

    public int getPagerStart() {
        return pagerStart;
    }

    public void setPagerStart(int pagerStart) {
        this.pagerStart = pagerStart;
    }

    public int getItemsFinish() {
        return itemsFinish;
    }

    public void setItemsFinish(int itemsFinish) {
        this.itemsFinish = itemsFinish;
    }

    public int getItemsStart() {
        return itemsStart;
    }

    public void setItemsStart(int itemsStart) {
        this.itemsStart = itemsStart;
    }

    public int getPagesDisplay() {
        return pagesDisplay;
    }

    public void setPagesDisplay(int pagesDisplay) {
        this.pagesDisplay = pagesDisplay;
    }

 
    /*
     * Υπολογισμός Σελίδων βάση πλήθος items και items νά σελίδα
     */
    private void computePages() {
        if(pageItems == 0){
            pages = 1;
        } else {
            pages = totalItems / pageItems;
            pages = pages + (((totalItems % pageItems)>0)?1:0);
        }
        if(currentPage < 1) {
            currentPage = 1;
        }


        pagerStart = currentPage - pagesDisplay/2 ;
        if(pagerStart < 1) {
            pagerStart = 1;
        }
        pagerFinish = pagerStart + pagesDisplay -1;
        if(pagerFinish > pages) {
            pagerFinish = pages;
            pagerStart = pagerFinish - pagesDisplay +1;
            if (pagerStart < 1) {
                pagerStart = 1;
            }
        }
    }
    
    
    /*
     * Υπολογίζει τα όρια για τα οποία θα γίνει αναζήτηση 
     * στη βάση
     * 
     */
    private void computeItemsRange(){

  itemsStart = (currentPage-1) * pageItems;
        if(itemsStart < 0) {
            itemsStart = 0;
        }
        itemsFinish = (currentPage) * pageItems; 
        if(itemsFinish > totalItems){
            itemsFinish = totalItems;
        }
    }

    @Override
    public String toString() {
        return "PagerResults{" + "totalItems=" + totalItems + ", itemsStart=" + itemsStart + ", itemsFinish=" + itemsFinish + ", currentPage=" + currentPage + ", pageItems=" + pageItems + ", pages=" + pages + ", pagerStart=" + pagerStart + ", pagerFinish=" + pagerFinish + ", pagesDisplay=" + pagesDisplay + '}';
    }
    
    /*
     * Υπολογίζει την τρέχουσα σελίδα όταν αλλάξει το 
     * Πλήθος στοιχείων ανά σελίδα
     * 
     */
    private void computeCurrentPage(){
        if(this.itemsStart == 0){
            this.currentPage = 1;
        } else {
            this.currentPage = this.pageItems / this.itemsStart;
        }
        if(this.currentPage > pages) {
            
            this.currentPage = pages;
           
        }
        this.currentPage = 1;
    }
    
}
