/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gr.eap.cpsvap.common;

/**
 *
 * @author Administrator
 */

public final class Constants {

    public static final Integer PAGER_PAGE_ITEMS = 10;
    public static final String PAGER_OFFSET = "PAGER_OFFSET";
    
    public static final String USER = "USER";
    public static final String USER_LOGIN = "USER_LOGIN";
    
    public static final String CRITERIA = "CRITERIA";   

}
