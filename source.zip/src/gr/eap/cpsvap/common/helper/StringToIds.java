/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.common.helper;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author Jim
 */
public class StringToIds {

    String stringIds;
    List<Integer> ids = new ArrayList<>();

    public StringToIds(String stringIds) {
        this.stringIds = stringIds;
        convertByJson();
    }

    public String getStringIds() {
        return stringIds;
    }

    public void setStringIds(String stringIds) {
        this.stringIds = stringIds;
    }

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }

    private void convertByJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            ids = Arrays.asList(mapper.readValue(stringIds, Integer[].class));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    public static void main(String[] args) {
//        StringToIds a = new StringToIds("");
//        a.convertByJson();
//    }

}
