package gr.eap.cpsvap.entity;


/**
 * Διαχειριστής του Forum
 * 
 * @author Θεοδωρίδης Δημήτρης
 * 
 * 
 */

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "USER")
public class User implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;
    
    @Column(name = "USER_NAME")
    private String userName;    
    
    @Column(name = "NAME")
    private String name;   
    
    @Column(name = "PASSWORD")
    private String password;        
    
 
    public User(){

    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    @Override
    public String toString() {
        return "User{" + "id=" + id + ", userName=" + userName + ", password=" + password + '}';
    }




    
}
