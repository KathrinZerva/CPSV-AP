package gr.eap.cpsvap.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * It represents a collection of people organized together into a community or 
 * other social, commercial or political structure. The group has some common 
 * purpose or reason for existence which goes beyond the set of people belonging 
 * to it. An organization may itself be able to act as an agent.
 * 
 * @author Katerina Zerva
 */
@Entity
@Table(name="ORGANIZATION")
@PrimaryKeyJoinColumn(name = "AGENT_ID")
public class Organization extends Agent {

    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="ALTERNATIVE_NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="ALTERNATIVE_NAME_LANGUAGE") )
    } )
    private Text alternativeName = new Text();
    
    public Organization() {
    }

    public Text getAlternativeName() {
        return alternativeName;
    }

    public void setAlternativeName(Text alternativeName) {
        this.alternativeName = alternativeName;
    }


    
    
    
}
