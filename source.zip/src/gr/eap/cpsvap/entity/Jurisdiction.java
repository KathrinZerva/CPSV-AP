
package gr.eap.cpsvap.entity;

import java.net.URI;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * A jurisdiction, typically a country, dealing with and making pronouncements 
 * on legal matters.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name = "JURISDICTION")
public class Jurisdiction {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
        
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "content", column = @Column(name = "NAME_CONTENT")),
        @AttributeOverride(name = "language", column = @Column(name = "NAME_LANGUAGE"))
    })
    private Text name = new Text();
    
    @Column(name = "IDENTIFIER")
    String identifier;

    public Jurisdiction() {
    }
  
    
    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
}
