
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Criterion requirement response is an assertion that responds to a criterion
 * requirement.
 * Criterion Requirement Response is the class used to define the actual response to a
 * criterion requirement. It provides the value for the specific requirement and the
 * period to which it applies. It refers to the criterion requirement that validates.
 * 
 * @author Katerina Zerva
 */
@Entity
@Table(name="REQUIREMENT_RESPONCE")
public class RequirementResponce {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="identifier", column = @Column(name="IDENTIFIER_IDENTIFIER") ),
        @AttributeOverride(name="type", column = @Column(name="IDENTIFIER_TYPE") ),
        @AttributeOverride(name="issueDate", column = @Column(name="IDENTIFIER_ISSUE_DATE") ),        
        @AttributeOverride(name="issuingAuthority", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY") ),
        @AttributeOverride(name="issuingAuthorityURI", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY_URI") ),        
    } )
    private Identifier identifier = new Identifier();   
    
    @Column(name = "NAME")
    String name;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    private Text description = new Text();  
        
        
    @Column(name = "VALUE")
    String value;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="EVIDENCE_ID")
    private Evidence provenByEvidence = new Evidence();
        
        
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="PERIOD_OF_TIME_ID")
    private PeriodOfTime appliesToPeriodOfTime = new PeriodOfTime();    
    
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="CRITERION_REQUIREMENT_ID")
    private CriterionRequirement validatesCriterionRequirement = new CriterionRequirement();    
    
    
/*    @OneToMany(mappedBy = "providesRequirementResponse",cascade = CascadeType.MERGE,orphanRemoval = true)
    Set<Agent> requirementResponces = new HashSet<>();
*/
    public RequirementResponce() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Evidence getProvenByEvidence() {
        return provenByEvidence;
    }

    public void setProvenByEvidence(Evidence provenByEvidence) {
        this.provenByEvidence = provenByEvidence;
    }

    public CriterionRequirement getValidatesCriterionRequirement() {
        return validatesCriterionRequirement;
    }

    public void setValidatesCriterionRequirement(CriterionRequirement validatesCriterionRequirement) {
        this.validatesCriterionRequirement = validatesCriterionRequirement;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public PeriodOfTime getAppliesToPeriodOfTime() {
        return appliesToPeriodOfTime;
    }

    public void setAppliesToPeriodOfTime(PeriodOfTime appliesToPeriodOfTime) {
        this.appliesToPeriodOfTime = appliesToPeriodOfTime;
    }

/*    public Set<Agent> getRequirementResponces() {
        return requirementResponces;
    }

    public void setRequirementResponces(Set<Agent> requirementResponces) {
        this.requirementResponces = requirementResponces;
    }
    
*/    
    
}
