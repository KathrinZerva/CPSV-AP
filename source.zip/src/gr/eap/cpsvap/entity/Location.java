package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.location.Address;
import gr.eap.cpsvap.entity.location.Geometry;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * An identifiable geographic place.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name = "LOCATION")
public class Location implements Cloneable {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="GEOGRAPHIC_NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="GEOGRAPHIC_NAME_LANGUAGE") )
    } )
    private Text geographicName = new Text();

    @Column(name = "GEOGRAPHIC_IDENTIFIER")
    String geographicIdentifier;
    
            
   @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="fullAddress.content", column = @Column(name="FULL_ADDRESS_CONTENT") ),
        @AttributeOverride(name="fullAddress.language", column = @Column(name="FULL_ADDRESS_LANGUAGE") ),  
        @AttributeOverride(name="poBox.content", column = @Column(name="PO_BOX_CONTENT") ),
        @AttributeOverride(name="poBox.language", column = @Column(name="PO_BOX_LANGUAGE") ), 
        @AttributeOverride(name="thoroughfare.content", column = @Column(name="THOROUGHFARE_CONTENT") ),
        @AttributeOverride(name="thoroughfare.language", column = @Column(name="THOROUGHFARE_LANGUAGE") ),
        @AttributeOverride(name="locatorDesignator.content", column = @Column(name="LOCATOR_DESIGNATOR_CONTENT") ),
        @AttributeOverride(name="locatorDesignator.language", column = @Column(name="LOCATOR_DESIGNATOR_LANGUAGE") ),        
        @AttributeOverride(name="locatorName.content", column = @Column(name="LOCATOR_NAME_CONTENT") ),
        @AttributeOverride(name="locatorName.language", column = @Column(name="LOCATOR_NAME_LANGUAGE") ),        
        @AttributeOverride(name="addressArea.content", column = @Column(name="ADDRESS_AREA_CONTENT") ),
        @AttributeOverride(name="addressArea.language", column = @Column(name="ADDRESS_AREA_LANGUAGE") ),
        @AttributeOverride(name="postName.content", column = @Column(name="POST_NAME_CONTENT") ),
        @AttributeOverride(name="postName.language", column = @Column(name="POST_NAME_LANGUAGE") ),
        @AttributeOverride(name="adminUnitL1.content", column = @Column(name="ADMIN_UNIT_L1_CONTENT") ),
        @AttributeOverride(name="adminUnitL1.language", column = @Column(name="ADMIN_UNIT_L1_LANGUAGE") ),
        @AttributeOverride(name="adminUnitL2.content", column = @Column(name="ADMIN_UNIT_L2_CONTENT") ),
        @AttributeOverride(name="adminUnitL2.language", column = @Column(name="ADMIN_UNIT_L2_LANGUAGE") ),          
        @AttributeOverride(name="postCode", column = @Column(name="ADDRESS_POST_CODE") ),        
        @AttributeOverride(name="addressId", column = @Column(name="ADDRESS_ADDRESS_ID") )        
    } )
    private Address address = new Address(); 

//    @Embedded
//    @AttributeOverrides( {
//        @AttributeOverride(name="coordinates", column = @Column(name="GEOMETRY_COORDINATES")),
//        @AttributeOverride(name="crs", column = @Column(name="GEOMETRY_CRS") ),
//        @AttributeOverride(name="type", column = @Column(name="GEOMETRY_TYPE"))   
//    } )
//    Geometry geometry = new Geometry();
    
   
    public Location() {

    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getGeographicName() {
        return geographicName;
    }

    public void setGeographicName(Text geographicName) {
        this.geographicName = geographicName;
    }

    public String getGeographicIdentifier() {
        return geographicIdentifier;
    }

    public void setGeographicIdentifier(String geographicIdentifier) {
        this.geographicIdentifier = geographicIdentifier;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

//    public Geometry getGeometry() {
//        return geometry;
//    }
//
//    public void setGeometry(Geometry geometry) {
//        this.geometry = geometry;
//    }

 
    
    
}
