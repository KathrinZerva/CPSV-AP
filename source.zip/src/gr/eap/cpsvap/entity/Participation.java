
package gr.eap.cpsvap.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Participation class supports this extra complexity if required, 
 * for instance, the description of a service user or a service provider.
 *
 * @author Katerina Zerva
 */
@Entity
@Table(name = "PARTICIPATION")
public class Participation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;

    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
   
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "content", column = @Column(name = "DESCRIPTION_CONTENT")),
        @AttributeOverride(name = "language", column = @Column(name = "DESCRIPTION_LANGUAGE"))
    })
    private Text description = new Text();
    

    public Participation() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }


    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

   
   
}
