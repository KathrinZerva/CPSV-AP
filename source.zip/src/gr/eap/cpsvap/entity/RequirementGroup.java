
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * Criterion requirement group is the set of requirements that must be fulfilled
  together to validate a criterion.
  A criterion can be satisfied using different options. The Requirement Group class is
  used to wrap the set of criteria requirements that validate a Criterion.  All criteria requirements belonging to a Requirement Group shall be valid for the
  Requirement Group to be considered valid.
  When there is more than one Requirement Group for a Criterion, at least one of
  them has to be positively validated for the criterion to be considered fulfilled.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="REQUIREMENT_GROUP")
public class RequirementGroup {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;    

    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="identifier", column = @Column(name="IDENTIFIER_IDENTIFIER") ),
        @AttributeOverride(name="type", column = @Column(name="IDENTIFIER_TYPE") ),
        @AttributeOverride(name="issueDate", column = @Column(name="IDENTIFIER_ISSUE_DATE") ),        
        @AttributeOverride(name="issuingAuthority", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY") ),
        @AttributeOverride(name="issuingAuthorityURI", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY_URI") ),        
    } )
    private Identifier identifier = new Identifier();     
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    private Text description = new Text(); 
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "CRITERION_REQUIREMENT_GROUP", 
        joinColumns = { @JoinColumn(name = "REQUIREMENT_GROUP_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "CRITERION_REQUIREMENT_ID") }
    )
    @OrderBy(value="name asc")
    Set<CriterionRequirement> hasCriterionRequirement = new HashSet<>();

    public RequirementGroup() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Set<CriterionRequirement> getHasCriterionRequirement() {
        return hasCriterionRequirement;
    }

    public void setHasCriterionRequirement(Set<CriterionRequirement> hasCriterionRequirement) {
        this.hasCriterionRequirement = hasCriterionRequirement;
    }
    

    
}
