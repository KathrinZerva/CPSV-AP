
package gr.eap.cpsvap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Durations begin with an uppercase P followed by the number and the relevant 
 * designator, formally: P[n]Y[n]M[n]DT[n]H[n]M[n]S, where Y is for years, 
 * M for months etc. Note that days and times are separated by an uppercase 
 * T which also disambiguates M as meaning month (P2M means 2 months) 
 * or minute (PT2M means 2 minutes). Durations may also be defined as a number 
 * of weeks so P4W means 4 weeks. A full explanation is provided in the Wikipedia 
 * page16 that references the official ISO standard17. 
 * 
 * 
 * @author Katerina Zerva
 */
@Entity
@Table(name = "DURATION")
public class Duration {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Column(name = "DURATION")
    String duration;    
    

    public Duration() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Duration{" + "id=" + id + ", duration=" + duration + '}';
    }

    
    
}
