
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.helper.Currency;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The Cost class represents any costs related to the execution of a 
 * Public Service that the Agent consuming it needs to pay.
 * 
 * @author Katerina Zerva
 */
@Entity
@Table(name = "COST")
public class Cost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;

    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
    
    @Column(name = "VALUE")
    Float value;
    
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "content", column = @Column(name = "DESCRIPTION_CONTENT")),
        @AttributeOverride(name = "language", column = @Column(name = "DESCRIPTION_LANGUAGE"))
    })
    private Text description = new Text();
    
    // Currency
    @ManyToOne(targetEntity = Currency.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "CURRENCY_ID")
    private Currency currency = new Currency();
    
    // Consept
    @ManyToOne(targetEntity = Consept.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "CONSEPT_ID")
    private Consept type = new Consept();
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "COST_PUBLIC_ORGANIZATION", 
        joinColumns = { @JoinColumn(name = "COST_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "PUBLIC_ORGANIZATION_ID") }
    )
//    @OrderBy(value="name.content asc")
    Set<PublicOrganization> isDefinedBy = new HashSet<>();

    public Cost() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }

    public Float getValue() {
        return value;
    }

    public void setValue(Float value) {
        this.value = value;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Set<PublicOrganization> getIsDefinedBy() {
        return isDefinedBy;
    }

    public void setIsDefinedBy(Set<PublicOrganization> isDefinedBy) {
        this.isDefinedBy = isDefinedBy;
    }

    public Consept getType() {
        return type;
    }

    public void setType(Consept type) {
        this.type = type;
    }

    
}
