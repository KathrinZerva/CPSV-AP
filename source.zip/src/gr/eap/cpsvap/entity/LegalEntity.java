
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Code;
import gr.eap.cpsvap.entity.composite.Identifier;
import gr.eap.cpsvap.entity.location.Address;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 *
 * A business that is legally registered.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="LEGAL_ENTITY")
@PrimaryKeyJoinColumn(name = "AGENT_ID")
public class LegalEntity extends Agent{
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="identifier", column = @Column(name="LEGAL_IDENTIFIER_IDENTIFIER") ),
        @AttributeOverride(name="type", column = @Column(name="LEGAL_IDENTIFIER_TYPE") ),
        @AttributeOverride(name="issueDate", column = @Column(name="LEGAL_IDENTIFIER_ISSUE_DATE") ),        
        @AttributeOverride(name="issuingAuthority", column = @Column(name="LEGAL_IDENTIFIER_ISSUING_AUTHORITY") ),
        @AttributeOverride(name="issuingAuthorityURI", column = @Column(name="LEGAL_IDENTIFIER_ISSUING_AUTHORITY_URI") ),        
    } )
    private Identifier legalIdentifier = new Identifier();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="ALTERNATIVE_NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="ALTERNATIVE_NAME_LANGUAGE") )
    } )
    private Text alternativeName = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="COMPANY_TYPE_CONTENT") ),
        @AttributeOverride(name="list", column = @Column(name="COMPANY_TYPE_LIST") ),
        @AttributeOverride(name="listAgency", column = @Column(name="COMPANY_TYPE_LIST_AGENCY") ),        
        @AttributeOverride(name="listVersion", column = @Column(name="COMPANY_TYPE_LIST_VERSION") )        
    } )
    private Code companyType = new Code();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="COMPANY_STATUS_CONTENT") ),
        @AttributeOverride(name="list", column = @Column(name="COMPANY_STATUS_LIST") ),
        @AttributeOverride(name="listAgency", column = @Column(name="COMPANY_STATUS_LIST_AGENCY") ),        
        @AttributeOverride(name="listVersion", column = @Column(name="COMPANY_STATUS_LIST_VERSION") )        
    } )
    private Code companyStatus = new Code();  
    
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="COMPANY_ACTIVITY_CONTENT") ),
        @AttributeOverride(name="list", column = @Column(name="COMPANY_ACTIVITY_LIST") ),
        @AttributeOverride(name="listAgency", column = @Column(name="COMPANY_ACTIVITY_LIST_AGENCY") ),        
        @AttributeOverride(name="listVersion", column = @Column(name="COMPANY_ACTIVITY_LIST_VERSION") )        
    } )
    private Code companyActivity = new Code();      
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="fullAddress.content", column = @Column(name="FULL_ADDRESS_CONTENT") ),
        @AttributeOverride(name="fullAddress.language", column = @Column(name="FULL_ADDRESS_LANGUAGE") ),  
        @AttributeOverride(name="poBox.content", column = @Column(name="PO_BOX_CONTENT") ),
        @AttributeOverride(name="poBox.language", column = @Column(name="PO_BOX_LANGUAGE") ), 
        @AttributeOverride(name="thoroughfare.content", column = @Column(name="THOROUGHFARE_CONTENT") ),
        @AttributeOverride(name="thoroughfare.language", column = @Column(name="THOROUGHFARE_LANGUAGE") ),
        @AttributeOverride(name="locatorDesignator.content", column = @Column(name="LOCATOR_DESIGNATOR_CONTENT") ),
        @AttributeOverride(name="locatorDesignator.language", column = @Column(name="LOCATOR_DESIGNATOR_LANGUAGE") ),        
        @AttributeOverride(name="locatorName.content", column = @Column(name="LOCATOR_NAME_CONTENT") ),
        @AttributeOverride(name="locatorName.language", column = @Column(name="LOCATOR_NAME_LANGUAGE") ),        
        @AttributeOverride(name="addressArea.content", column = @Column(name="ADDRESS_AREA_CONTENT") ),
        @AttributeOverride(name="addressArea.language", column = @Column(name="ADDRESS_AREA_LANGUAGE") ),
        @AttributeOverride(name="postName.content", column = @Column(name="POST_NAME_CONTENT") ),
        @AttributeOverride(name="postName.language", column = @Column(name="POST_NAME_LANGUAGE") ),
        @AttributeOverride(name="adminUnitL1.content", column = @Column(name="ADMIN_UNIT_L1_CONTENT") ),
        @AttributeOverride(name="adminUnitL1.language", column = @Column(name="ADMIN_UNIT_L1_LANGUAGE") ),
        @AttributeOverride(name="adminUnitL2.content", column = @Column(name="ADMIN_UNIT_L2_CONTENT") ),
        @AttributeOverride(name="adminUnitL2.language", column = @Column(name="ADMIN_UNIT_L2_LANGUAGE") ),          
        @AttributeOverride(name="postCode", column = @Column(name="ADDRESS_POST_CODE") ),        
        @AttributeOverride(name="addressId", column = @Column(name="ADDRESS_ADDRESS_ID") )        
    } )
    private Address registeredAddress = new Address();  
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="LOCATION_ID")
    private Location location = new Location();  
    

    public LegalEntity() {
    }

    public Identifier getLegalIdentifier() {
        return legalIdentifier;
    }

    public void setLegalIdentifier(Identifier legalIdentifier) {
        this.legalIdentifier = legalIdentifier;
    }

    public Text getAlternativeName() {
        return alternativeName;
    }

    public void setAlternativeName(Text alternativeName) {
        this.alternativeName = alternativeName;
    }

    public Code getCompanyType() {
        return companyType;
    }

    public void setCompanyType(Code companyType) {
        this.companyType = companyType;
    }

    public Code getCompanyStatus() {
        return companyStatus;
    }

    public void setCompanyStatus(Code companyStatus) {
        this.companyStatus = companyStatus;
    }

    public Code getCompanyActivity() {
        return companyActivity;
    }

    public void setCompanyActivity(Code companyActivity) {
        this.companyActivity = companyActivity;
    }

    public Address getRegisteredAddress() {
        return registeredAddress;
    }

    public void setRegisteredAddress(Address registeredAddress) {
        this.registeredAddress = registeredAddress;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
    
    
}
