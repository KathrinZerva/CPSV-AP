package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 *This class represents the Public Service itself, as it is described in a public service catalogue. A Public Service is a mandatory or discretionary set of activities performed, or able to be performed, by or on behalf of a public organisation, publicly funded and arise from public policy. Services may be for the benefit of an individual, a business, or other public authority, or groups of any of these. A service exists whether it is used or not, and the term 'benefit' may apply in the sense of enabling the fulfilment of an obligation. As defined in the revised version of the European Interoperability Framework12, a European public service comprises any service provided by public administrations in Europe, or by other organisations on their behalf, to businesses, citizens or others public administrations.
 * @author Katerina Zerva
 */
@Entity
@Table(name = "PUBLIC_SERVICE")
public class PublicService implements Cloneable {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    protected Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    protected Text description = new Text(); 
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="KEYWORD_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="KEYWORD_LANGUAGE") )
    } )
    protected Text keyword = new Text();  
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_THEMATIC_AREA", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "THEMATIC_AREA_ID") }
    )
    @OrderBy(value="description")
    private Set<ThematicArea> thematicAreas = new HashSet<>();    
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_PUBLIC_SERVICE_TYPE", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_TYPE_ID") }
    )
    @OrderBy(value="description")
    private Set<PublicServiceType> types = new HashSet<>();
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_LANGUAGE", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "LANGUAGE_ID") }
    )
    @OrderBy(value="code")
    private Set<NaturalLanguage> languages = new HashSet<>();
       
    @ManyToOne(targetEntity = PublicServiceStatus.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "PUBLIC_SERVICE_STATUS_ID")
    private PublicServiceStatus status = new PublicServiceStatus();  
    
    @ManyToOne(targetEntity = Duration.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "DURATION_ID")
    private Duration processingTime = new Duration();  
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_EVENT", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "EVENT_ID") }
    )
    @OrderBy(value="name.content")
    private Set<Event> isGroupedBy = new HashSet<>();    
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_PARTICIPATION", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "PARTICIPATION_ID") }
    )
    @OrderBy(value="description.content")
    private Set<Participation> hasParticipation = new HashSet<>();   
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_SECTOR", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "SECTOR_ID") }
    )
    @OrderBy(value="code")
    private Set<Sector> sectors = new HashSet<>();
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_EVIDENCE", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "EVIDENCE_ID") }
    )
    @OrderBy(value="name.content")
    private Set<Evidence> hasInput = new HashSet<>();    
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_OUTPUT", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "OUTPUT_ID") }
    )
    @OrderBy(value="name.content")
    private Set<Output> produces = new HashSet<>();     
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_COST", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "COST_ID") }
    )
    @OrderBy(value="description.content")
    private Set<Cost> hasCost = new HashSet<>();         
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_CONTACT_POINT", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "CONTACT_POINT_ID") }
    )
    @OrderBy(value="name")
    private Set<ContactPoint> hasContactPoint = new HashSet<>();       
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_PUBLIC_SERVICE_DATASET", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_DATASET_ID") }
    )
    @OrderBy(value="name.content")
    private Set<PublicServiceDataset> isDescribedAt = new HashSet<>();       
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_LOCATION", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "LOCATION_ID") }
    )
    @OrderBy(value="geographicName.content")
    private Set<Location> spatial = new HashSet<>();      
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_RULE", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "RULE_ID") }
    )
    @OrderBy(value="name.content")
    private Set<Rule> follows = new HashSet<>();   
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_CRITERION_REQUIREMENT", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "CRITERION_REQUIREMENT_ID") }
    )
    @OrderBy(value="name.content")
    private Set<CriterionRequirement> hasCriterion = new HashSet<>();      
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_CHANNEL", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "CHANNEL_ID") }
    )
    private Set<Channel> hasChannel = new HashSet<>();     
    
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_CONSEPT", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "CONSEPT_ID") }
    )
    private Set<Consept> isClassifiedBy = new HashSet<>();        
    
        //------------ requires  -----------//
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_REQUIRES", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "REQUIRES_ID") }
    )
    @OrderBy(value="name.content")
    private Set<PublicService> requires = new HashSet<>(); 
    
    //------------ relation  -----------//
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "PUBLIC_SERVICE_RELATION", 
        joinColumns = { @JoinColumn(name = "PUBLIC_SERVICE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "RELATION_ID") }
    )
    @OrderBy(value="name.content")
    private Set<PublicService> relation = new HashSet<>();     
    
    public PublicService() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }

    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Text getKeyword() {
        return keyword;
    }

    public void setKeyword(Text keyword) {
        this.keyword = keyword;
    }

    public Set<ThematicArea> getThematicAreas() {
        return thematicAreas;
    }

    public void setThematicAreas(Set<ThematicArea> thematicAreas) {
        this.thematicAreas = thematicAreas;
    }

    public Set<PublicServiceType> getTypes() {
        return types;
    }

    public void setTypes(Set<PublicServiceType> types) {
        this.types = types;
    }

    public Set<NaturalLanguage> getLanguages() {
        return languages;
    }

    public void setLanguages(Set<NaturalLanguage> languages) {
        this.languages = languages;
    }

    public Set<Event> getIsGroupedBy() {
        return isGroupedBy;
    }

    public void setIsGroupedBy(Set<Event> isGroupedBy) {
        this.isGroupedBy = isGroupedBy;
    }

    public Set<Sector> getSectors() {
        return sectors;
    }

    public void setSectors(Set<Sector> sectors) {
        this.sectors = sectors;
    }

    public Set<Participation> getHasParticipation() {
        return hasParticipation;
    }

    public void setHasParticipation(Set<Participation> hasParticipation) {
        this.hasParticipation = hasParticipation;
    }

    public PublicServiceStatus getStatus() {
        return status;
    }

    public void setStatus(PublicServiceStatus status) {
        this.status = status;
    }

    public Set<Evidence> getHasInput() {
        return hasInput;
    }

    public void setHasInput(Set<Evidence> hasInput) {
        this.hasInput = hasInput;
    }

    public Set<Output> getProduces() {
        return produces;
    }

    public void setProduces(Set<Output> produces) {
        this.produces = produces;
    }

    public Set<Cost> getHasCost() {
        return hasCost;
    }

    public void setHasCost(Set<Cost> hasCost) {
        this.hasCost = hasCost;
    }

    public Set<ContactPoint> getHasContactPoint() {
        return hasContactPoint;
    }

    public void setHasContactPoint(Set<ContactPoint> hasContactPoint) {
        this.hasContactPoint = hasContactPoint;
    }

    public Set<PublicServiceDataset> getIsDescribedAt() {
        return isDescribedAt;
    }

    public void setIsDescribedAt(Set<PublicServiceDataset> isDescribedAt) {
        this.isDescribedAt = isDescribedAt;
    }

    public Set<Location> getSpatial() {
        return spatial;
    }

    public void setSpatial(Set<Location> spatial) {
        this.spatial = spatial;
    }

    public Set<Rule> getFollows() {
        return follows;
    }

    public void setFollows(Set<Rule> follows) {
        this.follows = follows;
    }

    public Duration getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(Duration processingTime) {
        this.processingTime = processingTime;
    }

    public Set<CriterionRequirement> getHasCriterion() {
        return hasCriterion;
    }

    public void setHasCriterion(Set<CriterionRequirement> hasCriterion) {
        this.hasCriterion = hasCriterion;
    }

    public Set<Channel> getHasChannel() {
        return hasChannel;
    }

    public void setHasChannel(Set<Channel> hasChannel) {
        this.hasChannel = hasChannel;
    }

    public Set<Consept> getIsClassifiedBy() {
        return isClassifiedBy;
    }

    public void setIsClassifiedBy(Set<Consept> isClassifiedBy) {
        this.isClassifiedBy = isClassifiedBy;
    }

    public Set<PublicService> getRequires() {
        return requires;
    }

    public void setRequires(Set<PublicService> requires) {
        this.requires = requires;
    }

    public Set<PublicService> getRelation() {
        return relation;
    }

    public void setRelation(Set<PublicService> relation) {
        this.relation = relation;
    }

    
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    } 

}
