
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * Not all public services are needed or usable by everyone. For example, the 
 * visa service operated by European countries is not needed by European 
 * citizens but is needed by some citizens from elsewhere, or public services 
 * offering unemployment benefits and grants are targeting specific societal groups.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="CRITERION_REQUIREMENT")
public class CriterionRequirement {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    protected Text name = new Text();
       
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "CRITERION_REQUIREMENT_CRITERION_REQUIREMENT_TYPE", 
        joinColumns = { @JoinColumn(name = "CRITERION_REQUIREMENT_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "CRITERION_REQUIREMENT_TYPE_ID") }
    )
    @OrderBy(value="description")
    private Set<CriterionRequirementType> types = new HashSet<>();    

    public CriterionRequirement() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }

    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Set<CriterionRequirementType> getTypes() {
        return types;
    }

    public void setTypes(Set<CriterionRequirementType> types) {
        this.types = types;
    }

  
    
}
