package gr.eap.cpsvap.entity.helper;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Currency authority table is a controlled vocabulary that lists 
 * concepts associated with currencies.
 * 
 * @author Katerina Zerva
 */


@Entity
@Table(name="CURRENCY")
public class Currency implements Cloneable{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Column(name="CODE")
    String code;    
    
    @Column(name="DESCRIPTION")
    String description;

    public Currency() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

 
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

