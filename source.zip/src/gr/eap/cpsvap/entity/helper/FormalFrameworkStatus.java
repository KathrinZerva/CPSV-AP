
package gr.eap.cpsvap.entity.helper;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * This property represents the Status of the Formal Framework, for instance in 
 * force, not in force, partially applicable, implicitly revoked, explicitly 
 * revoked, repealed, expired, suspended, … 
 * The possible values for this property are described in a controlled vocabulary. 
 * 
 * @author Jim
 */

@Entity
@Table(name="FORMAL_FRAMEWORK_STATUS")
public class FormalFrameworkStatus {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;    
    
    @Column(name="NAME")
    String name;

    public FormalFrameworkStatus() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
