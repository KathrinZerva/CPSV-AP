package gr.eap.cpsvap.entity.helper;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The type property of the Processing Time class uses a controlled vocabulary 
 * to indicate  whether the indicated period is: exact, minimum, maximum or average.
 *
 * @author Katerina Zerva
 */


@Entity
@Table(name="PROCESSING_TIME_TYPE")
public class ProcessingTimeType implements Cloneable{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;    
    
    @Column(name="DESCRIPTION")
    String name;

    public ProcessingTimeType() {
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}

