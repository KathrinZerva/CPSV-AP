package gr.eap.cpsvap.entity.helper;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 *RFC 3066 provides a commonly used set of identifiers for natural languages. 
 * This is the set recognised by UN/CEFACT and XML Schema. Languages are 
 * represented by ISO 3166-1 Alpha 2 codes (e.g. “de” for German), optionally 
 * followed by a locale definition such as "-AT" meaning "German as spoken in Austria.”.
 * “de” (German), “de-at” (German as spoken in Austria)
 * 
 * @author Katerina Zerva
 */


@Entity
@Table(name="NATURAL_LANGUAGE")
public class NaturalLanguage implements Cloneable{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Column(name="CODE")
    String code;    
    
    @Column(name="DESCRIPTION")
    String name;

    public NaturalLanguage() {
    }

    public NaturalLanguage(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

