
package gr.eap.cpsvap.entity.helper;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 *This property represents the Type of a Formal Framework as described in a 
 * controlled vocabulary (e.g. directive, law, draft proposition, 
 * Parliamentary act, ministerial decision etc.). 
 * The possible values for this property are described in a controlled vocabulary. 
 * 
 * @author Jim
 */
@Entity
@Table(name="FORMAL_FRAMEWORK_TYPE")
public class FormalFrameworkType {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;    
    
    @Column(name="NAME")
    String name;

    public FormalFrameworkType() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
