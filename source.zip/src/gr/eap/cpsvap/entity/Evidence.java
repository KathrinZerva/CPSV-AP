package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * Evidence can be any resource - document, artefact – anything needed for 
 * executing the Public Service. In the context of Public Services, Evidence is 
 * usually administrative documents or completed application forms. A specific 
 * Public Service may require the presence of certain Evidence or combinations 
 * of Evidence in order to be delivered.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="EVIDENCE")
public class Evidence {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    protected Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    protected Text description = new Text(); 
    
           
    @ManyToOne(targetEntity = EvidenceType.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "EVIDENCE_TYPE_ID")
    private EvidenceType type = new EvidenceType(); 
    
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "EVIDENCE_LANGUAGE", 
        joinColumns = { @JoinColumn(name = "EVIDENCE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "LANGUAGE_ID") }
    )
    @OrderBy(value="code")
    private Set<NaturalLanguage> languages = new HashSet<>();
    
    public Evidence() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }


    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }


    public EvidenceType getType() {
        return type;
    }

    public void setType(EvidenceType type) {
        this.type = type;
    }

    public Set<NaturalLanguage> getLanguages() {
        return languages;
    }

    public void setLanguages(Set<NaturalLanguage> languages) {
        this.languages = languages;
    }

}
