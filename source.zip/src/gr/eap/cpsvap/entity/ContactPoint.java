package gr.eap.cpsvap.entity;


/**
    In CPSV-AP_IT and in Estonia contact information is being added to the model. 
* In CPSV-AP_IT this is done by adding a property “hasServiceContactPoint” 
* which is an association between Public Service and Organization.

    In Estonia the contact information was added as properties of the Service owner. 
* More specifically, the following properties are being added:

    Phone
    E-mail
* 
 * @author Katerina Zerva
 * 
 * 
 */

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "CONTACT_POINT")
public class ContactPoint implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;      
    
    @Column(name = "NAME")
    private String name;      
    
 
    public ContactPoint(){

    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
}
