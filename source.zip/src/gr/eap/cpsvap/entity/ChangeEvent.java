package gr.eap.cpsvap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The Life Event class represents an important event or situations in a 
 * citizen's life where public services may be required. Note the scope: 
 * an individual will encounter any number of 'events' in the general sense of 
 * the word. In the context of the CPSV-AP, the Life Event class only represents 
 * an event for which a Public Service is related. For example, a couple becoming 
 * engaged is not a CPSV-AP Life Event, getting married is, since only the 
 * latter has any relevance to public services. 
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="CHANGE_EVENT")
public class ChangeEvent{
        
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @ManyToOne(targetEntity = FormalFramework.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "FORMAL_FRAMEWORK_ID")
    private FormalFramework hasFormalFramework = new FormalFramework();

    
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "ORIGINAL_ORGANIZATION_ID")
    private PublicOrganization originalOrganization = new PublicOrganization();    

    
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "RESULTING_ORGANIZATION_ID")
    private PublicOrganization resultingOrganization = new PublicOrganization();      
    

    public ChangeEvent() {
    }

    public FormalFramework getHasFormalFramework() {
        return hasFormalFramework;
    }

    public void setHasFormalFramework(FormalFramework hasFormalFramework) {
        this.hasFormalFramework = hasFormalFramework;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public PublicOrganization getOriginalOrganization() {
        return originalOrganization;
    }

    public void setOriginalOrganization(PublicOrganization originalOrganization) {
        this.originalOrganization = originalOrganization;
    }

    public PublicOrganization getResultingOrganization() {
        return resultingOrganization;
    }

    public void setResultingOrganization(PublicOrganization resultingOrganization) {
        this.resultingOrganization = resultingOrganization;
    }
    

 
}
