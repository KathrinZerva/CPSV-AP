
package gr.eap.cpsvap.entity;

/**
 *
 * @author Katerina Zerva
 */
public class Type {
    
}
