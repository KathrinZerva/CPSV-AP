
package gr.eap.cpsvap.entity.composite;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Embeddable;

/**
 * A character string used to identify a resource.
 * @author Katerina Zerva
 */
@Embeddable
public class Identifier implements Serializable{

    String identifier;
    String type;
    Date issueDate;
    String issuingAuthority;
    String issuingAuthorityURI;

    public Identifier() {
    }

    public Identifier(String identifier, String type, Date issueDate, String issuingAuthority, String issuingAuthorityURI) {
        this.identifier = identifier;
        this.type = type;
        this.issueDate = issueDate;
        this.issuingAuthority = issuingAuthority;
        this.issuingAuthorityURI = issuingAuthorityURI;
    }

    
    
    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    public void setIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
    }

    public String getIssuingAuthorityURI() {
        return issuingAuthorityURI;
    }

    public void setIssuingAuthorityURI(String issuingAuthorityURI) {
        this.issuingAuthorityURI = issuingAuthorityURI;
    }

 
    
    
}
