
package gr.eap.cpsvap.entity.composite;

import java.io.Serializable;
import javax.persistence.Embeddable;

/**
 * A term from a controlled vocabulary.
 * @author Katerina Zerva
 */
@Embeddable
public class Code implements Serializable{

    String content;
    String list;
    String listAgency;
    String listVersion;

    public Code() {
    }

    public Code(String content, String list, String listAgency, String listVersion) {
        this.content = content;
        this.list = list;
        this.listAgency = listAgency;
        this.listVersion = listVersion;
    }

    
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getList() {
        return list;
    }

    public void setList(String list) {
        this.list = list;
    }

    public String getListAgency() {
        return listAgency;
    }

    public void setListAgency(String listAgency) {
        this.listAgency = listAgency;
    }

    public String getListVersion() {
        return listVersion;
    }

    public void setListVersion(String listVersion) {
        this.listVersion = listVersion;
    }

    
    
}
