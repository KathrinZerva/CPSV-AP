/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Katerina Zerva
 */
@Entity
@Table(name="FEK")

public class FekB {
    @Id
    @Column(name="ID")
    @GeneratedValue
    Integer id;
    @Column(name="YEAR")
    Integer year;    
    @Column(name="NAME")
    String name;
    @Column(name="FEK_NUMBER")    
    String fekNumber;
    @Column(name="DATE_PUBLISHED")        
    String datePublished;
    @Column(name="HEADER")      
    String header; 
    @Column(name="BODY")      
    String body;     
    @Column(name="CONTENT")      
    String content;
    @Column(name="URL")         
    String url;

    public FekB() {
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFekNumber() {
        return fekNumber;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public void setFekNumber(String fekNumber) {
        this.fekNumber = fekNumber;
    }

    public String getDatePublished() {
        return datePublished;
    }

    public void setDatePublished(String datePublished) {
        this.datePublished = datePublished;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
    
}
