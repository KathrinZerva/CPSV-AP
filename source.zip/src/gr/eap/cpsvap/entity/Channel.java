package gr.eap.cpsvap.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * The Channel class represents the medium through which an Agent provides, 
 * uses or interacts in another way with a Public Service. Typical examples 
 * include online services, phone, walk-in centres etc.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="CHANNEL")
public class Channel {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
            
    @Column(name = "OPENING_HOURS")
    String openingHours;     
    
    @Column(name = "AVAILABILITY_RESTRICTION")
    String availabilityRestriction;   
    
    
    @ManyToOne(targetEntity = ChannelType.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "CHANNEL_TYPE_ID")
    private ChannelType type = new ChannelType();

        
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "CHANNEL_PUBLIC_ORGANIZATION", 
        joinColumns = { @JoinColumn(name = "CHANNEL_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "PUBLIC_ORGANIZATION_ID") }
    )
    Set<PublicOrganization> ownedBy = new HashSet<>();
        
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "CHANNEL_EVIDENCE", 
        joinColumns = { @JoinColumn(name = "CHANNEL_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "EVIDENCE_ID") }
    )
    Set<Evidence> hasInput = new HashSet<>();    

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }

    public String getOpeningHours() {
        return openingHours;
    }

    public void setOpeningHours(String openingHours) {
        this.openingHours = openingHours;
    }

    public String getAvailabilityRestriction() {
        return availabilityRestriction;
    }

    public void setAvailabilityRestriction(String availabilityRestriction) {
        this.availabilityRestriction = availabilityRestriction;
    }

    public ChannelType getType() {
        return type;
    }

    public void setType(ChannelType type) {
        this.type = type;
    }

    public Set<PublicOrganization> getOwnedBy() {
        return ownedBy;
    }

    public void setOwnedBy(Set<PublicOrganization> ownedBy) {
        this.ownedBy = ownedBy;
    }

    public Set<Evidence> getHasInput() {
        return hasInput;
    }

    public void setHasInput(Set<Evidence> hasInput) {
        this.hasInput = hasInput;
    }
 
}
