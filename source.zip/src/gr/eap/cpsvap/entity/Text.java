package gr.eap.cpsvap.entity;

/**
 * The text data type is a combination of a string and a language identifier. It
 * is useful for names and descriptions that are available in multiple
 * languages. Where this is so, each version of the data should be included and
 * each one associated with the relevant language identifier.
 *
 * @author Katerina Zerva
 */

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class Text implements Serializable{

    String content = new String();
    String language = new String();

    public Text() {
        content = new String();
        language = new String();
    }

    public Text(String content, String language) {
        this.content = content;
        this.language = language;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    @Override
    public String toString() {
        return "Text{" + "content=" + content + ", language=" + language + '}';
    }

}
