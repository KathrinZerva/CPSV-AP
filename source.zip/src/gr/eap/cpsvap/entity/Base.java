package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;

/**
 * Has the basic properties
 * @author Jim
 */
public class Base {
    protected Identifier identifier;
    protected Text name;
    protected Text description;

    public Base() {
    }

    
    
    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }
    
    
    
}
