package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * The Rule class represents a document that sets out the specific rules, 
 * guidelines or procedures that the Public Service follows. It includes the 
 * terms of service, licence, and authentication requirements of the Public Service.
 * 
 * @author Katerina Zerva
 */
@Entity
@Table(name="RULE")
public class Rule {
  @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();    
    
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )  
   private Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    private Text description = new Text();    
        
    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "RULE_LANGUAGE", 
        joinColumns = { @JoinColumn(name = "RULE_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "LANGUAGE_ID") }
    )
    @OrderBy(value="code")
    private Set<NaturalLanguage> languages = new HashSet<>();


    public Rule() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }

    public Set<NaturalLanguage> getLanguages() {
        return languages;
    }

    public void setLanguages(Set<NaturalLanguage> languages) {
        this.languages = languages;
    }


    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }


    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    
}
