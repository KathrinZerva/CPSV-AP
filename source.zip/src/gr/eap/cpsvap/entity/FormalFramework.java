package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Code;
import gr.eap.cpsvap.entity.composite.Identifier;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Legislation, policy, or policies lying behind the rules that govern a public
 * service. This class and its properties are defined in the Core Public Service
 * Vocabulary and may represent legislation or official policy that leads to a
 * change event, including the establishment of the organization.
 *
 * @author Katerina Zerva
 */
@Entity
@Table(name="FORMAL_FRAMEWORK")
public class FormalFramework implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="identifier", column = @Column(name="IDENTIFIER_IDENTIFIER") ),
        @AttributeOverride(name="type", column = @Column(name="IDENTIFIER_TYPE") ),
        @AttributeOverride(name="issueDate", column = @Column(name="IDENTIFIER_ISSUE_DATE") ),        
        @AttributeOverride(name="issuingAuthority", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY") ),
        @AttributeOverride(name="issuingAuthorityURI", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY_URI") ),        
    } )
    private Identifier identifier = new Identifier(); 
    
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    private Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    private Text description = new Text();  
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="LANGUAGE_CONTENT") ),
        @AttributeOverride(name="list", column = @Column(name="LANGUAGE_LIST") ),
        @AttributeOverride(name="listAgency", column = @Column(name="LANGUAGE_LIST_AGENCY") ),        
        @AttributeOverride(name="listVersion", column = @Column(name="LANGUAGE_LIST_VERSION") )        
    } )
    private Code language = new Code();      
    
    @Column(name = "STATUS")
    String status;     
    
    @Column(name = "TYPE")
    String type;     
    
    @Column(name = "SUBJECT")
    String subject;         
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="TERRITORIAL_APPLICATION_CONTENT") ),
        @AttributeOverride(name="list", column = @Column(name="TERRITORIAL_APPLICATION_LIST") ),
        @AttributeOverride(name="listAgency", column = @Column(name="TERRITORIAL_APPLICATION_LIST_AGENCY") ),        
        @AttributeOverride(name="listVersion", column = @Column(name="TERRITORIAL_APPLICATION_LIST_VERSION") )        
    } )
    private Code territorialApplication = new Code();       
  
    
    @ManyToOne()
    @JoinColumn(name = "FORMAL_FRAMEWORK_ID")
    private FormalFramework related;

    @OneToMany(mappedBy = "related")
    private Set<FormalFramework> subs = new HashSet<>();
    

    
    public FormalFramework() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Code getLanguage() {
        return language;
    }

    public void setLanguage(Code language) {
        this.language = language;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Code getTerritorialApplication() {
        return territorialApplication;
    }

    public void setTerritorialApplication(Code territorialApplication) {
        this.territorialApplication = territorialApplication;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public FormalFramework getRelated() {
        return related;
    }

    public void setRelated(FormalFramework related) {
        this.related = related;
    }

    public Set<FormalFramework> getSubs() {
        return subs;
    }

    public void setSubs(Set<FormalFramework> subs) {
        this.subs = subs;
    }

    

}
