package gr.eap.cpsvap.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
*This class represents any concept that can be used for classifying the Public 
* Service and which relates to the Public Service through the property Is 
* Classified By (section 3.2.26). This class has been added in the CPSV-AP 
* to complement the need for adding other ways of classifying the Public Service,
* which have not been explicitely defined in the CPSV-AP.
 *
 * @author Katerina Zerva
 */

@Entity
@Table(name="CONSEPT")
@Inheritance(strategy = InheritanceType.JOINED)
public class Consept {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="PREFLABEL_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="PREFLABEL_LANGUAGE") )
    } )
    protected Text prefLabel = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="ALTLABEL_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="ALTLABEL_LANGUAGE") )
    } )
    protected Text altLabel = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="HIDDENLABEL_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="HIDDENLABEL_LANGUAGE") )
    } )
    protected Text hiddenLabel = new Text();    
   
    public Consept() {
    }

     public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getPrefLabel() {
        return prefLabel;
    }

    public void setPrefLabel(Text prefLabel) {
        this.prefLabel = prefLabel;
    }

    public Text getAltLabel() {
        return altLabel;
    }

    public void setAltLabel(Text altLabel) {
        this.altLabel = altLabel;
    }

    public Text getHiddenLabel() {
        return hiddenLabel;
    }

    public void setHiddenLabel(Text hiddenLabel) {
        this.hiddenLabel = hiddenLabel;
    }

 

}
