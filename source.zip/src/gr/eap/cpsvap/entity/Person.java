package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Code;
import gr.eap.cpsvap.entity.location.Address;
import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;

/**
 * A natural person.
 *
 * @author Katerina Zerva
 */
@Entity
@Table(name="PERSON")
@PrimaryKeyJoinColumn(name = "AGENT_ID")
public class Person extends Agent{

    @Column(name = "FULL_NAME")
    String fullName;
    
    @Column(name = "GIVEN_NAME")    
    String givenName;
    
    @Column(name = "FAMILY_NAME")        
    String familyName;
    
    @Column(name = "PATRONYMIC_NAME")      
    String patronymicName;
    
    @Column(name = "ALTERNATIVE_NAME")       
    String alternativeName;
    
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="GENDER_CONTENT") ),
        @AttributeOverride(name="list", column = @Column(name="GENDER_LIST") ),
        @AttributeOverride(name="listAgency", column = @Column(name="GENDER_LIST_AGENCY") ),        
        @AttributeOverride(name="listVersion", column = @Column(name="GENDER_LIST_VERSION") )        
    } )
    private Code gender = new Code();
        
    @Column(name = "BIRTH_NAME")       
    String birthName;
    
    @Column(name = "BIRTH_DATE")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dateOfBirth;
    
    @Column(name = "DEATH_DATE")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dateOfDeath;    
    
    @ManyToOne(targetEntity = Jurisdiction.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "CITIZENSHIP_ID")
    private Jurisdiction citizenship = new Jurisdiction();
    
    @ManyToOne(targetEntity = Jurisdiction.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "RESIDENCY_ID")
    private Jurisdiction residency = new Jurisdiction();    
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="COUNTRY_OF_BIRTH_ID")
    private Location countryOfBirth = new Location();
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="COUNTRY_OF_DEATH_ID")
    private Location countryOfDeath = new Location();  
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="PLACE_OF_BIRTH_ID")
    private Location placeOfBirth = new Location();
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="PLACE_OF_DEATH_ID")
    private Location placeOfDeath = new Location();  
    

    public Person() {
    }


    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getPatronymicName() {
        return patronymicName;
    }

    public void setPatronymicName(String patronymicName) {
        this.patronymicName = patronymicName;
    }

    public String getAlternativeName() {
        return alternativeName;
    }

    public void setAlternativeName(String alternativeName) {
        this.alternativeName = alternativeName;
    }


    public String getBirthName() {
        return birthName;
    }

    public void setBirthName(String birthName) {
        this.birthName = birthName;
    }

    public Code getGender() {
        return gender;
    }

    public void setGender(Code gender) {
        this.gender = gender;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Date getDateOfDeath() {
        return dateOfDeath;
    }

    public void setDateOfDeath(Date dateOfDeath) {
        this.dateOfDeath = dateOfDeath;
    }

    public Jurisdiction getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(Jurisdiction citizenship) {
        this.citizenship = citizenship;
    }

    public Jurisdiction getResidency() {
        return residency;
    }

    public void setResidency(Jurisdiction residency) {
        this.residency = residency;
    }

    public Location getCountryOfBirth() {
        return countryOfBirth;
    }

    public void setCountryOfBirth(Location countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    public Location getCountryOfDeath() {
        return countryOfDeath;
    }

    public void setCountryOfDeath(Location countryOfDeath) {
        this.countryOfDeath = countryOfDeath;
    }

    public Location getPlaceOfBirth() {
        return placeOfBirth;
    }

    public void setPlaceOfBirth(Location placeOfBirth) {
        this.placeOfBirth = placeOfBirth;
    }

    public Location getPlaceOfDeath() {
        return placeOfDeath;
    }

    public void setPlaceOfDeath(Location placeOfDeath) {
        this.placeOfDeath = placeOfDeath;
    }

    
 
}
