package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class represents the time it takes to operate a Public Service or to
 * complete a change in the provision of a Public Service for a given client.
 * Typically this will be the time taken to process an application once it has
 * been received by the service provider. This can be a time range, an average
 * time, an exact time for execution or any other indication of time. The actual
 * information is provided by a combination of three properties in addition to
 * the usual identifier. They indicate the number and unit of time (e.g. 3 days)
 * plus an indication whether this is an average time, an exact time or a
 * maximum time.
 *
 * @author Katerina Zerva
 */

@Entity
@Table(name = "PROCESSING_TIME")
public class ProcessingTime {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "identifier", column = @Column(name = "IDENTIFIER_IDENTIFIER")),
        @AttributeOverride(name = "type", column = @Column(name = "IDENTIFIER_TYPE")),
        @AttributeOverride(name = "issueDate", column = @Column(name = "IDENTIFIER_ISSUE_DATE")),        
        @AttributeOverride(name = "issuingAuthority", column = @Column(name = "IDENTIFIER_ISSUING_AUTHORITY")),
        @AttributeOverride(name = "issuingAuthorityURI", column = @Column(name = "IDENTIFIER_ISSUING_AUTHORITY_URI"))})
    private Identifier identifier = new Identifier();
    
    @Column(name = "MEASUREMENT_UNIT")  
    String measurementUnit;
    @Column(name = "QUANTITATIVE_VALUE")  
    Float quantitativeValue;
    @Column(name = "OPENING_HOURS")          
    String openingHours;

    public ProcessingTime() {
    }
    
    

    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }


    public Float getQuantitativeValue() {
        return quantitativeValue;
    }

    public void setQuantitativeValue(Float quantitativeValue) {
        this.quantitativeValue = quantitativeValue;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMeasurementUnit() {
        return measurementUnit;
    }

    public void setMeasurementUnit(String measurementUnit) {
        this.measurementUnit = measurementUnit;
    }

    public String getOpeningHours() {
        return openingHours;
    }

    public void setOpeningHours(String openingHours) {
        this.openingHours = openingHours;
    }

    
    
    

}
