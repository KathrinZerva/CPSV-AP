package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.helper.Currency;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * An intended result whose required inputs and processes are entirely within 
 * the control of the planning organization.
 * 
 * @author Katerina Zerva
 */
@Entity
@Table(name="OUTPUT")
public class Output {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    protected Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    protected Text description = new Text(); 
    
    @ManyToOne(targetEntity = Currency.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "OUTPUT_CURRENCY_ID")
    private Currency currency = new Currency();  
    
    @ManyToOne(targetEntity = Currency.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "OUTPUT_IS_DEFINED_BY_ID")
    private Currency isDefinedBy = new Currency();      
    
    public Output() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }

    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Currency getIsDefinedBy() {
        return isDefinedBy;
    }

    public void setIsDefinedBy(Currency isDefinedBy) {
        this.isDefinedBy = isDefinedBy;
    }




}
