/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 *
 * @author Jim
 */
@Entity
@Table(name = "PUBLIC_ORGANIZATION")
@PrimaryKeyJoinColumn(name = "ORGANIZATION_ID")
@Inheritance(strategy = InheritanceType.JOINED)
public class PublicOrganization extends Organization {

    @Column(name = "PREFERRED_LABEL")
    String preferredLabel;
    
    @Column(name = "ALTERNATIVE_LABEL")
    String alternativeLabel;    
    
    @Column(name = "PUBLIC_ORGANIZATION_SPATIAL")
    String spatial;    
    
    @Column(name = "PURPOSE")
    String purpose;        
    
    @Column(name = "CLASSIFICATION")
    String classification;      
    
    
    @Column(name = "DESCRIPTION")
    String description;
    
    @Column(name = "HOMEPAGE")
    String homepage;    
    
    
    @Column(name = "LOGO")
    String logo;      

    //------------ SubOrganization  -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_ORGANIZATION_ID")
    private PublicOrganization subOrganization;

    @OneToMany(mappedBy = "subOrganization", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> subOrganizationChildren = new HashSet<>();    
   
    //------------ SubOrganizationOf -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_ORGANIZATION_OF_ID")
    private PublicOrganization subOrganizationOf;

    @OneToMany(mappedBy = "subOrganizationOf", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> subOrganizationOfChildren = new HashSet<>();     
    
    //------------ hasUnit -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "HAS_UNIT_ID")
    private PublicOrganization hasUnit;

    @OneToMany(mappedBy = "hasUnit", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> hasUnitChildren = new HashSet<>();     
        
    //------------ Unit Of -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "UNIT_OF_ID")
    private PublicOrganization unitOf;

    @OneToMany(mappedBy = "unitOf", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> unitOfChildren = new HashSet<>();
    
    //------------ hasMember -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "HAS_MEMBER_ID")
    private PublicOrganization hasMember;

    @OneToMany(mappedBy = "hasMember", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> hasMemberChildren = new HashSet<>();     
        
    //------------ Member Of -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "MEMBER_OF_ID")
    private PublicOrganization memberOf;

    @OneToMany(mappedBy = "memberOf", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> memberOfChildren = new HashSet<>(); 
    
    //------------ Prev -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "PREV_ID")
    private PublicOrganization prev;

    @OneToMany(mappedBy = "prev", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> prevChildren = new HashSet<>();      
    
    //------------ Next -----------//
    @ManyToOne(targetEntity = PublicOrganization.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "NEXT_ID")
    private PublicOrganization next;

    @OneToMany(mappedBy = "next", cascade = {CascadeType.DETACH})
    private Set<PublicOrganization> nextChildren = new HashSet<>();       
    
    
    

    public PublicOrganization() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPreferredLabel() {
        return preferredLabel;
    }

    public void setPreferredLabel(String preferredLabel) {
        this.preferredLabel = preferredLabel;
    }

    public String getAlternativeLabel() {
        return alternativeLabel;
    }

    public void setAlternativeLabel(String alternativeLabel) {
        this.alternativeLabel = alternativeLabel;
    }

    public String getSpatial() {
        return spatial;
    }

    public void setSpatial(String spatial) {
        this.spatial = spatial;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public PublicOrganization getSubOrganization() {
        return subOrganization;
    }

    public void setSubOrganization(PublicOrganization subOrganization) {
        this.subOrganization = subOrganization;
    }

    public Set<PublicOrganization> getSubOrganizationChildren() {
        return subOrganizationChildren;
    }

    public void setSubOrganizationChildren(Set<PublicOrganization> subOrganizationChildren) {
        this.subOrganizationChildren = subOrganizationChildren;
    }

    public PublicOrganization getSubOrganizationOf() {
        return subOrganizationOf;
    }

    public void setSubOrganizationOf(PublicOrganization subOrganizationOf) {
        this.subOrganizationOf = subOrganizationOf;
    }

    public Set<PublicOrganization> getSubOrganizationOfChildren() {
        return subOrganizationOfChildren;
    }

    public void setSubOrganizationOfChildren(Set<PublicOrganization> subOrganizationOfChildren) {
        this.subOrganizationOfChildren = subOrganizationOfChildren;
    }

    public PublicOrganization getHasUnit() {
        return hasUnit;
    }

    public void setHasUnit(PublicOrganization hasUnit) {
        this.hasUnit = hasUnit;
    }

    public Set<PublicOrganization> getHasUnitChildren() {
        return hasUnitChildren;
    }

    public void setHasUnitChildren(Set<PublicOrganization> hasUnitChildren) {
        this.hasUnitChildren = hasUnitChildren;
    }

    public PublicOrganization getUnitOf() {
        return unitOf;
    }

    public void setUnitOf(PublicOrganization unitOf) {
        this.unitOf = unitOf;
    }

    public Set<PublicOrganization> getUnitOfChildren() {
        return unitOfChildren;
    }

    public void setUnitOfChildren(Set<PublicOrganization> unitOfChildren) {
        this.unitOfChildren = unitOfChildren;
    }

    public PublicOrganization getHasMember() {
        return hasMember;
    }

    public void setHasMember(PublicOrganization hasMember) {
        this.hasMember = hasMember;
    }

    public Set<PublicOrganization> getHasMemberChildren() {
        return hasMemberChildren;
    }

    public void setHasMemberChildren(Set<PublicOrganization> hasMemberChildren) {
        this.hasMemberChildren = hasMemberChildren;
    }

    public PublicOrganization getMemberOf() {
        return memberOf;
    }

    public void setMemberOf(PublicOrganization memberOf) {
        this.memberOf = memberOf;
    }

    public Set<PublicOrganization> getMemberOfChildren() {
        return memberOfChildren;
    }

    public void setMemberOfChildren(Set<PublicOrganization> memberOfChildren) {
        this.memberOfChildren = memberOfChildren;
    }

    public PublicOrganization getPrev() {
        return prev;
    }

    public void setPrev(PublicOrganization prev) {
        this.prev = prev;
    }

    public Set<PublicOrganization> getPrevChildren() {
        return prevChildren;
    }

    public void setPrevChildren(Set<PublicOrganization> prevChildren) {
        this.prevChildren = prevChildren;
    }

    public PublicOrganization getNext() {
        return next;
    }

    public void setNext(PublicOrganization next) {
        this.next = next;
    }

    public Set<PublicOrganization> getNextChildren() {
        return nextChildren;
    }

    public void setNextChildren(Set<PublicOrganization> nextChildren) {
        this.nextChildren = nextChildren;
    }
    
    

}
