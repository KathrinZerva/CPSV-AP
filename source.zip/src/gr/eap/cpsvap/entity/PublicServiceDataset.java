package gr.eap.cpsvap.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *The Public Service Dataset, is a specialisation of the Dataset class of the 
 * Data Catalog Vocabulary (DCAT)19 and inherits all its properties. The class 
 * describes the metadata of where the dataset is being described, for instance 
 * on a regional public service portal and/or a national eGovernment portal.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="PUBLIC_SERVICE_DATASET")
public class PublicServiceDataset {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    protected Text name = new Text();
    
    @Column(name = "LANDING_PAGE")
    String landingPage;   
                  
    @ManyToOne(targetEntity = Agent.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "PUBLIC_SERVICE_DATASET_AGENT_ID")
    private Agent publisher = new Agent();  
    
    
    public PublicServiceDataset() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }


    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public String getLandingPage() {
        return landingPage;
    }

    public void setLandingPage(String landingPage) {
        this.landingPage = landingPage;
    }

    public Agent getPublisher() {
        return publisher;
    }

    public void setPublisher(Agent publisher) {
        this.publisher = publisher;
    }


}
