
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * An entity that is able to carry out actions.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="CRITERION")
public class Criterion {
   @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="identifier", column = @Column(name="IDENTIFIER_IDENTIFIER") ),
        @AttributeOverride(name="type", column = @Column(name="IDENTIFIER_TYPE") ),
        @AttributeOverride(name="issueDate", column = @Column(name="IDENTIFIER_ISSUE_DATE") ),        
        @AttributeOverride(name="issuingAuthority", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY") ),
        @AttributeOverride(name="issuingAuthorityURI", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY_URI") ),        
    } )
    private Identifier identifier = new Identifier(); 
            
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )  
   private Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    private Text description = new Text();  
    
    @Column(name = "WEIGHT")
    Float weight;
    
    @Column(name = "FULFILLED_INDICATOR")
    @org.hibernate.annotations.Type(type = "yes_no")
    private Boolean fulfilledIndicator = Boolean.FALSE;
          
    @ManyToOne(targetEntity = FormalFramework.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "FORMAL_FRAMEWORK_ID")
    private FormalFramework isDefinedInFormalFramework = new FormalFramework();
        
    @ManyToOne(targetEntity = RequirementGroup.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "REQUIREMENT_GROUP_ID")
    private RequirementGroup fulfilledByRequirementGroup = new RequirementGroup();    
    
    
    public Criterion() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }

    public Boolean getFulfilledIndicator() {
        return fulfilledIndicator;
    }

    public void setFulfilledIndicator(Boolean fulfilledIndicator) {
        this.fulfilledIndicator = fulfilledIndicator;
    }

    public FormalFramework getIsDefinedInFormalFramework() {
        return isDefinedInFormalFramework;
    }

    public void setIsDefinedInFormalFramework(FormalFramework isDefinedInFormalFramework) {
        this.isDefinedInFormalFramework = isDefinedInFormalFramework;
    }

    public RequirementGroup getFulfilledByRequirementGroup() {
        return fulfilledByRequirementGroup;
    }

    public void setFulfilledByRequirementGroup(RequirementGroup fulfilledByRequirementGroup) {
        this.fulfilledByRequirementGroup = fulfilledByRequirementGroup;
    }

    
}
