
package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import gr.eap.cpsvap.entity.location.Address;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * An entity that is able to carry out actions.
 * 
 * @author Katerina Zerva
 */

@Entity
@Table(name="AGENT")
@Inheritance(strategy = InheritanceType.JOINED)
public class Agent {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    private Text name = new Text();
    
    @Column(name = "TYPE")
    String type; 
    
   @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="fullAddress.content", column = @Column(name="FULL_ADDRESS_CONTENT") ),
        @AttributeOverride(name="fullAddress.language", column = @Column(name="FULL_ADDRESS_LANGUAGE") ),  
        @AttributeOverride(name="poBox.content", column = @Column(name="PO_BOX_CONTENT") ),
        @AttributeOverride(name="poBox.language", column = @Column(name="PO_BOX_LANGUAGE") ), 
        @AttributeOverride(name="thoroughfare.content", column = @Column(name="THOROUGHFARE_CONTENT") ),
        @AttributeOverride(name="thoroughfare.language", column = @Column(name="THOROUGHFARE_LANGUAGE") ),
        @AttributeOverride(name="locatorDesignator.content", column = @Column(name="LOCATOR_DESIGNATOR_CONTENT") ),
        @AttributeOverride(name="locatorDesignator.language", column = @Column(name="LOCATOR_DESIGNATOR_LANGUAGE") ),        
        @AttributeOverride(name="locatorName.content", column = @Column(name="LOCATOR_NAME_CONTENT") ),
        @AttributeOverride(name="locatorName.language", column = @Column(name="LOCATOR_NAME_LANGUAGE") ),        
        @AttributeOverride(name="addressArea.content", column = @Column(name="ADDRESS_AREA_CONTENT") ),
        @AttributeOverride(name="addressArea.language", column = @Column(name="ADDRESS_AREA_LANGUAGE") ),
        @AttributeOverride(name="postName.content", column = @Column(name="POST_NAME_CONTENT") ),
        @AttributeOverride(name="postName.language", column = @Column(name="POST_NAME_LANGUAGE") ),
        @AttributeOverride(name="adminUnitL1.content", column = @Column(name="ADMIN_UNIT_L1_CONTENT") ),
        @AttributeOverride(name="adminUnitL1.language", column = @Column(name="ADMIN_UNIT_L1_LANGUAGE") ),
        @AttributeOverride(name="adminUnitL2.content", column = @Column(name="ADMIN_UNIT_L2_CONTENT") ),
        @AttributeOverride(name="adminUnitL2.language", column = @Column(name="ADMIN_UNIT_L2_LANGUAGE") ),          
        @AttributeOverride(name="postCode", column = @Column(name="ADDRESS_POST_CODE") ),        
        @AttributeOverride(name="addressId", column = @Column(name="ADDRESS_ADDRESS_ID") )        
    } )
    private Address hasAddress = new Address();    
    
    @ManyToOne(targetEntity = Criterion.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "CRITERION_ID")
    private Criterion satisfiesCriterion = new Criterion();       
   
    

    public Agent() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }


    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Address getHasAddress() {
        return hasAddress;
    }

    public void setHasAddress(Address hasAddress) {
        this.hasAddress = hasAddress;
    }



    public Criterion getSatisfiesCriterion() {
        return satisfiesCriterion;
    }

    public void setSatisfiesCriterion(Criterion satisfiesCriterion) {
        this.satisfiesCriterion = satisfiesCriterion;
    }

}
