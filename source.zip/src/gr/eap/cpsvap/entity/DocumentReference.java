package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import java.net.URL;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * A reference to the document, attestation or data, usually provided by a party
 * different from the one providing the response, that proves the response.
 *
 * @author Katerina Zerva
 */
@Entity
@Table(name="DOCUMENT_REFERENCE")
public class DocumentReference {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="identifier", column = @Column(name="IDENTIFIER_IDENTIFIER") ),
        @AttributeOverride(name="type", column = @Column(name="IDENTIFIER_TYPE") ),
        @AttributeOverride(name="issueDate", column = @Column(name="IDENTIFIER_ISSUE_DATE") ),        
        @AttributeOverride(name="issuingAuthority", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY") ),
        @AttributeOverride(name="issuingAuthorityURI", column = @Column(name="IDENTIFIER_ISSUING_AUTHORITY_URI") ),        
    } )
    protected Identifier identifier = new Identifier();  
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    private Text description = new Text();

    @Column(name = "URL")    
    String url;
    /*
    
    

Type - The document reference may contain the type that categorizes the attestation or
evidentiary document.

     */
    public DocumentReference() {
    }
    
    public Identifier getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }



}
