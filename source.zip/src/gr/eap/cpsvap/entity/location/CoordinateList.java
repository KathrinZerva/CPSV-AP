
package gr.eap.cpsvap.entity.location;

import java.util.List;

/**
 * A system of geometry where the position of points is described using an 
 * ordered pair of numbers.
 * 
 * @author Katerina Zerva
 */
public class CoordinateList {
    List<Float> position;

    public List<Float> getPosition() {
        return position;
    }

    public void setPosition(List<Float> position) {
        this.position = position;
    }
    
    
    
}
