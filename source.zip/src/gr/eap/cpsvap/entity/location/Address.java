package gr.eap.cpsvap.entity.location;

import gr.eap.cpsvap.entity.Text;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

/**
 * An address representing a location.
 *
 * @author Katerina Zerva
 */
@Embeddable
public class Address {

    @Embedded
    Text fullAddress = new Text();
    @Embedded
    Text poBox = new Text();
    @Embedded
    Text thoroughfare = new Text();
    @Embedded
    Text locatorDesignator = new Text();
    @Embedded
    Text locatorName = new Text();
    @Embedded
    Text addressArea = new Text();
    @Embedded
    Text postName = new Text();
    @Embedded
    Text adminUnitL1;
    @Embedded
    Text adminUnitL2;

    String postCode = new String();
    String addressId = new String();

    public Address() {
        fullAddress = new Text();
        poBox = new Text();
        thoroughfare = new Text();
        locatorDesignator = new Text();
        locatorName = new Text();
        addressArea = new Text();
        postName = new Text();
        postCode = new String();
        addressId = new String();
    }

    public Text getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(Text fullAddress) {
        this.fullAddress = fullAddress;
    }

    public Text getPoBox() {
        return poBox;
    }

    public void setPoBox(Text poBox) {
        this.poBox = poBox;
    }

    public Text getThoroughfare() {
        return thoroughfare;
    }

    public void setThoroughfare(Text thoroughfare) {
        this.thoroughfare = thoroughfare;
    }

    public Text getLocatorDesignator() {
        return locatorDesignator;
    }

    public void setLocatorDesignator(Text locatorDesignator) {
        this.locatorDesignator = locatorDesignator;
    }

    public Text getLocatorName() {
        return locatorName;
    }

    public void setLocatorName(Text locatorName) {
        this.locatorName = locatorName;
    }

    public Text getAddressArea() {
        return addressArea;
    }

    public void setAddressArea(Text addressArea) {
        this.addressArea = addressArea;
    }

    public Text getPostName() {
        return postName;
    }

    public void setPostName(Text postName) {
        this.postName = postName;
    }

    public Text getAdminUnitL1() {
        return adminUnitL1;
    }

    public void setAdminUnitL1(Text adminUnitL1) {
        this.adminUnitL1 = adminUnitL1;
    }

    public Text getAdminUnitL2() {
        return adminUnitL2;
    }

    public void setAdminUnitL2(Text adminUnitL2) {
        this.adminUnitL2 = adminUnitL2;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    @Override
    public String toString() {
        return "Address{" + "fullAddress=" + fullAddress + ", poBox=" + poBox + ", thoroughfare=" + thoroughfare + ", locatorDesignator=" + locatorDesignator + ", locatorName=" + locatorName + ", addressArea=" + addressArea + ", postName=" + postName + ", adminUnitL1=" + adminUnitL1 + ", adminUnitL2=" + adminUnitL2 + ", postCode=" + postCode + ", addressId=" + addressId + '}';
    }

}
