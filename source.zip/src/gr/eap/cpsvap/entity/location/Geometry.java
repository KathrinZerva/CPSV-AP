package gr.eap.cpsvap.entity.location;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

/**
 * A geometry representing a location.
 * 
 * @author Katerina Zerva
 */
@Embeddable
public class Geometry {

    String coordinates = new String();
    @Embedded
    String crs = new String();
    @Embedded    
    String type = new String();

    public Geometry() {

    }

    public String getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(String coordinates) {
        this.coordinates = coordinates;
    }

    public String getCrs() {
        return crs;
    }

    public void setCrs(String crs) {
        this.crs = crs;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
 
}
