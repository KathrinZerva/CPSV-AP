package gr.eap.cpsvap.entity;

import gr.eap.cpsvap.entity.composite.Identifier;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
* This class represents an event that can be of any type that triggers, makes 
* use of, or in some way is related to, a Public Service. It is not expected to 
* be used directly, rather, one or other of its subclasses should be used. 
* The properties of the class are, of course, inherited by those subclasses.
 *
 * @author Katerina Zerva
 */

@Entity
@Table(name="EVENT")
@Inheritance(strategy = InheritanceType.JOINED)
public class Event {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    Integer id;
     
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="IDENTIFIER_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="IDENTIFIER_LANGUAGE") )
    } )
    protected Text identifier = new Text();   
        
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="NAME_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="NAME_LANGUAGE") )
    } )
    protected Text name = new Text();
    
    @Embedded
    @AttributeOverrides( {
        @AttributeOverride(name="content", column = @Column(name="DESCRIPTION_CONTENT") ),
        @AttributeOverride(name="language", column = @Column(name="DESCRIPTION_LANGUAGE") )
    } )
    protected Text description = new Text();    
    
//    @ManyToOne(targetEntity = Jurisdiction.class, fetch = FetchType.LAZY)
//    @JoinColumn(name = "PUBLIC_SERVICE_ID")
//    protected PublicService relatedService = new PublicService(); 
    
    // Type


    public Event() {
    }

    
    
    
    /*
    

Type The type property links an Event to a controlled vocabulary of event types 
    and it is the nature of those controlled vocabularies that is the major 
    difference between a business event, such as creating the business in the 
    first place and a life event, such as the birth of a child.

    
     */

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Text getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Text identifier) {
        this.identifier = identifier;
    }


    public Text getName() {
        return name;
    }

    public void setName(Text name) {
        this.name = name;
    }

    public Text getDescription() {
        return description;
    }

    public void setDescription(Text description) {
        this.description = description;
    }

/*    public PublicService getRelatedService() {
        return relatedService;
    }

    public void setRelatedService(PublicService relatedService) {
        this.relatedService = relatedService;
    }
*/

}
