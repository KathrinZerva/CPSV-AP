package gr.eap.cpsvap.entity;


/**
Indicates whether a Public Service is active, inactive, under development etc. 
* according to a controlled vocabulary.

* Active
* Inactive
* Under development

…
 * 
 * @author Katerina Zerva
 * 
 * 
 */

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "PUBLIC_SERVICE_STATUS")
public class PublicServiceStatus implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;      
    
    @Column(name = "NAME")
    private String name;      
    
 
    public PublicServiceStatus(){

    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
}
