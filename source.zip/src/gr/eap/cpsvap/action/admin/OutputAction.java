package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.Output;
import gr.eap.cpsvap.entity.helper.Currency;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.CurrencyManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.OutputManager;
import gr.eap.cpsvap.vo.criteria.CurrencyCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.OutputCriteria;

public class OutputAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(OutputAction.class);
    //List of costs; Setter and Getter are below
    private List<Output> outputs;
    private List<NaturalLanguage> languages;    
    private List<Currency> currencies;        
    //Output object to be added; Setter and Getter are below
    private Output output;
    private List<Integer> selectedIds = new ArrayList<>();

    OutputCriteria criteria = new OutputCriteria();
    //Output manager injected by spring context; This is cool !!
    private OutputManager outputManager;
    private NaturalLanguageManager naturalLanguageManager;
    private CurrencyManager currencyManager;    
    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());  
        currencies = currencyManager.list(new CurrencyCriteria());  
        
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (OutputCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new OutputCriteria();
        }
        totalItems = outputManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        outputs = outputManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new OutputCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        output = new Output();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        output = outputManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        outputManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (output.getCurrency().getId() != null) {
            output.setCurrency(currencyManager.get(output.getCurrency().getId()));
        } else {
            output.setCurrency(null);
        } 
        if (output.getIsDefinedBy().getId() != null) {
            output.setIsDefinedBy(currencyManager.get(output.getIsDefinedBy().getId()));
        } else {
            output.setIsDefinedBy(null);
        }         
        outputManager.save(output);
        String message = "Message:Output successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (output != null && output.getId() != null) {
            selected = output.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    
    /**
     * ********* Getters Setters **********
     */
    public List<Output> getOutputs() {
        return outputs;
    }

    public void setOutputs(List<Output> outputs) {
        this.outputs = outputs;
    }

    public Output getOutput() {
        return output;
    }

    public void setOutput(Output output) {
        this.output = output;
    }


    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<Currency> getCurrencies() {
        return currencies;
    }
    
    public OutputCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(OutputCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param outputManager
     */
    public void setOutputManager(OutputManager outputManager) {
        this.outputManager = outputManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
    public void setCurrencyManager(CurrencyManager currencyManager) {
        this.currencyManager = currencyManager;
    }    
    
}
