package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.common.helper.StringToIds;
import gr.eap.cpsvap.entity.Agent;
import gr.eap.cpsvap.entity.Channel;
import gr.eap.cpsvap.entity.Consept;
import gr.eap.cpsvap.entity.ContactPoint;
import gr.eap.cpsvap.entity.Cost;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.entity.Duration;
import gr.eap.cpsvap.entity.Event;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.entity.Location;
import gr.eap.cpsvap.entity.Output;
import gr.eap.cpsvap.entity.Participation;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.entity.PublicService;
import gr.eap.cpsvap.entity.PublicServiceDataset;
import gr.eap.cpsvap.entity.PublicServiceStatus;
import gr.eap.cpsvap.entity.PublicServiceType;
import gr.eap.cpsvap.entity.Rule;
import gr.eap.cpsvap.entity.Sector;
import gr.eap.cpsvap.entity.ThematicArea;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.entity.helper.ProcessingTimeType;
import gr.eap.cpsvap.entity.helper.ProcessingTimeUnit;
import gr.eap.cpsvap.service.ChannelManager;
import gr.eap.cpsvap.service.ConseptManager;
import gr.eap.cpsvap.service.ContactPointManager;
import gr.eap.cpsvap.service.CostManager;
import gr.eap.cpsvap.service.CriterionRequirementManager;
import gr.eap.cpsvap.service.DurationManager;
import gr.eap.cpsvap.service.EventManager;
import gr.eap.cpsvap.service.EvidenceManager;
import gr.eap.cpsvap.service.LocationManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.service.OutputManager;
import gr.eap.cpsvap.service.ParticipationManager;
import gr.eap.cpsvap.service.PublicServiceDatasetManager;
import gr.eap.cpsvap.service.PublicServiceManager;
import gr.eap.cpsvap.service.PublicServiceStatusManager;
import gr.eap.cpsvap.service.PublicServiceTypeManager;
import gr.eap.cpsvap.service.RuleManager;
import gr.eap.cpsvap.service.SectorManager;
import gr.eap.cpsvap.service.ThematicAreaManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.PublicServiceCriteria;
import gr.eap.cpsvap.vo.criteria.PublicServiceStatusCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class PublicServiceAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(PublicServiceAction.class);
    //List of publicServices; Setter and Getter are below
    private List<PublicService> publicServices;
    private List<PublicServiceStatus> publicServiceStatuses;
    private List<ContactPoint> contactPoints;
    //PublicService object to be added; Setter and Getter are below
    private PublicService publicService;
    private List<NaturalLanguage> languages;
    private List<Agent> agents;
    private List<Event> events;
    private List<PublicService> services;
    private List<Participation> participations;
    private List<Cost> costs;
    private List<ProcessingTimeType> processingTimeTypes;
    private List<ProcessingTimeUnit> processingTimeUnits;
    private List<Channel> channels;  
    private List<Criterion> criterions;     
    private List<Rule> rules; 
    private List<Output> outputs;     
    private List<FormalFramework> formalFrameworks;
    private List<PublicOrganization> publicOrganizations;


    private List<Integer> selectedIds = new ArrayList<>();
    Integer requiresId;
    Integer relatedId;
    private String thematicAreaIds;
    private String typeIds;    
    private String languageIds;  
    private String eventIds;      
    private String sectorIds;
    private String participationIds;    
    private String evidenceIds;   
    private String outputIds;    
    private String costIds;     
    private String contactPointIds;
    private String datasetIds;   
    private String locationIds;     
    private String ruleIds;      
    private String criterionRequirementIds;     
    private String channelIds;        
    private String conseptIds;   
    private String requireIds;   
    private String relationIds;     
    
    PublicServiceCriteria criteria = new PublicServiceCriteria();
    private PublicServiceManager publicServiceManager;
    private NaturalLanguageManager naturalLanguageManager;
    private ThematicAreaManager thematicAreaManager; 
    private PublicServiceTypeManager publicServiceTypeManager;    
    private SectorManager sectorManager;   
    private PublicServiceStatusManager publicServiceStatusManager;       
    private EventManager eventManager;
    private ParticipationManager participationManager; 
    private EvidenceManager evidenceManager;   
    private OutputManager outputManager;   
    private CostManager costManager;       
    private ContactPointManager contactPointManager;    
    private PublicServiceDatasetManager publicServiceDatasetManager;  
    private LocationManager locationManager;      
    private RuleManager ruleManager;    
    private DurationManager durationManager;    
    private CriterionRequirementManager criterionRequirementManager;        
    private ChannelManager channelManager;    
    private ConseptManager conseptManager;     
    

    @Override
    public void prepare() throws Exception {
       languages = naturalLanguageManager.list(new NaturalLanguageCriteria());
       publicServiceStatuses = publicServiceStatusManager.list(new PublicServiceStatusCriteria());

    }

    public String execute() {

        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (PublicServiceCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new PublicServiceCriteria();
        }
        totalItems = publicServiceManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        publicServices = publicServiceManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new PublicServiceCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        services = publicServiceManager.list(new PublicServiceCriteria());
        publicService = new PublicService();
        return INPUT;
    }

    public String edit() {
        publicService = publicServiceManager.get(getSelected());
        if (publicService == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        PublicServiceCriteria psCriteria = new PublicServiceCriteria();
        psCriteria.getNotIds().add(publicService.getId());
        services = publicServiceManager.list(psCriteria);
        /*       if (!publicService.getRequires().isEmpty()) {
            Object[] requires = publicService.getRequires().toArray();
            PublicService l = (PublicService) requires[0];
            requiresId = l.getId();
        }
        if (!publicService.getRelated().isEmpty()) {
            Object[] related = publicService.getRelated().toArray();
            PublicService l = (PublicService) related[0];
            relatedId = l.getId();
        }        */
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        publicServiceManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (publicService.getStatus().getId() != null) {
            publicService.setStatus(publicServiceStatusManager.get(publicService.getStatus().getId()));
        } else {
            publicService.setStatus(null);
        } 
        
        Duration duration;
        if (publicService.getProcessingTime().getId() != null && 
                publicService.getProcessingTime().getId() > 0) {
            duration = durationManager.get(publicService.getProcessingTime().getId());
        } else {
            duration = new Duration();
        }

        duration.setDuration(publicService.getProcessingTime().getDuration());
        durationManager.save(duration);
        publicService.setProcessingTime(duration);
                 
        if (thematicAreaIds != null && thematicAreaIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(thematicAreaIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                ThematicArea thematicArea = thematicAreaManager.get(id);
                if (thematicArea != null) {
                    publicService.getThematicAreas().add(thematicArea);
                }
            }
        }        
        if (typeIds != null && typeIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(typeIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                PublicServiceType type = publicServiceTypeManager.get(id);
                if (type != null) {
                    publicService.getTypes().add(type);
                }
            }
        }     
        if (languageIds != null && languageIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(languageIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                NaturalLanguage language = naturalLanguageManager.get(id);
                if (language != null) {
                    publicService.getLanguages().add(language);
                }
            }
        } 
        if (eventIds != null && eventIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(eventIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Event event = eventManager.get(id);                
                if (event != null) {
                    publicService.getIsGroupedBy().add(event);
                }
            }
        } 
        if (participationIds != null && participationIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(participationIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Participation participation = participationManager.get(id);                
                if (participation != null) {
                    publicService.getHasParticipation().add(participation);
                }
            }
        }         
        if (sectorIds != null && sectorIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(sectorIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Sector sector = sectorManager.get(id);
                if (sector != null) {
                    publicService.getSectors().add(sector);
                }
            }
        }
        if (evidenceIds != null && evidenceIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(evidenceIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Evidence evidence = evidenceManager.get(id);
                if (evidence != null) {
                    publicService.getHasInput().add(evidence);
                }
            }
        }    
        if (outputIds != null && outputIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(outputIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Output output = outputManager.get(id);
                if (output != null) {
                    publicService.getProduces().add(output);
                }
            }
        }    
        if (costIds != null && costIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(costIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Cost cost = costManager.get(id);
                if (cost != null) {
                    publicService.getHasCost().add(cost);
                }
            }
        }          
        if (contactPointIds != null && contactPointIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(contactPointIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                ContactPoint contactPoint = contactPointManager.get(id);
                if (contactPoint != null) {
                    publicService.getHasContactPoint().add(contactPoint);
                }
            }
        }      
        if (datasetIds != null && datasetIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(datasetIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                PublicServiceDataset publicServiceDataset = publicServiceDatasetManager.get(id);
                if (publicServiceDataset != null) {
                    publicService.getIsDescribedAt().add(publicServiceDataset);
                }
            }
        }    
        
        if (locationIds != null && locationIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(locationIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Location location = locationManager.get(id);
                if (location != null) {
                    publicService.getSpatial().add(location);
                }
            }
        }          
        if (ruleIds != null && ruleIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(ruleIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Rule rule = ruleManager.get(id);
                if (rule != null) {
                    publicService.getFollows().add(rule);
                }
            }
        }  
        if (criterionRequirementIds != null && criterionRequirementIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(criterionRequirementIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                CriterionRequirement criterionRequirement = criterionRequirementManager.get(id);
                if (criterionRequirement != null) {
                    publicService.getHasCriterion().add(criterionRequirement);
                }
            }
        }    
        if (channelIds != null && channelIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(channelIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Channel channel = channelManager.get(id);
                if (channel != null) {
                    publicService.getHasChannel().add(channel);
                }
            }
        }   
         if (conseptIds != null && conseptIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(conseptIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Consept consept = conseptManager.get(id);
                if (consept != null) {
                    publicService.getIsClassifiedBy().add(consept);
                }
            }
        } 
         if (requireIds != null && requireIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(requireIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                PublicService require = publicServiceManager.get(id);
                if (require != null) {
                    publicService.getRequires().add(require);
                }
            }
        }  
         if (relationIds != null && relationIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(relationIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                PublicService require = publicServiceManager.get(id);
                if (require != null) {
                    publicService.getRelation().add(require);
                }
            }
        }           
        publicServiceManager.save(publicService); 
        String message = "Message:PublicService successfully saved.";
        addActionMessage(message);
    }



    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (publicService != null && publicService.getId() != null) {
            selected = publicService.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters
     *
     **********
     * @param publicServices
     */
    public void setPublicServices(List<PublicService> publicServices) {
        this.publicServices = publicServices;
    }

    public List<PublicService> getPublicServices() {
        return publicServices;
    }

    public PublicService getPublicService() {
        return publicService;
    }

    public void setPublicService(PublicService publicService) {
        this.publicService = publicService;
    }

    public PublicServiceCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(PublicServiceCriteria criteria) {
        this.criteria = criteria;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public void setLanguages(List<NaturalLanguage> languages) {
        this.languages = languages;
    }

    public List<PublicServiceStatus> getPublicServiceStatuses() {
        return publicServiceStatuses;
    }

    public String getThematicAreaIds() {
        return thematicAreaIds;
    }

    public void setThematicAreaIds(String thematicAreaIds) {
        this.thematicAreaIds = thematicAreaIds;
    }

    public String getTypeIds() {
        return typeIds;
    }

    public void setTypeIds(String typeIds) {
        this.typeIds = typeIds;
    }

    public String getLanguageIds() {
        return languageIds;
    }

    public void setLanguageIds(String languageIds) {
        this.languageIds = languageIds;
    }

    public String getEventIds() {
        return eventIds;
    }

    public void setEventIds(String eventIds) {
        this.eventIds = eventIds;
    }

    public String getParticipationIds() {
        return participationIds;
    }

    public void setParticipationIds(String participationIds) {
        this.participationIds = participationIds;
    }

    
    public String getSectorIds() {
        return sectorIds;
    }

    public void setSectorIds(String sectorIds) {
        this.sectorIds = sectorIds;
    }

    public String getEvidenceIds() {
        return evidenceIds;
    }

    public void setEvidenceIds(String evidenceIds) {
        this.evidenceIds = evidenceIds;
    }

    public String getOutputIds() {
        return outputIds;
    }

    public void setOutputIds(String outputIds) {
        this.outputIds = outputIds;
    }

    public String getCostIds() {
        return costIds;
    }

    public void setCostIds(String costIds) {
        this.costIds = costIds;
    }

    public String getContactPointIds() {
        return contactPointIds;
    }

    public void setContactPointIds(String contactPointIds) {
        this.contactPointIds = contactPointIds;
    }

    public String getDatasetIds() {
        return datasetIds;
    }

    public void setDatasetIds(String datasetIds) {
        this.datasetIds = datasetIds;
    }

    public String getLocationIds() {
        return locationIds;
    }

    public void setLocationIds(String locationIds) {
        this.locationIds = locationIds;
    }

    public String getRuleIds() {
        return ruleIds;
    }

    public void setRuleIds(String ruleIds) {
        this.ruleIds = ruleIds;
    }

    public String getChannelIds() {
        return channelIds;
    }

    public void setChannelIds(String channelIds) {
        this.channelIds = channelIds;
    }

    public String getConseptIds() {
        return conseptIds;
    }

    public void setConseptIds(String conseptIds) {
        this.conseptIds = conseptIds;
    }

    public String getRequireIds() {
        return requireIds;
    }

    public void setRequireIds(String requireIds) {
        this.requireIds = requireIds;
    }

    public String getRelationIds() {
        return relationIds;
    }

    public void setRelationIds(String relationIds) {
        this.relationIds = relationIds;
    }

       
    public List<ContactPoint> getContactPoints() {
        return contactPoints;
    }

    public List<Agent> getAgents() {
        return agents;
    }

    public List<Event> getEvents() {
        return events;
    }

    public List<PublicService> getServices() {
        return services;
    }

    public List<Participation> getParticipations() {
        return participations;
    }

    public List<Cost> getCosts() {
        return costs;
    }    
    

    public List<ProcessingTimeType> getProcessingTimeTypes() {
        return processingTimeTypes;
    }

    public List<ProcessingTimeUnit> getProcessingTimeUnits() {
        return processingTimeUnits;
    }

    public List<Criterion> getCriterions() {
        return criterions;
    }

    public List<Channel> getChannels() {
        return channels;
    }

    public List<FormalFramework> getFormalFrameworks() {
        return formalFrameworks;
    }

    public List<Output> getOutputs() {
        return outputs;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public String getCriterionRequirementIds() {
        return criterionRequirementIds;
    }

    public void setCriterionRequirementIds(String criterionRequirementIds) {
        this.criterionRequirementIds = criterionRequirementIds;
    }

    public List<PublicOrganization> getPublicOrganizations() {
        return publicOrganizations;
    }

    
    public List<Integer> getSelectedIds() {
        return selectedIds;
    }
    

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    public Integer getRequiresId() {
        return requiresId;
    }

    public void setRequiresId(Integer requiresId) {
        this.requiresId = requiresId;
    }

    public Integer getRelatedId() {
        return relatedId;
    }

    public void setRelatedId(Integer relatedId) {
        this.relatedId = relatedId;
    }

    /**
     * ********* Spring
     *
     *********
     * @param publicServiceManager
     */
    public void setPublicServiceManager(PublicServiceManager publicServiceManager) {
        this.publicServiceManager = publicServiceManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }

    public void setThematicAreaManager(ThematicAreaManager thematicAreaManager) {
        this.thematicAreaManager = thematicAreaManager;
    }  
    
    public void setPublicServiceTypeManager(PublicServiceTypeManager publicServiceTypeManager) {
        this.publicServiceTypeManager = publicServiceTypeManager;
    }    
    
    public void setSectorManager(SectorManager sectorManager) {
        this.sectorManager = sectorManager;
    } 
    
    public void setPublicServiceStatusManager(PublicServiceStatusManager publicServiceStatusManager) {
        this.publicServiceStatusManager = publicServiceStatusManager;
    }
    
    public void setEventManager(EventManager eventManager) {
        this.eventManager = eventManager;
    }     
    
    public void setParticipationManager(ParticipationManager participationManager) {
        this.participationManager = participationManager;
    }        
    
    public void setEvidenceManager(EvidenceManager evidenceManager) {
        this.evidenceManager = evidenceManager;
    }   
    
    public void setOutputManager(OutputManager outputManager) {
        this.outputManager = outputManager;
    }       
    
    public void setCostManager(CostManager costManager) {
        this.costManager = costManager;
    }         
    
    public void setContactPointManager(ContactPointManager contactPointManager) {
        this.contactPointManager = contactPointManager;
    }       

    public void setPublicServiceDatasetManager(PublicServiceDatasetManager publicServiceDatasetManager) {
        this.publicServiceDatasetManager = publicServiceDatasetManager;
    }
    
    public void setLocationManager(LocationManager locationManager) {
        this.locationManager = locationManager;
    }    
    
    public void setRuleManager(RuleManager ruleManager) {
        this.ruleManager = ruleManager;
    }    
    
    public void setDurationManager(DurationManager durationManager) {
        this.durationManager = durationManager;
    }    
    
    public void setCriterionRequirementManager(CriterionRequirementManager criterionRequirementManager) {
        this.criterionRequirementManager = criterionRequirementManager;
    }    
    
    public void setChannelManager(ChannelManager channelManager) {
        this.channelManager = channelManager;
    }      
    
    public void setConseptManager(ConseptManager conseptManager) {
        this.conseptManager = conseptManager;
    }       
}
