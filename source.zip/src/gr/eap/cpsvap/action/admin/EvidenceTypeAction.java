package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.EvidenceType;
import gr.eap.cpsvap.service.EvidenceTypeManager;
import gr.eap.cpsvap.vo.criteria.EvidenceTypeCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class EvidenceTypeAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(EvidenceTypeAction.class);
    //List of evidenceTypes; Setter and Getter are below
    private List<EvidenceType> evidenceTypes;
    //EvidenceType object to be added; Setter and Getter are below
    private EvidenceType evidenceType;
    private List<Integer> selectedIds = new ArrayList<>();
    
    EvidenceTypeCriteria criteria = new EvidenceTypeCriteria();
    private EvidenceTypeManager evidenceTypeManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (EvidenceTypeCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new EvidenceTypeCriteria();
        }
        
        totalItems = evidenceTypeManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        evidenceTypes = evidenceTypeManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new EvidenceTypeCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        evidenceType = new EvidenceType();
        return INPUT;
    }

    public String edit() {
        evidenceType = evidenceTypeManager.get(getSelected());
        if (evidenceType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        evidenceTypeManager.delete(getSelected());

        if (evidenceType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        evidenceTypeManager.save(evidenceType);
        String message = "Message:EvidenceType successfully saved.";
        addActionMessage(message);
    }


    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (evidenceType != null && evidenceType.getId() != null) {
            selected = evidenceType.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setEvidenceTypes(List<EvidenceType> evidenceTypes) {
        this.evidenceTypes = evidenceTypes;
    }
    
    public List<EvidenceType> getEvidenceTypes() {
        return evidenceTypes;
    }    

    public EvidenceType getEvidenceType() {
        return evidenceType;
    }

    public void setEvidenceType(EvidenceType evidenceType) {
        this.evidenceType = evidenceType;
    }

    public EvidenceTypeCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(EvidenceTypeCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param evidenceTypeManager
     */
    public void setEvidenceTypeManager(EvidenceTypeManager evidenceTypeManager) {
        this.evidenceTypeManager = evidenceTypeManager;
    }

}
