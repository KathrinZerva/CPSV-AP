package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.ChannelType;
import gr.eap.cpsvap.service.ChannelTypeManager;
import gr.eap.cpsvap.vo.criteria.ChannelTypeCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class ChannelTypeAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(ChannelTypeAction.class);
    //List of channelTypes; Setter and Getter are below
    private List<ChannelType> channelTypes;
    //ChannelType object to be added; Setter and Getter are below
    private ChannelType channelType;
    private List<Integer> selectedIds = new ArrayList<>();
    
    ChannelTypeCriteria criteria = new ChannelTypeCriteria();
    private ChannelTypeManager channelTypeManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (ChannelTypeCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new ChannelTypeCriteria();
        }
        totalItems = channelTypeManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        channelTypes = channelTypeManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new ChannelTypeCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        channelType = new ChannelType();
        return INPUT;
    }

    public String edit() {
        channelType = channelTypeManager.get(getSelected());
        if (channelType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        channelTypeManager.delete(getSelected());

        if (channelType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        channelTypeManager.save(channelType);
        String message = "Message:ChannelType successfully saved.";
        addActionMessage(message);
    }


    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (channelType != null && channelType.getId() != null) {
            selected = channelType.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setChannelTypes(List<ChannelType> channelTypes) {
        this.channelTypes = channelTypes;
    }
    
    public List<ChannelType> getChannelTypes() {
        return channelTypes;
    }    

    public ChannelType getChannelType() {
        return channelType;
    }

    public void setChannelType(ChannelType channelType) {
        this.channelType = channelType;
    }

    public ChannelTypeCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(ChannelTypeCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param channelTypeManager
     */
    public void setChannelTypeManager(ChannelTypeManager channelTypeManager) {
        this.channelTypeManager = channelTypeManager;
    }

}
