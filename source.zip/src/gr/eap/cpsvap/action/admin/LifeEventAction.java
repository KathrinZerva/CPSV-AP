package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.LifeEvent;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.LifeEventCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.LifeEventManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

public class LifeEventAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(LifeEventAction.class);
    //List of lifeEvents; Setter and Getter are below
    private List<LifeEvent> lifeEvents;
    private List<NaturalLanguage> languages;    
    //LifeEvent object to be added; Setter and Getter are below
    private LifeEvent lifeEvent;
    private List<Integer> selectedIds = new ArrayList<>();

    LifeEventCriteria criteria = new LifeEventCriteria();
    //LifeEvent manager injected by spring context; This is cool !!
    private LifeEventManager lifeEventManager;
    private NaturalLanguageManager naturalLanguageManager;
    

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());        
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (LifeEventCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new LifeEventCriteria();
        }
        totalItems = lifeEventManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        lifeEvents = lifeEventManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new LifeEventCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        lifeEvent = new LifeEvent();
        return INPUT;
    }

    public String edit() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (lifeEvent != null && lifeEvent.getId() != null) {
            selected = lifeEvent.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        lifeEvent = lifeEventManager.get(selected);
        if (lifeEvent == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (lifeEvent != null && lifeEvent.getId() != null) {
            selected = lifeEvent.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        lifeEventManager.delete(selected);
        
        if (lifeEvent == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        lifeEventManager.save(lifeEvent);
        String message = "Message:LifeEvent successfully saved.";
        addActionMessage(message);
    }

    /**
     * ********* Getters Setters **********
     */
    public List<LifeEvent> getLifeEvents() {
        return lifeEvents;
    }

    public void setLifeEventes(List<LifeEvent> lifeEvents) {
        this.lifeEvents = lifeEvents;
    }

    public LifeEvent getLifeEvent() {
        return lifeEvent;
    }

    public void setLifeEvent(LifeEvent lifeEvent) {
        this.lifeEvent = lifeEvent;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public LifeEventCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(LifeEventCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param lifeEventManager
     */
    public void setLifeEventManager(LifeEventManager lifeEventManager) {
        this.lifeEventManager = lifeEventManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
}
