package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.entity.Organization;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.entity.PublicService;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.CriterionManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.PublicOrganizationManager;
import gr.eap.cpsvap.service.PublicServiceManager;
import gr.eap.cpsvap.service.RequirementResponceManager;
import gr.eap.cpsvap.vo.criteria.CriterionCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;
import gr.eap.cpsvap.vo.criteria.PublicServiceCriteria;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;

public class PublicOrganizationAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(PublicOrganizationAction.class);
    //List of organizations; Setter and Getter are below
    private List<PublicOrganization> publicOrganizations;
    private List<NaturalLanguage> languages;   
    private List<PublicService> publicServices;    
    private List<Criterion> criterions;
    private List<RequirementResponce> requirementResponces;      
    //PublicOrganization object to be added; Setter and Getter are below
    private PublicOrganization publicOrganization;
    private List<Integer> selectedIds = new ArrayList<>();

    PublicOrganizationCriteria criteria = new PublicOrganizationCriteria();
    //PublicOrganization manager injected by spring context; This is cool !!
    private PublicOrganizationManager publicOrganizationManager;
    private NaturalLanguageManager naturalLanguageManager;
    private PublicServiceManager publicServiceManager;    
    private CriterionManager criterionManager;
    private RequirementResponceManager requirementResponceManager;
    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria()); 
        criterions = criterionManager.list(new CriterionCriteria());  
        requirementResponces = requirementResponceManager.list(new RequirementResponceCriteria());          
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (PublicOrganizationCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new PublicOrganizationCriteria();
        }
        totalItems = publicOrganizationManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        publicOrganizations = publicOrganizationManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new PublicOrganizationCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        publicOrganizations = publicOrganizationManager.list(new PublicOrganizationCriteria());
        publicOrganization = new PublicOrganization();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        publicOrganization = publicOrganizationManager.get(selected);        
        PublicOrganizationCriteria poCriteria = new PublicOrganizationCriteria();
        poCriteria.getNotIds().add(publicOrganization.getId());       
        publicOrganizations = publicOrganizationManager.list(poCriteria);        
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

       Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        publicOrganizationManager.delete(selected);
        return list();
    }

    private void saveLocal() {
                
        if (publicOrganization.getSubOrganization().getId() != null) {
            publicOrganization.setSubOrganization(publicOrganizationManager.get(publicOrganization.getSubOrganization().getId()));
        } else {
            publicOrganization.setSubOrganization(null);
        }  
        if (publicOrganization.getSubOrganizationOf().getId() != null) {
            publicOrganization.setSubOrganizationOf(publicOrganizationManager.get(publicOrganization.getSubOrganizationOf().getId()));
        } else {
            publicOrganization.setSubOrganizationOf(null);
        }      
        if (publicOrganization.getHasUnit().getId() != null) {
            publicOrganization.setHasUnit(publicOrganizationManager.get(publicOrganization.getHasUnit().getId()));
        } else {
            publicOrganization.setHasUnit(null);
        }     
        if (publicOrganization.getUnitOf().getId() != null) {
            publicOrganization.setUnitOf(publicOrganizationManager.get(publicOrganization.getUnitOf().getId()));
        } else {
            publicOrganization.setUnitOf(null);
        }          
        if (publicOrganization.getHasMember().getId() != null) {
            publicOrganization.setHasMember(publicOrganizationManager.get(publicOrganization.getHasMember().getId()));
        } else {
            publicOrganization.setHasMember(null);
        } 
         if (publicOrganization.getMemberOf().getId() != null) {
            publicOrganization.setMemberOf(publicOrganizationManager.get(publicOrganization.getMemberOf().getId()));
        } else {
            publicOrganization.setMemberOf(null);
        }         
         if (publicOrganization.getPrev().getId() != null) {
            publicOrganization.setPrev(publicOrganizationManager.get(publicOrganization.getPrev().getId()));
        } else {
            publicOrganization.setPrev(null);
        }     
         if (publicOrganization.getNext().getId() != null) {
            publicOrganization.setNext(publicOrganizationManager.get(publicOrganization.getNext().getId()));
        } else {
            publicOrganization.setNext(null);
        }            
         
        
/*         if (publicOrganization.getPlaysRole().getId() != null) {
            publicOrganization.setPlaysRole(publicServiceManager.get(publicOrganization.getPlaysRole().getId()));
        } else {
            publicOrganization.setPlaysRole(null);
        }
       if (publicOrganization.getUses().getId() != null) {
            publicOrganization.setUses(publicServiceManager.get(publicOrganization.getUses().getId()));
        } else {
            publicOrganization.setUses(null);
        }        
*/        
        if (publicOrganization.getSatisfiesCriterion().getId() != null) {
            publicOrganization.setSatisfiesCriterion(criterionManager.get(publicOrganization.getSatisfiesCriterion().getId()));
        } else {
            publicOrganization.setSatisfiesCriterion(null);
        }  
//        if (publicOrganization.getProvidesRequirementResponse().getId() != null) {
//            publicOrganization.setProvidesRequirementResponse(requirementResponceManager.get(publicOrganization.getProvidesRequirementResponse().getId()));
//        } else {
//            publicOrganization.setProvidesRequirementResponse(null);
//        } 
        publicOrganizationManager.save(publicOrganization);
        String message = "Message:PublicOrganization successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (publicOrganization != null && publicOrganization.getId() != null) {
            selected = publicOrganization.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    /**
     * ********* Getters Setters **********
     */
    public List<PublicOrganization> getPublicOrganizations() {
        return publicOrganizations;
    }

    public void setPublicOrganizations(List<PublicOrganization> publicOrganizations) {
        this.publicOrganizations = publicOrganizations;
    }

    public PublicOrganization getPublicOrganization() {
        return publicOrganization;
    }

    public void setPublicOrganization(PublicOrganization publicOrganization) {
        this.publicOrganization = publicOrganization;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<PublicService> getPublicServices() {
        return publicServices;
    }

    public List<Criterion> getCriterions() {
        return criterions;
    }

    public List<RequirementResponce> getRequirementResponces() {
        return requirementResponces;
    }
    

    public PublicOrganizationCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(PublicOrganizationCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param publicOrganizationManager
     */
    public void setPublicOrganizationManager(PublicOrganizationManager publicOrganizationManager) {
        this.publicOrganizationManager = publicOrganizationManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
    
    public void setCriterionManager(CriterionManager criterionManager) {
        this.criterionManager = criterionManager;
    }
    
    public void setRequirementResponceManager(RequirementResponceManager requirementResponceManager) {
        this.requirementResponceManager = requirementResponceManager;
    }    
}
