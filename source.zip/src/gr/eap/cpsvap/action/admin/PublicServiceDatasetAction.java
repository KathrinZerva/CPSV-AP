package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.common.helper.StringToIds;
import gr.eap.cpsvap.entity.Agent;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.entity.PublicServiceDataset;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.AgentManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.PublicServiceDatasetManager;
import gr.eap.cpsvap.vo.criteria.AgentCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.PublicServiceDatasetCriteria;

public class PublicServiceDatasetAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(PublicServiceDatasetAction.class);
    //List of evidences; Setter and Getter are below
    private List<PublicServiceDataset> publicServiceDatasets;
    private List<NaturalLanguage> languages;  
    private List<Agent> agents;    
    
    //PublicServiceDataset object to be added; Setter and Getter are below
    private PublicServiceDataset publicServiceDataset;
    private List<Integer> selectedIds = new ArrayList<>();
    
    PublicServiceDatasetCriteria criteria = new PublicServiceDatasetCriteria();
    //PublicServiceDataset manager injected by spring context; This is cool !!
    private PublicServiceDatasetManager publicServiceDatasetManager;
    private NaturalLanguageManager naturalLanguageManager;
    private AgentManager agentManager;

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria()); 
        agents = agentManager.list(new AgentCriteria()); 
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (PublicServiceDatasetCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new PublicServiceDatasetCriteria();
        }
        totalItems = publicServiceDatasetManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        publicServiceDatasets = publicServiceDatasetManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new PublicServiceDatasetCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        publicServiceDataset = new PublicServiceDataset();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        publicServiceDataset = publicServiceDatasetManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

       Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        publicServiceDatasetManager.delete(selected);
        return list();
    }

    private void saveLocal() {  
        if (publicServiceDataset.getPublisher().getId() != null) {
            publicServiceDataset.setPublisher(agentManager.get(publicServiceDataset.getPublisher().getId()));
        } else {
            publicServiceDataset.setPublisher(null);
        }         
        publicServiceDatasetManager.save(publicServiceDataset);
        String message = "Message:PublicServiceDataset successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (publicServiceDataset != null && publicServiceDataset.getId() != null) {
            selected = publicServiceDataset.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    /**
     * ********* Getters Setters **********
     */
    public List<PublicServiceDataset> getPublicServiceDatasets() {
        return publicServiceDatasets;
    }

    public void setPublicServiceDatasets(List<PublicServiceDataset> publicServiceDatasets) {
        this.publicServiceDatasets = publicServiceDatasets;
    }

    public PublicServiceDataset getPublicServiceDataset() {
        return publicServiceDataset;
    }

    public void setPublicServiceDataset(PublicServiceDataset publicServiceDataset) {
        this.publicServiceDataset = publicServiceDataset;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<Agent> getAgents() {
        return agents;
    }


    public PublicServiceDatasetCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(PublicServiceDatasetCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param publicServiceDatasetManager
     */
    public void setPublicServiceDatasetManager(PublicServiceDatasetManager publicServiceDatasetManager) {
        this.publicServiceDatasetManager = publicServiceDatasetManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
    
    public void setAgentManager(AgentManager agentManager) {
        this.agentManager = agentManager;
    }
}
