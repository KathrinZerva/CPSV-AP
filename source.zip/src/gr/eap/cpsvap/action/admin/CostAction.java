package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.common.helper.StringToIds;
import gr.eap.cpsvap.entity.Consept;
import gr.eap.cpsvap.entity.Cost;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.entity.helper.Currency;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.ConseptManager;
import gr.eap.cpsvap.service.CurrencyManager;
import gr.eap.cpsvap.vo.criteria.CostCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.CostManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.service.PublicOrganizationManager;
import gr.eap.cpsvap.vo.criteria.ConseptCriteria;
import gr.eap.cpsvap.vo.criteria.CurrencyCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

public class CostAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(CostAction.class);
    //List of costs; Setter and Getter are below
    private List<Cost> costs;
    private List<Currency> currencies;
    private List<Consept> types;
    private List<NaturalLanguage> languages;
    private String publicOrganizationIds;

    //Cost object to be added; Setter and Getter are below
    private Cost cost;
    private List<Integer> selectedIds = new ArrayList<>();

    CostCriteria criteria = new CostCriteria();
    //Cost manager injected by spring context; This is cool !!
    private CostManager costManager;
    private CurrencyManager currencyManager;
    private ConseptManager conseptManager;    
    private PublicOrganizationManager publicOrganizationManager;
    private NaturalLanguageManager naturalLanguageManager;

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        currencies = currencyManager.list(new CurrencyCriteria());
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());
        types = conseptManager.list(new ConseptCriteria());        
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (CostCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new CostCriteria();
        }
        totalItems = costManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        costs = costManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new CostCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        cost = new Cost();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        cost = costManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        costManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (cost.getCurrency().getId() != null) {
            cost.setCurrency(currencyManager.get(cost.getCurrency().getId()));
        } else {
            cost.setCurrency(null);
        }
        if (cost.getType().getId() != null) {
            cost.setType(conseptManager.get(cost.getType().getId()));
        } else {
            cost.setType(null);
        }        
        if (publicOrganizationIds != null && publicOrganizationIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(publicOrganizationIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                PublicOrganization publicOrganization = publicOrganizationManager.get(id);
                if (publicOrganization != null) {
                    cost.getIsDefinedBy().add(publicOrganization);
                }
            }
        }
        costManager.save(cost);
        String message = "Message:Cost successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (cost != null && cost.getId() != null) {
            selected = cost.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public List<Cost> getCosts() {
        return costs;
    }

    public void setCosts(List<Cost> costs) {
        this.costs = costs;
    }

    public Cost getCost() {
        return cost;
    }

    public void setCost(Cost cost) {
        this.cost = cost;
    }

    public List<Currency> getCurrencies() {
        return currencies;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public String getPublicOrganizationIds() {
        return publicOrganizationIds;
    }

    public void setPublicOrganizationIds(String publicOrganizationIds) {
        this.publicOrganizationIds = publicOrganizationIds;
    }

    public List<Consept> getTypes() {
        return types;
    }

    public void setTypes(List<Consept> types) {
        this.types = types;
    }

    public CostCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(CostCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param costManager
     */
    public void setCostManager(CostManager costManager) {
        this.costManager = costManager;
    }

    public void setCurrencyManager(CurrencyManager currencyManager) {
        this.currencyManager = currencyManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }

    public void setPublicOrganizationManager(PublicOrganizationManager publicOrganizationManager) {
        this.publicOrganizationManager = publicOrganizationManager;
    }
    public void setConseptManager(ConseptManager conseptManager) {
        this.conseptManager = conseptManager;
    }    
    
    
}
