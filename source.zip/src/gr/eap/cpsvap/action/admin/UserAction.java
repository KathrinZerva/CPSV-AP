package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.common.Constants;
import java.util.ArrayList;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.entity.User;
import gr.eap.cpsvap.service.UserManager;
import gr.eap.cpsvap.vo.criteria.UserCriteria;
import java.util.List;
import org.apache.log4j.Logger;
        
        
public class UserAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(UserAction.class);
    //List of users; Setter and Getter are below
    private List<User> users;
    //User object to be added; Setter and Getter are below
    private User user;
    private List<Integer> selectedIds = new ArrayList<>();

    UserCriteria criteria = new UserCriteria();
    //User manager injected by spring context; This is cool !!
    private UserManager userManager;

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (UserCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new UserCriteria();
        }
        totalItems = userManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        users = userManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new UserCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }
    public String create() {
        user = new User();
        return INPUT;
    }

    public String edit() {

        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (user != null && user.getId() != null) {
            selected = user.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        user = userManager.get(selected);
        if (user == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (user != null && user.getId() != null) {
            selected = user.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        userManager.delete(selected);
        if (user == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        userManager.save(user);
        String message = "Message:User successfully saved.";
        addActionMessage(message);
    }

    /**
     * ********* Getters Setters **********
     */
    public List<User> getUsers() {
        return users;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }


    public UserCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(UserCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     */
    public void setUserManager(UserManager userManager) {
        this.userManager = userManager;
    }

}
