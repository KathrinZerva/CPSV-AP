package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.entity.Jurisdiction;
import gr.eap.cpsvap.entity.Location;
import gr.eap.cpsvap.entity.Person;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.CriterionManager;
import gr.eap.cpsvap.service.JurisdictionManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.PersonCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.PersonManager;
import gr.eap.cpsvap.service.LocationManager;
import gr.eap.cpsvap.service.RequirementResponceManager;
import gr.eap.cpsvap.vo.criteria.CriterionCriteria;
import gr.eap.cpsvap.vo.criteria.JurisdictionCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;

public class PersonAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(PersonAction.class);
    //List of persons; Setter and Getter are below
    private List<Person> persons;
    private List<NaturalLanguage> languages;
    private List<Jurisdiction> jurisdictions;
    private List<Criterion> criterions;
    private List<RequirementResponce> requirementResponces;
    
    //Person object to be added; Setter and Getter are below
    private Person person;
    private List<Integer> selectedIds = new ArrayList<>();

    PersonCriteria criteria = new PersonCriteria();
    //Person manager injected by spring context; This is cool !!
    private PersonManager personManager;
    private NaturalLanguageManager naturalLanguageManager;
    private JurisdictionManager jurisdictionManager;
    private LocationManager locationManager;
    private CriterionManager criterionManager;
    private RequirementResponceManager requirementResponceManager;

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());
        jurisdictions = jurisdictionManager.list(new JurisdictionCriteria());
        criterions = criterionManager.list(new CriterionCriteria());  
        requirementResponces = requirementResponceManager.list(new RequirementResponceCriteria());         
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (PersonCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new PersonCriteria();
        }
        totalItems = personManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        persons = personManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new PersonCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        person = new Person();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        person = personManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        personManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (person.getCitizenship().getId() != null) {
            person.setCitizenship(jurisdictionManager.get(person.getCitizenship().getId()));
        } else {
            person.setCitizenship(null);
        }
        if (person.getResidency().getId() != null) {
            person.setResidency(jurisdictionManager.get(person.getResidency().getId()));
        } else {
            person.setResidency(null);
        }
        if (person.getSatisfiesCriterion().getId() != null) {
            person.setSatisfiesCriterion(criterionManager.get(person.getSatisfiesCriterion().getId()));
        } else {
            person.setSatisfiesCriterion(null);
        }  
//        if (person.getProvidesRequirementResponse().getId() != null) {
//            person.setProvidesRequirementResponse(requirementResponceManager.get(person.getProvidesRequirementResponse().getId()));
//        } else {
//            person.setProvidesRequirementResponse(null);
//        }          
        
        
        
        Location countryOfBirth = person.getCountryOfBirth();
        locationManager.save(countryOfBirth);
        person.setCountryOfBirth(countryOfBirth);
        
        Location countryOfDeath = person.getCountryOfDeath();
        locationManager.save(countryOfDeath);
        person.setCountryOfDeath(countryOfDeath);          
        
        Location placeOfBirth = person.getPlaceOfBirth();
        locationManager.save(placeOfBirth);
        person.setPlaceOfBirth(placeOfBirth);
        
        Location placeOfDeath = person.getPlaceOfDeath();
        locationManager.save(placeOfDeath);
        person.setPlaceOfDeath(placeOfDeath);        
                
        personManager.save(person);
        String message = "Message:Person successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (person != null && person.getId() != null) {
            selected = person.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

 

    /**
     * ********* Getters Setters **********
     */
    public List<Person> getPersons() {
        return persons;
    }

    public void setPersones(List<Person> persons) {
        this.persons = persons;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<Jurisdiction> getJurisdictions() {
        return jurisdictions;
    }

    public List<Criterion> getCriterions() {
        return criterions;
    }

    public List<RequirementResponce> getRequirementResponces() {
        return requirementResponces;
    }

    public PersonCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(PersonCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param personManager
     */
    public void setPersonManager(PersonManager personManager) {
        this.personManager = personManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }

    public void setJurisdictionManager(JurisdictionManager jurisdictionManager) {
        this.jurisdictionManager = jurisdictionManager;
    }

    public void setLocationManager(LocationManager locationManager) {
        this.locationManager = locationManager;
    }
    
    public void setCriterionManager(CriterionManager criterionManager) {
        this.criterionManager = criterionManager;
    }
    
    public void setRequirementResponceManager(RequirementResponceManager requirementResponceManager) {
        this.requirementResponceManager = requirementResponceManager;
    }    

}
