package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class NaturalLanguageAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(NaturalLanguageAction.class);
    //List of naturalLanguages; Setter and Getter are below
    private List<NaturalLanguage> naturalLanguages;
    //NaturalLanguage object to be added; Setter and Getter are below
    private NaturalLanguage naturalLanguage;
    private List<Integer> selectedIds = new ArrayList<>();
    
    NaturalLanguageCriteria criteria = new NaturalLanguageCriteria();
    private NaturalLanguageManager naturalLanguageManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else if ("clone".equals(action)) {
            return clone();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (NaturalLanguageCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new NaturalLanguageCriteria();
        }
        totalItems = naturalLanguageManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        naturalLanguages = naturalLanguageManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new NaturalLanguageCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        naturalLanguage = new NaturalLanguage();
        return INPUT;
    }

    public String edit() {
        naturalLanguage = naturalLanguageManager.get(getSelected());
        if (naturalLanguage == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        naturalLanguageManager.delete(getSelected());

        if (naturalLanguage == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        naturalLanguageManager.save(naturalLanguage);
        String message = "Message:NaturalLanguage successfully saved.";
        addActionMessage(message);
    }

    public String clone() {
        naturalLanguage = naturalLanguageManager.get(getSelected());
        if (naturalLanguage == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        try {
            NaturalLanguage newNaturalLanguage = (NaturalLanguage) naturalLanguage.clone();
            newNaturalLanguage.setId(null);
            naturalLanguageManager.save(newNaturalLanguage);
            addActionMessage("Message:Event successfully copied.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list();
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (naturalLanguage != null && naturalLanguage.getId() != null) {
            selected = naturalLanguage.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setNaturalLanguages(List<NaturalLanguage> naturalLanguages) {
        this.naturalLanguages = naturalLanguages;
    }
    
    public List<NaturalLanguage> getNaturalLanguages() {
        return naturalLanguages;
    }    

    public NaturalLanguage getNaturalLanguage() {
        return naturalLanguage;
    }

    public void setNaturalLanguage(NaturalLanguage naturalLanguage) {
        this.naturalLanguage = naturalLanguage;
    }

    public NaturalLanguageCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(NaturalLanguageCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param naturalLanguageManager
     */
    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }

}
