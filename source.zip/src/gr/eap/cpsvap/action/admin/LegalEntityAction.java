package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.entity.LegalEntity;
import gr.eap.cpsvap.entity.Location;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.CriterionManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.LegalEntityCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.LegalEntityManager;
import gr.eap.cpsvap.service.LocationManager;
import gr.eap.cpsvap.service.RequirementResponceManager;
import gr.eap.cpsvap.vo.criteria.CriterionCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;

public class LegalEntityAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(LegalEntityAction.class);
    //List of legalEntitys; Setter and Getter are below
    private List<LegalEntity> legalEntities;
    private List<NaturalLanguage> languages;    
    private List<Criterion> criterions;
    private List<RequirementResponce> requirementResponces;      
    //LegalEntity object to be added; Setter and Getter are below
    private LegalEntity legalEntity;
    private List<Integer> selectedIds = new ArrayList<>();

    LegalEntityCriteria criteria = new LegalEntityCriteria();
    //LegalEntity manager injected by spring context; This is cool !!
    private LegalEntityManager legalEntityManager;
    private NaturalLanguageManager naturalLanguageManager;
    private LocationManager locationManager;    
    private CriterionManager criterionManager;
    private RequirementResponceManager requirementResponceManager;
    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());  
        criterions = criterionManager.list(new CriterionCriteria());  
        requirementResponces = requirementResponceManager.list(new RequirementResponceCriteria());         
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (LegalEntityCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new LegalEntityCriteria();
        }
        totalItems = legalEntityManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        legalEntities = legalEntityManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new LegalEntityCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        legalEntity = new LegalEntity();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        legalEntity = legalEntityManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        legalEntityManager.delete(selected);
         return list();
    }

    private void saveLocal() {
        if (legalEntity.getSatisfiesCriterion().getId() != null) {
            legalEntity.setSatisfiesCriterion(criterionManager.get(legalEntity.getSatisfiesCriterion().getId()));
        } else {
            legalEntity.setSatisfiesCriterion(null);
        }  
//        if (legalEntity.getProvidesRequirementResponse().getId() != null) {
//            legalEntity.setProvidesRequirementResponse(requirementResponceManager.get(legalEntity.getProvidesRequirementResponse().getId()));
//        } else {
//            legalEntity.setProvidesRequirementResponse(null);
//        }                 
        Location location = legalEntity.getLocation();
        locationManager.save(location);
        legalEntity.setLocation(location);
        
        legalEntityManager.save(legalEntity);
        String message = "Message:LegalEntity successfully saved.";
        addActionMessage(message);
    }

    
    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (legalEntity != null && legalEntity.getId() != null) {
            selected = legalEntity.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    /**
     * ********* Getters Setters **********
     */
    public List<LegalEntity> getLegalEntities() {
        return legalEntities;
    }

    public void setLegalEntities(List<LegalEntity> legalEntities) {
        this.legalEntities = legalEntities;
    }

    public LegalEntity getLegalEntity() {
        return legalEntity;
    }

    public void setLegalEntity(LegalEntity legalEntity) {
        this.legalEntity = legalEntity;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<Criterion> getCriterions() {
        return criterions;
    }

    public List<RequirementResponce> getRequirementResponces() {
        return requirementResponces;
    }

    public LegalEntityCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(LegalEntityCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param legalEntityManager
     */
    public void setLegalEntityManager(LegalEntityManager legalEntityManager) {
        this.legalEntityManager = legalEntityManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
    
    public void setLocationManager(LocationManager locationManager) {
        this.locationManager = locationManager;
    }    
    
    public void setCriterionManager(CriterionManager criterionManager) {
        this.criterionManager = criterionManager;
    }
    
    public void setRequirementResponceManager(RequirementResponceManager requirementResponceManager) {
        this.requirementResponceManager = requirementResponceManager;
    }     
    
}
