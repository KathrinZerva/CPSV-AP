package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.helper.FormalFrameworkStatus;
import gr.eap.cpsvap.service.FormalFrameworkStatusManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkStatusCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class FormalFrameworkStatusAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(FormalFrameworkStatusAction.class);
    //List of formalFrameworkStatuss; Setter and Getter are below
    private List<FormalFrameworkStatus> formalFrameworkStatuses;
    //FormalFrameworkStatus object to be added; Setter and Getter are below
    private FormalFrameworkStatus formalFrameworkStatus;
    private List<Integer> selectedIds = new ArrayList<>();
    
    FormalFrameworkStatusCriteria criteria = new FormalFrameworkStatusCriteria();
    private FormalFrameworkStatusManager formalFrameworkStatusManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (FormalFrameworkStatusCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new FormalFrameworkStatusCriteria();
        }
        totalItems = formalFrameworkStatusManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        formalFrameworkStatuses = formalFrameworkStatusManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new FormalFrameworkStatusCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        formalFrameworkStatus = new FormalFrameworkStatus();
        return INPUT;
    }

    public String edit() {
        formalFrameworkStatus = formalFrameworkStatusManager.get(getSelected());
        if (formalFrameworkStatus == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        formalFrameworkStatusManager.delete(getSelected());

        if (formalFrameworkStatus == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        formalFrameworkStatusManager.save(formalFrameworkStatus);
        String message = "Message:FormalFrameworkStatus successfully saved.";
        addActionMessage(message);
    }


    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (formalFrameworkStatus != null && formalFrameworkStatus.getId() != null) {
            selected = formalFrameworkStatus.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setFormalFrameworkStatuses(List<FormalFrameworkStatus> formalFrameworkStatuses) {
        this.formalFrameworkStatuses = formalFrameworkStatuses;
    }
    
    public List<FormalFrameworkStatus> getFormalFrameworkStatuses() {
        return formalFrameworkStatuses;
    }    

    public FormalFrameworkStatus getFormalFrameworkStatus() {
        return formalFrameworkStatus;
    }

    public void setFormalFrameworkStatus(FormalFrameworkStatus formalFrameworkStatus) {
        this.formalFrameworkStatus = formalFrameworkStatus;
    }

    public FormalFrameworkStatusCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(FormalFrameworkStatusCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param formalFrameworkStatusManager
     */
    public void setFormalFrameworkStatusManager(FormalFrameworkStatusManager formalFrameworkStatusManager) {
        this.formalFrameworkStatusManager = formalFrameworkStatusManager;
    }

}
