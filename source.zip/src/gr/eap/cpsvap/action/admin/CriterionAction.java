package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.entity.RequirementGroup;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.CriterionCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.CriterionManager;
import gr.eap.cpsvap.service.FormalFrameworkManager;
import gr.eap.cpsvap.service.RequirementGroupManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import gr.eap.cpsvap.vo.criteria.RequirementGroupCriteria;

public class CriterionAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(CriterionAction.class);
    //List of criterions; Setter and Getter are below
    private List<Criterion> criterions;
    private List<NaturalLanguage> languages;  
    private List<FormalFramework> formalFrameworks;
    private List<RequirementGroup> requirementGroups;    
    
    //Criterion object to be added; Setter and Getter are below
    private Criterion criterion;
    private List<Integer> selectedIds = new ArrayList<>();

    CriterionCriteria criteria = new CriterionCriteria();
    //Criterion manager injected by spring context; This is cool !!
    private CriterionManager criterionManager;
    private NaturalLanguageManager naturalLanguageManager;
    private FormalFrameworkManager formalFrameworkManager;
    private RequirementGroupManager requirementGroupManager;    
    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria()); 
        formalFrameworks = formalFrameworkManager.list(new FormalFrameworkCriteria());
        requirementGroups = requirementGroupManager.list(new RequirementGroupCriteria());        
        
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (CriterionCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new CriterionCriteria();
        }
        totalItems = criterionManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        criterions = criterionManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new CriterionCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        criterion = new Criterion();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        criterion = criterionManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

       Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        criterionManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (criterion.getIsDefinedInFormalFramework().getId() != null) {
            criterion.setIsDefinedInFormalFramework(formalFrameworkManager.get(
                    criterion.getIsDefinedInFormalFramework().getId()));
        } else {
            criterion.setIsDefinedInFormalFramework(null);
        }
        if (criterion.getFulfilledByRequirementGroup().getId() != null) {
            criterion.setFulfilledByRequirementGroup(requirementGroupManager.get(
                    criterion.getFulfilledByRequirementGroup().getId()));
        } else {
            criterion.setFulfilledByRequirementGroup(null);
        }
                
        criterionManager.save(criterion);
        String message = "Message:Criterion successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (criterion != null && criterion.getId() != null) {
            selected = criterion.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    /**
     * ********* Getters Setters **********
     */
    public List<Criterion> getCriterions() {
        return criterions;
    }

    public void setCriterions(List<Criterion> criterions) {
        this.criterions = criterions;
    }

    public Criterion getCriterion() {
        return criterion;
    }

    public void setCriterion(Criterion criterion) {
        this.criterion = criterion;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }
    

    public CriterionCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(CriterionCriteria criteria) {
        this.criteria = criteria;
    }

    public List<FormalFramework> getFormalFrameworks() {
        return formalFrameworks;
    }

    public List<RequirementGroup> getRequirementGroups() {
        return requirementGroups;
    }
    
    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param criterionManager
     */
    public void setCriterionManager(CriterionManager criterionManager) {
        this.criterionManager = criterionManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
    
    public void setFormalFrameworkManager(FormalFrameworkManager formalFrameworkManager) {
        this.formalFrameworkManager = formalFrameworkManager;
    }    
    
    public void setRequirementGroupManager(RequirementGroupManager requirementGroupManager) {
        this.requirementGroupManager = requirementGroupManager;
    }        
    
       
}
