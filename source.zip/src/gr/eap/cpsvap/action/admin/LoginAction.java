package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.ERROR;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.User;
import gr.eap.cpsvap.service.UserManager;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.SessionAware;

public class LoginAction extends ActionSupport implements ModelDriven<User>, SessionAware {

    private User user = new User();
    private Map<String, Object> sessionAttributes = null;
    private static final Logger log = Logger.getLogger(LoginAction.class);
    //Document manager injected by spring context; This is cool !!
    private UserManager userManager;

    @Override
    public String execute() throws Exception {
        User userDB = userManager.getUserByCredentials(user.getUserName(), user.getPassword());
        if (userDB == null) {
            addActionError("Τα στοιχεία που καταχώρησες δεν είναι σωστά. Παρακαλούμε δοκίμασε ξανά.");
            return ERROR;
        } else {
            user.setName(userDB.getName());
            sessionAttributes.put(Constants.USER, userDB);
            return SUCCESS;
        }
    }

    @Override
    public void validate() {
        if (user != null) {
            if (user.getUserName().length() == 0) {
                addFieldError("loginName", "Το πεδίο User name απαιτήται");
            }
            if (user.getPassword().length() == 0) {
                addFieldError("password", "Το πεδίο Password απαιτήται");
            }
        } else {
            addFieldError("loginName", "Το πεδίο User name απαιτήται");
            addFieldError("password", "Το πεδίο Password απαιτήται");
        }
    }

    @Override
    public void setSession(Map<String, Object> sessionAttributes) {
        this.sessionAttributes = sessionAttributes;
    }

    @Override
    public User getModel() {
        return user;
    }

    /***********  Spring **********/
    public void setUserManager(UserManager userManager) {
        this.userManager = userManager;
    }
}
