package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.CriterionRequirementType;
import gr.eap.cpsvap.service.CriterionRequirementTypeManager;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementTypeCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class CriterionRequirementTypeAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(CriterionRequirementTypeAction.class);
    //List of criterionRequirementTypes; Setter and Getter are below
    private List<CriterionRequirementType> criterionRequirementTypes;
    //CriterionRequirementType object to be added; Setter and Getter are below
    private CriterionRequirementType criterionRequirementType;
    private List<Integer> selectedIds = new ArrayList<>();
    
    CriterionRequirementTypeCriteria criteria = new CriterionRequirementTypeCriteria();
    private CriterionRequirementTypeManager criterionRequirementTypeManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (CriterionRequirementTypeCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new CriterionRequirementTypeCriteria();
        }
        totalItems = criterionRequirementTypeManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        criterionRequirementTypes = criterionRequirementTypeManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new CriterionRequirementTypeCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        criterionRequirementType = new CriterionRequirementType();
        return INPUT;
    }

    public String edit() {
        criterionRequirementType = criterionRequirementTypeManager.get(getSelected());
        if (criterionRequirementType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        criterionRequirementTypeManager.delete(getSelected());

        if (criterionRequirementType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        criterionRequirementTypeManager.save(criterionRequirementType);
        String message = "Message:CriterionRequirementType successfully saved.";
        addActionMessage(message);
    }


    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (criterionRequirementType != null && criterionRequirementType.getId() != null) {
            selected = criterionRequirementType.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setCriterionRequirementTypes(List<CriterionRequirementType> criterionRequirementTypes) {
        this.criterionRequirementTypes = criterionRequirementTypes;
    }
    
    public List<CriterionRequirementType> getCriterionRequirementTypes() {
        return criterionRequirementTypes;
    }    

    public CriterionRequirementType getCriterionRequirementType() {
        return criterionRequirementType;
    }

    public void setCriterionRequirementType(CriterionRequirementType criterionRequirementType) {
        this.criterionRequirementType = criterionRequirementType;
    }

    public CriterionRequirementTypeCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(CriterionRequirementTypeCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param criterionRequirementTypeManager
     */
    public void setCriterionRequirementTypeManager(CriterionRequirementTypeManager criterionRequirementTypeManager) {
        this.criterionRequirementTypeManager = criterionRequirementTypeManager;
    }

}
