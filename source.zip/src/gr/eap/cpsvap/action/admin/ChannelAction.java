package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.common.helper.StringToIds;
import gr.eap.cpsvap.entity.Channel;
import gr.eap.cpsvap.entity.ChannelType;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.ChannelCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.ChannelManager;
import gr.eap.cpsvap.service.ChannelTypeManager;
import gr.eap.cpsvap.service.EvidenceManager;
import gr.eap.cpsvap.service.PublicOrganizationManager;
import gr.eap.cpsvap.vo.criteria.ChannelTypeCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

public class ChannelAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(ChannelAction.class);
    //List of channels; Setter and Getter are below
    private List<Channel> channels;
    private List<NaturalLanguage> languages;
    private List<ChannelType> channelTypes;

    //Channel object to be added; Setter and Getter are below
    private Channel channel;
    private List<Integer> selectedIds = new ArrayList<>();
    private String publicOrganizationIds;
    private String evidenceIds;    

    ChannelCriteria criteria = new ChannelCriteria();
    //Channel manager injected by spring context; This is cool !!
    private ChannelManager channelManager;
    private NaturalLanguageManager naturalLanguageManager;
    private ChannelTypeManager channelTypeManager;
    private PublicOrganizationManager publicOrganizationManager; 
    private EvidenceManager evidenceManager;     

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());
        channelTypes = channelTypeManager.list(new ChannelTypeCriteria());
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (ChannelCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new ChannelCriteria();
        }
        totalItems = channelManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        channels = channelManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new ChannelCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        channel = new Channel();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        channel = channelManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        channelManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (channel.getType().getId() != null) {
            channel.setType(channelTypeManager.get(channel.getType().getId()));
        } else {
            channel.setType(null);
        }         

        if (publicOrganizationIds != null && publicOrganizationIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(publicOrganizationIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                PublicOrganization publicOrganization = publicOrganizationManager.get(id);
                if (publicOrganization != null) {
                    channel.getOwnedBy().add(publicOrganization);
                }
            }
        } 
        if (evidenceIds != null && evidenceIds.length() > 0) {
            StringToIds stringToIds = new StringToIds(evidenceIds);
            List<Integer> ids = stringToIds.getIds();
            for (Integer id : ids) {
                Evidence evidence = evidenceManager.get(id);
                if (evidence != null) {
                    channel.getHasInput().add(evidence);
                }
            }
        }  
        channelManager.save(channel);
        String message = "Message:Channel successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (channel != null && channel.getId() != null) {
            selected = channel.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public List<Channel> getChannels() {
        return channels;
    }

    public void setChannels(List<Channel> channels) {
        this.channels = channels;
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<ChannelType> getChannelTypes() {
        return channelTypes;
    }

    
    public ChannelCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(ChannelCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    public String getPublicOrganizationIds() {
        return publicOrganizationIds;
    }

    public void setPublicOrganizationIds(String publicOrganizationIds) {
        this.publicOrganizationIds = publicOrganizationIds;
    }

    public String getEvidenceIds() {
        return evidenceIds;
    }

    public void setEvidenceIds(String evidenceIds) {
        this.evidenceIds = evidenceIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param channelManager
     */
    public void setChannelManager(ChannelManager channelManager) {
        this.channelManager = channelManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }

    public void setChannelTypeManager(ChannelTypeManager channelTypeManager) {
        this.channelTypeManager = channelTypeManager;
    }

    public void setPublicOrganizationManager(PublicOrganizationManager publicOrganizationManager) {
        this.publicOrganizationManager = publicOrganizationManager;
    }    
    public void setEvidenceManager(EvidenceManager evidenceManager) {
        this.evidenceManager = evidenceManager;
    }    

}
