package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.helper.FormalFrameworkType;
import gr.eap.cpsvap.service.FormalFrameworkTypeManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkTypeCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class FormalFrameworkTypeAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(FormalFrameworkTypeAction.class);
    //List of formalFrameworkTypes; Setter and Getter are below
    private List<FormalFrameworkType> formalFrameworkTypes;
    //FormalFrameworkType object to be added; Setter and Getter are below
    private FormalFrameworkType formalFrameworkType;
    private List<Integer> selectedIds = new ArrayList<>();
    
    FormalFrameworkTypeCriteria criteria = new FormalFrameworkTypeCriteria();
    private FormalFrameworkTypeManager formalFrameworkTypeManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (FormalFrameworkTypeCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new FormalFrameworkTypeCriteria();
        }
        totalItems = formalFrameworkTypeManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        formalFrameworkTypes = formalFrameworkTypeManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new FormalFrameworkTypeCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        formalFrameworkType = new FormalFrameworkType();
        return INPUT;
    }

    public String edit() {
        formalFrameworkType = formalFrameworkTypeManager.get(getSelected());
        if (formalFrameworkType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        formalFrameworkTypeManager.delete(getSelected());

        if (formalFrameworkType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        formalFrameworkTypeManager.save(formalFrameworkType);
        String message = "Message:FormalFrameworkType successfully saved.";
        addActionMessage(message);
    }


    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (formalFrameworkType != null && formalFrameworkType.getId() != null) {
            selected = formalFrameworkType.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setFormalFrameworkTypes(List<FormalFrameworkType> formalFrameworkTypes) {
        this.formalFrameworkTypes = formalFrameworkTypes;
    }
    
    public List<FormalFrameworkType> getFormalFrameworkTypes() {
        return formalFrameworkTypes;
    }    

    public FormalFrameworkType getFormalFrameworkType() {
        return formalFrameworkType;
    }

    public void setFormalFrameworkType(FormalFrameworkType formalFrameworkType) {
        this.formalFrameworkType = formalFrameworkType;
    }

    public FormalFrameworkTypeCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(FormalFrameworkTypeCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param formalFrameworkTypeManager
     */
    public void setFormalFrameworkTypeManager(FormalFrameworkTypeManager formalFrameworkTypeManager) {
        this.formalFrameworkTypeManager = formalFrameworkTypeManager;
    }

}
