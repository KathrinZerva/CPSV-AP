package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.ChangeEvent;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.entity.PublicService;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.ChangeEventCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.ChangeEventManager;
import gr.eap.cpsvap.service.FormalFrameworkManager;
import gr.eap.cpsvap.service.PublicOrganizationManager;
import gr.eap.cpsvap.service.PublicServiceManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;

public class ChangeEventAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(ChangeEventAction.class);
    //List of changeEvents; Setter and Getter are below
    private List<ChangeEvent> changeEvents;
    private List<PublicOrganization> publicOrganizations;   
    private List<FormalFramework> formalFrameworks;    
    //ChangeEvent object to be added; Setter and Getter are below
    private ChangeEvent changeEvent;
    private List<Integer> selectedIds = new ArrayList<>();

    ChangeEventCriteria criteria = new ChangeEventCriteria();
    //ChangeEvent manager injected by spring context; This is cool !!
    private ChangeEventManager changeEventManager;
    private PublicOrganizationManager publicOrganizationManager;    
    private FormalFrameworkManager formalFrameworkManager;

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        formalFrameworks = formalFrameworkManager.list(new FormalFrameworkCriteria()); 
        publicOrganizations = publicOrganizationManager.list(new PublicOrganizationCriteria());         
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (ChangeEventCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new ChangeEventCriteria();
        }
        totalItems = changeEventManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        changeEvents = changeEventManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new ChangeEventCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        changeEvent = new ChangeEvent();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        changeEvent = changeEventManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        changeEventManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        if (changeEvent.getHasFormalFramework().getId() != null) {
            changeEvent.setHasFormalFramework(formalFrameworkManager.get(changeEvent.getHasFormalFramework().getId()));
        } else {
            changeEvent.setHasFormalFramework(null);
        } 
        if (changeEvent.getOriginalOrganization().getId() != null) {
            changeEvent.setOriginalOrganization(publicOrganizationManager.get(changeEvent.getOriginalOrganization().getId()));
        } else {
            changeEvent.setOriginalOrganization(null);
        }   
        if (changeEvent.getResultingOrganization().getId() != null) {
            changeEvent.setResultingOrganization(publicOrganizationManager.get(changeEvent.getResultingOrganization().getId()));
        } else {
            changeEvent.setResultingOrganization(null);
        }         
        changeEventManager.save(changeEvent);
        String message = "Message:ChangeEvent successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if change.id is not null to apply access from link
        Integer selected = null;
        if (changeEvent != null && changeEvent.getId() != null) {
            selected = changeEvent.getId();
        } else {
            // Checked if changes have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public List<ChangeEvent> getChangeEvents() {
        return changeEvents;
    }

    public void setChangeEventes(List<ChangeEvent> changeEvents) {
        this.changeEvents = changeEvents;
    }

    public ChangeEvent getChangeEvent() {
        return changeEvent;
    }

    public void setChangeEvent(ChangeEvent changeEvent) {
        this.changeEvent = changeEvent;
    }

    public List<PublicOrganization> getPublicOrganizations() {
        return publicOrganizations;
    }

    public void setPublicOrganizations(List<PublicOrganization> publicOrganizations) {
        this.publicOrganizations = publicOrganizations;
    }


    public List<FormalFramework> getFormalFrameworks() {
        return formalFrameworks;
    }
    

    public ChangeEventCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(ChangeEventCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param changeEventManager
     */
    public void setChangeEventManager(ChangeEventManager changeEventManager) {
        this.changeEventManager = changeEventManager;
    }
    
    public void setFormalFrameworkManager(FormalFrameworkManager formalFrameworkManager) {
        this.formalFrameworkManager = formalFrameworkManager;
    }
    
    
    public void setPublicOrganizationManager(PublicOrganizationManager publicOrganizationManager) {
        this.publicOrganizationManager = publicOrganizationManager;
    }    
    
}
