package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.entity.PeriodOfTime;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.CriterionRequirementManager;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.RequirementResponceManager;
import gr.eap.cpsvap.service.EvidenceManager;
import gr.eap.cpsvap.service.PeriodOfTimeManager;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementCriteria;
import gr.eap.cpsvap.vo.criteria.EvidenceCriteria;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

public class RequirementResponceAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(RequirementResponceAction.class);
    //List of requirementResponces; Setter and Getter are below
    private List<RequirementResponce> requirementResponces;
    private List<NaturalLanguage> languages;
    private List<Evidence> evidences;  
    private List<CriterionRequirement> criterionRequirements;      
    //RequirementResponce object to be added; Setter and Getter are below
    private RequirementResponce requirementResponce;
    private List<Integer> selectedIds = new ArrayList<>();

    RequirementResponceCriteria criteria = new RequirementResponceCriteria();
    //RequirementResponce manager injected by spring context; This is cool !!
    private RequirementResponceManager requirementResponceManager;
    private NaturalLanguageManager naturalLanguageManager;
    private PeriodOfTimeManager periodOfTimeManager;
    private EvidenceManager evidenceManager;   
    private CriterionRequirementManager criterionRequirementManager;       

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());
        evidences = evidenceManager.list(new EvidenceCriteria());  
        criterionRequirements = criterionRequirementManager.list(new CriterionRequirementCriteria());          
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (RequirementResponceCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new RequirementResponceCriteria();
        }
        totalItems = requirementResponceManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        requirementResponces = requirementResponceManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new RequirementResponceCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        requirementResponce = new RequirementResponce();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        requirementResponce = requirementResponceManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        requirementResponceManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        PeriodOfTime appliesToPeriodOfTime = requirementResponce.getAppliesToPeriodOfTime();
        periodOfTimeManager.save(appliesToPeriodOfTime);
        requirementResponce.setAppliesToPeriodOfTime(appliesToPeriodOfTime);        
        if (requirementResponce.getProvenByEvidence().getId() != null) {
            requirementResponce.setProvenByEvidence(evidenceManager.get(requirementResponce.getProvenByEvidence().getId()));
        } else {
            requirementResponce.setProvenByEvidence(null);
        }    
        if (requirementResponce.getValidatesCriterionRequirement().getId() != null) {
            requirementResponce.setValidatesCriterionRequirement(criterionRequirementManager.get(requirementResponce.getValidatesCriterionRequirement().getId()));
        } else {
            requirementResponce.setValidatesCriterionRequirement(null);
        }  
        requirementResponceManager.save(requirementResponce);
        String message = "Message:RequirementResponce successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (requirementResponce != null && requirementResponce.getId() != null) {
            selected = requirementResponce.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

 

    /**
     * ********* Getters Setters **********
     */
    public List<RequirementResponce> getRequirementResponces() {
        return requirementResponces;
    }

    public void setRequirementResponcees(List<RequirementResponce> requirementResponces) {
        this.requirementResponces = requirementResponces;
    }

    public RequirementResponce getRequirementResponce() {
        return requirementResponce;
    }

    public void setRequirementResponce(RequirementResponce requirementResponce) {
        this.requirementResponce = requirementResponce;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }

    public List<Evidence> getEvidences() {
        return evidences;
    }

    public List<CriterionRequirement> getCriterionRequirements() {
        return criterionRequirements;
    }

    
    public RequirementResponceCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(RequirementResponceCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }
    
    
    /**
     * ********* Spring
     *
     *********
     * @param requirementResponceManager
     */
    public void setRequirementResponceManager(RequirementResponceManager requirementResponceManager) {
        this.requirementResponceManager = requirementResponceManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }

    public void setPeriodOfTimeManager(PeriodOfTimeManager periodOfTimeManager) {
        this.periodOfTimeManager = periodOfTimeManager;
    }
    
    public void setEvidenceManager(EvidenceManager evidenceManager) {
        this.evidenceManager = evidenceManager;
    }
    
    public void setCriterionRequirementManager(CriterionRequirementManager criterionRequirementManager) {
        this.criterionRequirementManager = criterionRequirementManager;
    }    
}
