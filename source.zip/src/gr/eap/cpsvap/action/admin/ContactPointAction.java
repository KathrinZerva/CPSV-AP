package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.ContactPoint;
import gr.eap.cpsvap.vo.criteria.ContactPointCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.ContactPointManager;

public class ContactPointAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(ContactPointAction.class);
    //List of contactPoints; Setter and Getter are below
    private List<ContactPoint> contactPoints;
    //ContactPoint object to be added; Setter and Getter are below
    private ContactPoint contactPoint;
    private List<Integer> selectedIds = new ArrayList<>();

    ContactPointCriteria criteria = new ContactPointCriteria();
    //ContactPoint manager injected by spring context; This is cool !!
    private ContactPointManager contactPointManager;

    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (ContactPointCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new ContactPointCriteria();
        }
        totalItems = contactPointManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        contactPoints = contactPointManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new ContactPointCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        contactPoint = new ContactPoint();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        contactPoint = contactPointManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        contactPointManager.delete(selected);
        return list();
    }

    private void saveLocal() {
        contactPointManager.save(contactPoint);
        String message = "Message:ContactPoint successfully saved.";
        addActionMessage(message);
    }
    
    
    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (contactPoint != null && contactPoint.getId() != null) {
            selected = contactPoint.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }
    
    /**
     * ********* Getters Setters **********
     */
    public List<ContactPoint> getContactPoints() {
        return contactPoints;
    }

    public void setContactPoints(List<ContactPoint> contactPoints) {
        this.contactPoints = contactPoints;
    }

    public ContactPoint getContactPoint() {
        return contactPoint;
    }

    public void setContactPoint(ContactPoint contactPoint) {
        this.contactPoint = contactPoint;
    }


    public ContactPointCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(ContactPointCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param contactPointManager
     */
    public void setContactPointManager(ContactPointManager contactPointManager) {
        this.contactPointManager = contactPointManager;
    }

}
