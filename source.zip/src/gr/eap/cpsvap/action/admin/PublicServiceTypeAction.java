package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.PublicServiceType;
import gr.eap.cpsvap.service.PublicServiceTypeManager;
import gr.eap.cpsvap.vo.criteria.PublicServiceTypeCriteria;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

public class PublicServiceTypeAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(PublicServiceTypeAction.class);
    //List of publicServiceTypes; Setter and Getter are below
    private List<PublicServiceType> publicServiceTypes;
    //PublicServiceType object to be added; Setter and Getter are below
    private PublicServiceType publicServiceType;
    private List<Integer> selectedIds = new ArrayList<>();
    
    PublicServiceTypeCriteria criteria = new PublicServiceTypeCriteria();
    private PublicServiceTypeManager publicServiceTypeManager;


    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {        
        criteria = (PublicServiceTypeCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new PublicServiceTypeCriteria();
        }
        totalItems = publicServiceTypeManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        publicServiceTypes = publicServiceTypeManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new PublicServiceTypeCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        publicServiceType = new PublicServiceType();
        return INPUT;
    }

    public String edit() {
        publicServiceType = publicServiceTypeManager.get(getSelected());
        if (publicServiceType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {

        publicServiceTypeManager.delete(getSelected());

        if (publicServiceType == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + getSelected() + ").");
            return list();
        }
        return INPUT;
    }

    private void saveLocal() {
        publicServiceTypeManager.save(publicServiceType);
        String message = "Message:PublicServiceType successfully saved.";
        addActionMessage(message);
    }


    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (publicServiceType != null && publicServiceType.getId() != null) {
            selected = publicServiceType.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }

    /**
     * ********* Getters Setters **********
     */
    public void setPublicServiceTypes(List<PublicServiceType> publicServiceTypes) {
        this.publicServiceTypes = publicServiceTypes;
    }
    
    public List<PublicServiceType> getPublicServiceTypes() {
        return publicServiceTypes;
    }    

    public PublicServiceType getPublicServiceType() {
        return publicServiceType;
    }

    public void setPublicServiceType(PublicServiceType publicServiceType) {
        this.publicServiceType = publicServiceType;
    }

    public PublicServiceTypeCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(PublicServiceTypeCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring
     *
     *********
     * @param publicServiceTypeManager
     */
    public void setPublicServiceTypeManager(PublicServiceTypeManager publicServiceTypeManager) {
        this.publicServiceTypeManager = publicServiceTypeManager;
    }

}
