package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.Jurisdiction;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.JurisdictionCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.JurisdictionManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

public class JurisdictionAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JurisdictionAction.class);
    //List of jurisdictions; Setter and Getter are below
    private List<Jurisdiction> jurisdictions;
    private List<NaturalLanguage> languages;      
    //Jurisdiction object to be added; Setter and Getter are below
    private Jurisdiction jurisdiction;
    private List<Integer> selectedIds = new ArrayList<>();

    JurisdictionCriteria criteria = new JurisdictionCriteria();
    //Jurisdiction manager injected by spring context; This is cool !!
    private JurisdictionManager jurisdictionManager;
    private NaturalLanguageManager naturalLanguageManager;
    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
        languages = naturalLanguageManager.list(new NaturalLanguageCriteria());        
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (JurisdictionCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new JurisdictionCriteria();
        }
        totalItems = jurisdictionManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        jurisdictions = jurisdictionManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new JurisdictionCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        jurisdiction = new Jurisdiction();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        jurisdiction = jurisdictionManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        jurisdictionManager.delete(selected);
        return INPUT;
    }

    private void saveLocal() {
        jurisdictionManager.save(jurisdiction);
        String message = "Message:Jurisdiction successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (jurisdiction != null && jurisdiction.getId() != null) {
            selected = jurisdiction.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    
    /**
     * ********* Getters Setters **********
     */
    public List<Jurisdiction> getJurisdictions() {
        return jurisdictions;
    }

    public void setJurisdictions(List<Jurisdiction> jurisdictions) {
        this.jurisdictions = jurisdictions;
    }

    public Jurisdiction getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(Jurisdiction jurisdiction) {
        this.jurisdiction = jurisdiction;
    }


    public List<NaturalLanguage> getLanguages() {
        return languages;
    }
    
    public JurisdictionCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(JurisdictionCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param jurisdictionManager
     */
    public void setJurisdictionManager(JurisdictionManager jurisdictionManager) {
        this.jurisdictionManager = jurisdictionManager;
    }

    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
}
