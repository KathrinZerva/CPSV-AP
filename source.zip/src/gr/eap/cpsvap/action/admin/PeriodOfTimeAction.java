package gr.eap.cpsvap.action.admin;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.action.PagerAction;
import gr.eap.cpsvap.common.Constants;
import gr.eap.cpsvap.entity.PeriodOfTime;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.PeriodOfTimeCriteria;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import gr.eap.cpsvap.service.PeriodOfTimeManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;

public class PeriodOfTimeAction extends PagerAction implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(PeriodOfTimeAction.class);
    //List of periodOfTimes; Setter and Getter are below
    private List<PeriodOfTime> periodOfTimes;
    //PeriodOfTime object to be added; Setter and Getter are below
    private PeriodOfTime periodOfTime;
    private List<Integer> selectedIds = new ArrayList<>();

    PeriodOfTimeCriteria criteria = new PeriodOfTimeCriteria();
    //PeriodOfTime manager injected by spring context; This is cool !!
    private PeriodOfTimeManager periodOfTimeManager;
    //This method will be called before any of Action method is invoked;
    //So some pre-processing if required.
    @Override
    public void prepare() throws Exception {
    }

    public String execute() {
        if ("create".equals(action)) {
            return create();
        } else if ("list".equals(action)) {
            return list();
        } else if ("cancel".equals(action)) {
            return list();
        } else if ("search".equals(action)) {
            return search();
        } else if ("edit".equals(action)) {
            return edit();
        } else if ("delete".equals(action)) {
            return delete();
        } else if ("save".equals(action)) {
            return save();
        } else {
            return search();
        }
    }

    public String list() {
        criteria = (PeriodOfTimeCriteria) session.get(Constants.CRITERIA);
        if (criteria == null) {
            criteria = new PeriodOfTimeCriteria();
        }
        totalItems = periodOfTimeManager.getTotalItems(criteria);
        pager.setTotalItems(totalItems.intValue());
        periodOfTimes = periodOfTimeManager.list(criteria, pager);
        action = "list";
        return SUCCESS;
    }

    private String search() {
        if (criteria == null) {
            criteria = new PeriodOfTimeCriteria();
        }
        session.put(Constants.CRITERIA, criteria);
        pager.setCurrentPage(1);
        return list();
    }

    public String create() {
        periodOfTime = new PeriodOfTime();
        return INPUT;
    }

    public String edit() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        periodOfTime = periodOfTimeManager.get(selected);
        return INPUT;
    }

    public String save() {
        saveLocal();
        return list();
    }

    public String delete() {
        Integer selected = getSelected();
        if (selected == null) {
            addActionMessage("Error:You are not permitted to use that link to directly access that page (#" + selected + ").");
            return list();
        }
        periodOfTimeManager.delete(selected);
        return INPUT;
    }

    private void saveLocal() {
        periodOfTimeManager.save(periodOfTime);
        String message = "Message:PeriodOfTime successfully saved.";
        addActionMessage(message);
    }

    private Integer getSelected() {
        // Checked if business.id is not null to apply access from link
        Integer selected = null;
        if (periodOfTime != null && periodOfTime.getId() != null) {
            selected = periodOfTime.getId();
        } else {
            // Checked if businesss have selected from list with checkboxes
            // and takes into account first selection
            for (Integer id : selectedIds) {
                if (id != null) {
                    if (selected == null) {
                        selected = id;
                    }
                }
            }
        }
        return selected;
    }    
    
    
    /**
     * ********* Getters Setters **********
     */
    public List<PeriodOfTime> getPeriodOfTimes() {
        return periodOfTimes;
    }

    public void setPeriodOfTimes(List<PeriodOfTime> periodOfTimes) {
        this.periodOfTimes = periodOfTimes;
    }

    public PeriodOfTime getPeriodOfTime() {
        return periodOfTime;
    }

    public void setPeriodOfTime(PeriodOfTime periodOfTime) {
        this.periodOfTime = periodOfTime;
    }
    
    public PeriodOfTimeCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(PeriodOfTimeCriteria criteria) {
        this.criteria = criteria;
    }

    public List<Integer> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(List<Integer> selectedIds) {
        this.selectedIds = selectedIds;
    }

    /**
     * ********* Spring *********
     * @param periodOfTimeManager
     */
    public void setPeriodOfTimeManager(PeriodOfTimeManager periodOfTimeManager) {
        this.periodOfTimeManager = periodOfTimeManager;
    }

}
