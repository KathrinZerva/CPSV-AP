package gr.eap.cpsvap.action.admin;

import java.util.Map;

import org.apache.log4j.Logger;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;
import gr.eap.cpsvap.common.Constants;


public class LogoutAction extends ActionSupport {

    private static final long serialVersionUID = -6659825682584240539L;

    private static final Logger log = Logger.getLogger(LogoutAction.class);

    Map session = ActionContext.getContext().getSession();

    @Override
    public String execute() {
        session.remove(Constants.USER);
        addActionMessage("Logout");
        return SUCCESS;
    }

}
