/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Rule;
import gr.eap.cpsvap.service.RuleManager;
import gr.eap.cpsvap.vo.criteria.RuleCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonRuleAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonRuleAction.class);
    //List of rules; Setter and Getter are below
    private List<Rule> rules;
    //Rule object to be added; Setter and Getter are below
    private Rule rule;

    RuleCriteria criteria = new RuleCriteria();
    //Rule manager injected by spring context; This is cool !!
    private RuleManager ruleManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        rules = ruleManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Rule> getRules() {
        return rules;
    }



    /**
     * ********* Spring
     *
     *********
     * @param ruleManager
     */
    public void setRuleManager(RuleManager ruleManager) {
        this.ruleManager = ruleManager;
    }
}
