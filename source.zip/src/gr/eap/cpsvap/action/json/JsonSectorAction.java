/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Sector;
import gr.eap.cpsvap.service.SectorManager;
import gr.eap.cpsvap.vo.criteria.SectorCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonSectorAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonSectorAction.class);
    //List of sectors; Setter and Getter are below
    private List<Sector> sectors;

    SectorCriteria criteria = new SectorCriteria();
    //Sector manager injected by spring context; This is cool !!
    private SectorManager sectorManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        sectors = sectorManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Sector> getSectors() {
        return sectors;
    }



    /**
     * ********* Spring
     *
     *********
     * @param sectorManager
     */
    public void setSectorManager(SectorManager sectorManager) {
        this.sectorManager = sectorManager;
    }
}
