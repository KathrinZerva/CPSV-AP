/*
 * List of Costs via Json
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Cost;
import gr.eap.cpsvap.service.CostManager;
import gr.eap.cpsvap.vo.criteria.CostCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonCostAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonCostAction.class);
    //List of events; Setter and Getter are below
    private List<Cost> costs;
    //Cost object to be added; Setter and Getter are below

    CostCriteria criteria = new CostCriteria();
    //Cost manager injected by spring context; This is cool !!
    private CostManager costManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        costs = costManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Cost> getCosts() {
        return costs;
    }



    /**
     * ********* Spring
     *
     *********
     * @param costManager
     */
    public void setCostManager(CostManager costManager) {
        this.costManager = costManager;
    }
}
