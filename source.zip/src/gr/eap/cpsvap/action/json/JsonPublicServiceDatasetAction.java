/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.PublicServiceDataset;
import gr.eap.cpsvap.service.PublicServiceDatasetManager;
import gr.eap.cpsvap.service.PublicServiceTypeManager;
import gr.eap.cpsvap.vo.criteria.PublicServiceDatasetCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonPublicServiceDatasetAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonPublicServiceDatasetAction.class);
    //List of publicServiceTypes; Setter and Getter are below
    private List<PublicServiceDataset> publicServiceDatasets;

    PublicServiceDatasetCriteria criteria = new PublicServiceDatasetCriteria();
    //PublicServiceType manager injected by spring context; This is cool !!
    private PublicServiceDatasetManager publicServiceDatasetManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        publicServiceDatasets = publicServiceDatasetManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<PublicServiceDataset> getPublicServiceDatasets() {
        return publicServiceDatasets;
    }



    /**
     * ********* Spring
     *
     *********
     * @param publicServiceDatasetManager
     */
    public void setPublicServiceDatasetManager(PublicServiceDatasetManager publicServiceDatasetManager) {
        this.publicServiceDatasetManager = publicServiceDatasetManager;
    }
}
