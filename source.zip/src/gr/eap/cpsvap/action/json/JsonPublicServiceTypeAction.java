/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.PublicServiceType;
import gr.eap.cpsvap.service.PublicServiceTypeManager;
import gr.eap.cpsvap.vo.criteria.PublicServiceTypeCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonPublicServiceTypeAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonPublicServiceTypeAction.class);
    //List of publicServiceTypes; Setter and Getter are below
    private List<PublicServiceType> publicServiceTypes;

    PublicServiceTypeCriteria criteria = new PublicServiceTypeCriteria();
    //PublicServiceType manager injected by spring context; This is cool !!
    private PublicServiceTypeManager publicServiceTypeManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        publicServiceTypes = publicServiceTypeManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<PublicServiceType> getPublicServiceTypes() {
        return publicServiceTypes;
    }



    /**
     * ********* Spring
     *
     *********
     * @param publicServiceTypeManager
     */
    public void setPublicServiceTypeManager(PublicServiceTypeManager publicServiceTypeManager) {
        this.publicServiceTypeManager = publicServiceTypeManager;
    }
}
