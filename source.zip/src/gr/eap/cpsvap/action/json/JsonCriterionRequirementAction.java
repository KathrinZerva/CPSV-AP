/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.service.CriterionRequirementManager;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonCriterionRequirementAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonCriterionRequirementAction.class);
    //List of evidences; Setter and Getter are below
    private List<CriterionRequirement> criterionRequirements;
    //CriterionRequirement object to be added; Setter and Getter are below
    private CriterionRequirement criterionRequirement;

    CriterionRequirementCriteria criteria = new CriterionRequirementCriteria();
    //CriterionRequirement manager injected by spring context; This is cool !!
    private CriterionRequirementManager criterionRequirementManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        criterionRequirements = criterionRequirementManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<CriterionRequirement> getCriterionRequirements() {
        return criterionRequirements;
    }



    /**
     * ********* Spring
     *
     *********
     * @param criterionRequirementManager
     */
    public void setCriterionRequirementManager(CriterionRequirementManager criterionRequirementManager) {
        this.criterionRequirementManager = criterionRequirementManager;
    }
}
