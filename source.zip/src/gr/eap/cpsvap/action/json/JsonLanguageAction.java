/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonLanguageAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonLanguageAction.class);
    //List of naturalLanguages; Setter and Getter are below
    private List<NaturalLanguage> languages;

    NaturalLanguageCriteria criteria = new NaturalLanguageCriteria();
    //NaturalLanguage manager injected by spring context; This is cool !!
    private NaturalLanguageManager naturalLanguageManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        languages = naturalLanguageManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<NaturalLanguage> getLanguages() {
        return languages;
    }



    /**
     * ********* Spring
     *
     *********
     * @param naturalLanguageManager
     */
    public void setNaturalLanguageManager(NaturalLanguageManager naturalLanguageManager) {
        this.naturalLanguageManager = naturalLanguageManager;
    }
}
