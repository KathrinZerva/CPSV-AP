/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.ThematicArea;
import gr.eap.cpsvap.service.ThematicAreaManager;
import gr.eap.cpsvap.vo.criteria.ThematicAreaCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonThematicAreaAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonThematicAreaAction.class);
    //List of thematicAreas; Setter and Getter are below
    private List<ThematicArea> thematicAreas;

    ThematicAreaCriteria criteria = new ThematicAreaCriteria();
    //ThematicArea manager injected by spring context; This is cool !!
    private ThematicAreaManager thematicAreaManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        thematicAreas = thematicAreaManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<ThematicArea> getThematicAreas() {
        return thematicAreas;
    }



    /**
     * ********* Spring
     *
     *********
     * @param thematicAreaManager
     */
    public void setThematicAreaManager(ThematicAreaManager thematicAreaManager) {
        this.thematicAreaManager = thematicAreaManager;
    }
}
