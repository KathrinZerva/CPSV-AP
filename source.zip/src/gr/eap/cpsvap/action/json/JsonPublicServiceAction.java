/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.PublicService;
import gr.eap.cpsvap.service.PublicServiceManager;
import gr.eap.cpsvap.vo.criteria.PublicServiceCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonPublicServiceAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonPublicServiceAction.class);
    //List of publicServiceTypes; Setter and Getter are below
    private List<PublicService> publicServices;

    PublicServiceCriteria criteria = new PublicServiceCriteria();
    //PublicServiceType manager injected by spring context; This is cool !!
    private PublicServiceManager publicServiceManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        publicServices = publicServiceManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<PublicService> getPublicServices() {
        return publicServices;
    }



    /**
     * ********* Spring
     *
     *********
     * @param publicServiceManager
     */
    public void setPublicServiceManager(PublicServiceManager publicServiceManager) {
        this.publicServiceManager = publicServiceManager;
    }
}
