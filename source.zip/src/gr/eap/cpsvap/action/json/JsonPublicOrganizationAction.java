/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.service.PublicOrganizationManager;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonPublicOrganizationAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonPublicOrganizationAction.class);
    //List of publicOrganizations; Setter and Getter are below
    private List<PublicOrganization> publicOrganizations;
    //PublicOrganization object to be added; Setter and Getter are below
    PublicOrganizationCriteria criteria = new PublicOrganizationCriteria();
    //PublicOrganization manager injected by spring context; This is cool !!
    private PublicOrganizationManager publicOrganizationManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        publicOrganizations = publicOrganizationManager.list(new PublicOrganizationCriteria());
        return Action.SUCCESS;
    }

    public List<PublicOrganization> getPublicOrganizations() {
        return publicOrganizations;
    }


    /**
     * ********* Spring
     *
     *********
     * @param publicOrganizationManager
     */
    public void setPublicOrganizationManager(PublicOrganizationManager publicOrganizationManager) {
        this.publicOrganizationManager = publicOrganizationManager;
    }
}
