/*
 * List of Events via Json
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Location;
import gr.eap.cpsvap.service.LocationManager;
import gr.eap.cpsvap.vo.criteria.LocationCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonLocationAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonLocationAction.class);
    //List of events; Setter and Getter are below
    private List<Location> locations;
    //Location object to be added; Setter and Getter are below

    LocationCriteria criteria = new LocationCriteria();
    //Location manager injected by spring context; This is cool !!
    private LocationManager locationManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        locations = locationManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Location> getLocations() {
        return locations;
    }



    /**
     * ********* Spring
     *
     *********
     * @param locationManager
     */
    public void setLocationManager(LocationManager locationManager) {
        this.locationManager = locationManager;
    }
}
