/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.service.FormalFrameworkManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonFormalFrameworkAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonFormalFrameworkAction.class);
    //List of formalFrameworks; Setter and Getter are below
    private List<FormalFramework> formalFrameworks;
    //FormalFramework object to be added; Setter and Getter are below
    private FormalFramework formalFramework;

    FormalFrameworkCriteria criteria = new FormalFrameworkCriteria();
    //FormalFramework manager injected by spring context; This is cool !!
    private FormalFrameworkManager formalFrameworkManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        formalFrameworks = formalFrameworkManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<FormalFramework> getFormalFrameworks() {
        return formalFrameworks;
    }



    /**
     * ********* Spring
     *
     *********
     * @param formalFrameworkManager
     */
    public void setFormalFrameworkManager(FormalFrameworkManager formalFrameworkManager) {
        this.formalFrameworkManager = formalFrameworkManager;
    }
}
