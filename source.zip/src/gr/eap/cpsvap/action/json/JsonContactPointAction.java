/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.ContactPoint;
import gr.eap.cpsvap.service.ContactPointManager;
import gr.eap.cpsvap.vo.criteria.ContactPointCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonContactPointAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonContactPointAction.class);
    //List of contactPoints; Setter and Getter are below
    private List<ContactPoint> contactPoints;

    ContactPointCriteria criteria = new ContactPointCriteria();
    //ContactPoint manager injected by spring context; This is cool !!
    private ContactPointManager contactPointManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        contactPoints = contactPointManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<ContactPoint> getContactPoints() {
        return contactPoints;
    }



    /**
     * ********* Spring
     *
     *********
     * @param contactPointManager
     */
    public void setContactPointManager(ContactPointManager contactPointManager) {
        this.contactPointManager = contactPointManager;
    }
}
