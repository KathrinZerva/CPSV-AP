/*
 * List of Consepts via Json
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Consept;
import gr.eap.cpsvap.service.ConseptManager;
import gr.eap.cpsvap.vo.criteria.ConseptCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonConseptAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonConseptAction.class);
    //List of events; Setter and Getter are below
    private List<Consept> consepts;
    //Consept object to be added; Setter and Getter are below

    ConseptCriteria criteria = new ConseptCriteria();
    //Consept manager injected by spring context; This is cool !!
    private ConseptManager conseptManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        consepts = conseptManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Consept> getConsepts() {
        return consepts;
    }



    /**
     * ********* Spring
     *
     *********
     * @param conseptManager
     */
    public void setConseptManager(ConseptManager conseptManager) {
        this.conseptManager = conseptManager;
    }
}
