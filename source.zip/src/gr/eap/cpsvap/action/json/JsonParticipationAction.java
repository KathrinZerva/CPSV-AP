/*
 * List of Participations via Json
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Participation;
import gr.eap.cpsvap.service.ParticipationManager;
import gr.eap.cpsvap.vo.criteria.ParticipationCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonParticipationAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonParticipationAction.class);
    //List of participations; Setter and Getter are below
    private List<Participation> participations;
    //Participation object to be added; Setter and Getter are below

    ParticipationCriteria criteria = new ParticipationCriteria();
    //Participation manager injected by spring context; This is cool !!
    private ParticipationManager participationManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        participations = participationManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Participation> getParticipations() {
        return participations;
    }



    /**
     * ********* Spring
     *
     *********
     * @param participationManager
     */
    public void setParticipationManager(ParticipationManager participationManager) {
        this.participationManager = participationManager;
    }
}
