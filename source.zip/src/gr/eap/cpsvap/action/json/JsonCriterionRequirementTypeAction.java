/*
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.CriterionRequirementType;
import gr.eap.cpsvap.service.CriterionRequirementTypeManager;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementTypeCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonCriterionRequirementTypeAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonCriterionRequirementTypeAction.class);
    //List of criterionRequirementTypes; Setter and Getter are below
    private List<CriterionRequirementType> criterionRequirementTypes;

    CriterionRequirementTypeCriteria criteria = new CriterionRequirementTypeCriteria();
    //CriterionRequirementType manager injected by spring context; This is cool !!
    private CriterionRequirementTypeManager criterionRequirementTypeManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        criterionRequirementTypes = criterionRequirementTypeManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<CriterionRequirementType> getCriterionRequirementTypes() {
        return criterionRequirementTypes;
    }



    /**
     * ********* Spring
     *
     *********
     * @param criterionRequirementTypeManager
     */
    public void setCriterionRequirementTypeManager(CriterionRequirementTypeManager criterionRequirementTypeManager) {
        this.criterionRequirementTypeManager = criterionRequirementTypeManager;
    }
}
