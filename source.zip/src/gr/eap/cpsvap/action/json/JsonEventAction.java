/*
 * List of Events via Json
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Event;
import gr.eap.cpsvap.service.EventManager;
import gr.eap.cpsvap.vo.criteria.EventCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonEventAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonEventAction.class);
    //List of events; Setter and Getter are below
    private List<Event> events;
    //Event object to be added; Setter and Getter are below

    EventCriteria criteria = new EventCriteria();
    //Event manager injected by spring context; This is cool !!
    private EventManager eventManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        events = eventManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Event> getEvents() {
        return events;
    }



    /**
     * ********* Spring
     *
     *********
     * @param eventManager
     */
    public void setEventManager(EventManager eventManager) {
        this.eventManager = eventManager;
    }
}
