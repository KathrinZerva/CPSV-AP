/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Output;
import gr.eap.cpsvap.service.OutputManager;
import gr.eap.cpsvap.vo.criteria.OutputCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonOutputAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonOutputAction.class);
    //List of evidences; Setter and Getter are below
    private List<Output> outputs;
    //Output object to be added; Setter and Getter are below
    private Output output;

    OutputCriteria criteria = new OutputCriteria();
    //Output manager injected by spring context; This is cool !!
    private OutputManager outputManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        outputs = outputManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Output> getOutputs() {
        return outputs;
    }



    /**
     * ********* Spring
     *
     *********
     * @param outputManager
     */
    public void setOutputManager(OutputManager outputManager) {
        this.outputManager = outputManager;
    }
}
