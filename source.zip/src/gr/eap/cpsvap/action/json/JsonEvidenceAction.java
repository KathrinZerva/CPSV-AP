/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.service.EvidenceManager;
import gr.eap.cpsvap.vo.criteria.EvidenceCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonEvidenceAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonEvidenceAction.class);
    //List of evidences; Setter and Getter are below
    private List<Evidence> evidences;
    //Evidence object to be added; Setter and Getter are below
    private Evidence evidence;

    EvidenceCriteria criteria = new EvidenceCriteria();
    //Evidence manager injected by spring context; This is cool !!
    private EvidenceManager evidenceManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        evidences = evidenceManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Evidence> getEvidences() {
        return evidences;
    }



    /**
     * ********* Spring
     *
     *********
     * @param evidenceManager
     */
    public void setEvidenceManager(EvidenceManager evidenceManager) {
        this.evidenceManager = evidenceManager;
    }
}
