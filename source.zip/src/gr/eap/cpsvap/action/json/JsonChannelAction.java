/*
 * List of Channels via Json
 */
package gr.eap.cpsvap.action.json;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import gr.eap.cpsvap.entity.Channel;
import gr.eap.cpsvap.service.ChannelManager;
import gr.eap.cpsvap.vo.criteria.ChannelCriteria;
import java.util.List;
import org.apache.log4j.Logger;

public class JsonChannelAction extends ActionSupport implements Preparable {

    private static final long serialVersionUID = 1L;

    //Logger configured using log4j
    private static final Logger logger = Logger.getLogger(JsonChannelAction.class);
    //List of events; Setter and Getter are below
    private List<Channel> channels;
    //Channel object to be added; Setter and Getter are below

    ChannelCriteria criteria = new ChannelCriteria();
    //Channel manager injected by spring context; This is cool !!
    private ChannelManager channelManager;

    @Override
    public void prepare() throws Exception {
    }

    @Override
    public String execute() {
        channels = channelManager.list(criteria);
        return Action.SUCCESS;
    }

    public List<Channel> getChannels() {
        return channels;
    }



    /**
     * ********* Spring
     *
     *********
     * @param channelManager
     */
    public void setChannelManager(ChannelManager channelManager) {
        this.channelManager = channelManager;
    }
}
