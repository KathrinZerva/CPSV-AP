/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.action;

import java.util.Map;

import org.apache.log4j.Logger;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.ActionContext;
import gr.eap.cpsvap.common.PagerResults;


public class PagerAction extends ActionSupport
        implements Preparable {


    private static final long serialVersionUID = -6659925452584240539L;
    private static final Logger log = Logger.getLogger(PagerAction.class);
    protected Map parameters = ActionContext.getContext().getParameters();
    protected Map session = ActionContext.getContext().getSession();
    protected Integer pagerOffset = 0;
    protected Long totalItems = 0l;


 
    protected PagerResults pager = new PagerResults();
    protected String action;

    public void prepare() throws Exception {
        setPagerOffset();
    }

    protected String getParameterValue(String param) {
        Object varr = parameters.get(param);
        if (varr == null) {
            return null;
        }
        return ((String[]) varr)[0];
    }

    protected void setPagerOffset() {
        String pOffset = getParameterValue("pager.offset");
        if (pOffset != null) {
            try {
                pagerOffset = Integer.parseInt(pOffset);
            } catch (NumberFormatException nfex) {
                System.out.println(nfex);
                pagerOffset = 0;
            }
        } else {
            pagerOffset = 0;
        }
        pager.setCurrentPage(pagerOffset);
    }



    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public PagerResults getPager() {
        return pager;
    }

    public void setPager(PagerResults pager) {
        this.pager = pager;
    }
    
    
}
