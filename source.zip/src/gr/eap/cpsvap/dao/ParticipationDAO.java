package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Participation;
import gr.eap.cpsvap.vo.criteria.ParticipationCriteria;

public interface ParticipationDAO {

    public Participation get(Integer id);
    public List<Participation> list(ParticipationCriteria criteria);    
    public List<Participation> list(ParticipationCriteria criteria,  PagerResults pager);
    public Long getTotalItems(ParticipationCriteria criteria);
    public void save(Participation participation);
    public void delete(Integer id);    
}
