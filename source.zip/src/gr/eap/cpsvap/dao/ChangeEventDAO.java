package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ChangeEvent;
import gr.eap.cpsvap.vo.criteria.ChangeEventCriteria;

public interface ChangeEventDAO {

    public ChangeEvent get(Integer id);
    public List<ChangeEvent> list(ChangeEventCriteria criteria);    
    public List<ChangeEvent> list(ChangeEventCriteria criteria,  PagerResults pager);
    public Long getTotalItems(ChangeEventCriteria criteria);
    public void save(ChangeEvent changeEvent);
    public void delete(Integer id);    
}
