package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.EvidenceType;
import gr.eap.cpsvap.vo.criteria.EvidenceTypeCriteria;

public interface EvidenceTypeDAO {

    public EvidenceType get(Integer id);
    public List<EvidenceType> list(EvidenceTypeCriteria criteria);    
    public List<EvidenceType> list(EvidenceTypeCriteria criteria,  PagerResults pager);
    public Long getTotalItems(EvidenceTypeCriteria criteria);
    public void save(EvidenceType evidenceType);
    public void delete(Integer id);    
}
