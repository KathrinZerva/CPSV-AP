package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicService;
import gr.eap.cpsvap.vo.criteria.PublicServiceCriteria;
import java.util.List;

public interface PublicServiceDAO {
    
    public PublicService get(Integer id);
    public List<PublicService> list(PublicServiceCriteria criteria);    
    public List<PublicService> list(PublicServiceCriteria criteria,  PagerResults pager);
    public Long getTotalItems(PublicServiceCriteria criteria);
    public void save(PublicService publicService);
    public void delete(Integer id);
}
