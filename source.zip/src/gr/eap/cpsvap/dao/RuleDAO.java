package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Rule;
import gr.eap.cpsvap.vo.criteria.RuleCriteria;

public interface RuleDAO {

    public Rule get(Integer id);
    public List<Rule> list(RuleCriteria criteria);    
    public List<Rule> list(RuleCriteria criteria,  PagerResults pager);
    public Long getTotalItems(RuleCriteria criteria);
    public void save(Rule rule);
    public void delete(Integer id);    
}
