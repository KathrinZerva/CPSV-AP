package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.helper.FormalFrameworkType;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkTypeCriteria;
import java.util.List;

public interface FormalFrameworkTypeDAO {
    
    public FormalFrameworkType get(Integer id);
    public List<FormalFrameworkType> list(FormalFrameworkTypeCriteria criteria);    
    public List<FormalFrameworkType> list(FormalFrameworkTypeCriteria criteria,  PagerResults pager);
    public Long getTotalItems(FormalFrameworkTypeCriteria criteria);
    public void save(FormalFrameworkType formalFrameworkType);
    public void delete(Integer id);
}
