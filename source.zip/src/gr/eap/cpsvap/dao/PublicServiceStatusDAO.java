package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicServiceStatus;
import gr.eap.cpsvap.vo.criteria.PublicServiceStatusCriteria;

public interface PublicServiceStatusDAO {

    public PublicServiceStatus get(Integer id);
    public List<PublicServiceStatus> list(PublicServiceStatusCriteria criteria);    
    public List<PublicServiceStatus> list(PublicServiceStatusCriteria criteria,  PagerResults pager);
    public Long getTotalItems(PublicServiceStatusCriteria criteria);
    public void save(PublicServiceStatus publicServiceStatus);
    public void delete(Integer id);    
}
