package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.RequirementGroup;
import gr.eap.cpsvap.vo.criteria.RequirementGroupCriteria;

public interface RequirementGroupDAO {

    public RequirementGroup get(Integer id);
    public List<RequirementGroup> list(RequirementGroupCriteria criteria);    
    public List<RequirementGroup> list(RequirementGroupCriteria criteria,  PagerResults pager);
    public Long getTotalItems(RequirementGroupCriteria criteria);
    public void save(RequirementGroup requirementGroup);
    public void delete(Integer id);    
}
