package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Organization;
import gr.eap.cpsvap.vo.criteria.OrganizationCriteria;

public interface OrganizationDAO {

    public Organization get(Integer id);
    public List<Organization> list(OrganizationCriteria criteria);    
    public List<Organization> list(OrganizationCriteria criteria,  PagerResults pager);
    public Long getTotalItems(OrganizationCriteria criteria);
    public void save(Organization organization);
    public void delete(Integer id);    
}
