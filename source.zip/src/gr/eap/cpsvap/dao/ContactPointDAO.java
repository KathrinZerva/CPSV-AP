package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ContactPoint;
import gr.eap.cpsvap.vo.criteria.ContactPointCriteria;

public interface ContactPointDAO {

    public ContactPoint get(Integer id);
    public List<ContactPoint> list(ContactPointCriteria criteria);    
    public List<ContactPoint> list(ContactPointCriteria criteria,  PagerResults pager);
    public Long getTotalItems(ContactPointCriteria criteria);
    public void save(ContactPoint contactPoint);
    public void delete(Integer id);    
}
