package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Event;
import gr.eap.cpsvap.vo.criteria.EventCriteria;

public interface EventDAO {

    public Event get(Integer id);
    public List<Event> list(EventCriteria criteria);    
    public List<Event> list(EventCriteria criteria,  PagerResults pager);
    public Long getTotalItems(EventCriteria criteria);
    public void save(Event event);
    public void delete(Integer id);    
}
