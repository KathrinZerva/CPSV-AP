package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;

public interface RequirementResponceDAO {

    public RequirementResponce get(Integer id);
    public List<RequirementResponce> list(RequirementResponceCriteria criteria);    
    public List<RequirementResponce> list(RequirementResponceCriteria criteria,  PagerResults pager);
    public Long getTotalItems(RequirementResponceCriteria criteria);
    public void save(RequirementResponce requirementResponce);
    public void delete(Integer id);    
}
