package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Person;
import gr.eap.cpsvap.vo.criteria.PersonCriteria;

public interface PersonDAO {

    public Person get(Integer id);
    public List<Person> list(PersonCriteria criteria);    
    public List<Person> list(PersonCriteria criteria,  PagerResults pager);
    public Long getTotalItems(PersonCriteria criteria);
    public void save(Person person);
    public void delete(Integer id);    
}
