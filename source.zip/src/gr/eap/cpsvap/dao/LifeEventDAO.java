package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.LifeEvent;
import gr.eap.cpsvap.vo.criteria.LifeEventCriteria;

public interface LifeEventDAO {

    public LifeEvent get(Integer id);
    public List<LifeEvent> list(LifeEventCriteria criteria);    
    public List<LifeEvent> list(LifeEventCriteria criteria,  PagerResults pager);
    public Long getTotalItems(LifeEventCriteria criteria);
    public void save(LifeEvent lifeEvent);
    public void delete(Integer id);    
}
