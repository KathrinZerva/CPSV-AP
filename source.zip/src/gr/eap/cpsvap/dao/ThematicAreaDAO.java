package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ThematicArea;
import gr.eap.cpsvap.vo.criteria.ThematicAreaCriteria;

public interface ThematicAreaDAO {

    public ThematicArea get(Integer id);
    public List<ThematicArea> list(ThematicAreaCriteria criteria);    
    public List<ThematicArea> list(ThematicAreaCriteria criteria,  PagerResults pager);
    public Long getTotalItems(ThematicAreaCriteria criteria);
    public void save(ThematicArea thematicArea);
    public void delete(Integer id);    
}
