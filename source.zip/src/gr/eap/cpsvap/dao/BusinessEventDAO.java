package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.BusinessEvent;
import gr.eap.cpsvap.vo.criteria.BusinessEventCriteria;

public interface BusinessEventDAO {

    public BusinessEvent get(Integer id);
    public List<BusinessEvent> list(BusinessEventCriteria criteria);    
    public List<BusinessEvent> list(BusinessEventCriteria criteria,  PagerResults pager);
    public Long getTotalItems(BusinessEventCriteria criteria);
    public void save(BusinessEvent businessEvent);
    public void delete(Integer id);    
}
