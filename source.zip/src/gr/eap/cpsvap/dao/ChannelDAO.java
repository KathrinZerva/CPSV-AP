package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Channel;
import gr.eap.cpsvap.vo.criteria.ChannelCriteria;

public interface ChannelDAO {

    public Channel get(Integer id);
    public List<Channel> list(ChannelCriteria criteria);    
    public List<Channel> list(ChannelCriteria criteria,  PagerResults pager);
    public Long getTotalItems(ChannelCriteria criteria);
    public void save(Channel channel);
    public void delete(Integer id);    
}
