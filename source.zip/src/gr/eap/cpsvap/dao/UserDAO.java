package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.User;
import gr.eap.cpsvap.vo.criteria.UserCriteria;
import java.util.List;

public interface UserDAO {

    User getUserByCredentials(String userId, String password);
    
    public User get(Integer id);
    public List<User> list(UserCriteria criteria);    
    public List<User> list(UserCriteria criteria,  PagerResults pager);
    public Long getTotalItems(UserCriteria criteria);
    public void save(User user);
    public void delete(Integer id);
}
