package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.helper.FormalFrameworkStatus;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkStatusCriteria;
import java.util.List;

public interface FormalFrameworkStatusDAO {
    
    public FormalFrameworkStatus get(Integer id);
    public List<FormalFrameworkStatus> list(FormalFrameworkStatusCriteria criteria);    
    public List<FormalFrameworkStatus> list(FormalFrameworkStatusCriteria criteria,  PagerResults pager);
    public Long getTotalItems(FormalFrameworkStatusCriteria criteria);
    public void save(FormalFrameworkStatus formalFrameworkStatus);
    public void delete(Integer id);
}
