package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;

public interface FormalFrameworkDAO {

    public FormalFramework get(Integer id);
    public List<FormalFramework> list(FormalFrameworkCriteria criteria);    
    public List<FormalFramework> list(FormalFrameworkCriteria criteria,  PagerResults pager);
    public Long getTotalItems(FormalFrameworkCriteria criteria);
    public void save(FormalFramework formalFramework);
    public void delete(Integer id); 
    public FormalFramework merge(FormalFramework formalFramework); 
    public void evict(FormalFramework formalFramework); 
    
    public void dumpHibernateSession(); 
}
