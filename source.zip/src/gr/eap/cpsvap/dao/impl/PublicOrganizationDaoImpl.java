package gr.eap.cpsvap.dao.impl;


import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;
import java.util.List;

import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.PublicOrganizationDAO;
import gr.eap.cpsvap.entity.PublicOrganization;

@Repository
public class PublicOrganizationDaoImpl extends AbstractGenericDaoImpl<PublicOrganization, Integer> 
        implements PublicOrganizationDAO {
   
    @SuppressWarnings("unchecked")
    @Override
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria) {

        List<PublicOrganization> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {

            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(PublicOrganization.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
            
            if(criteria.getNotIds() != null && criteria.getNotIds().size() > 0){
                crit.add(Restrictions.not(Restrictions.in("id", criteria.getNotIds())));
            }
         
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria, PagerResults pager) {

        List<PublicOrganization> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(PublicOrganization.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @Override
    public Long getTotalItems(PublicOrganizationCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(PublicOrganization.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }
}
