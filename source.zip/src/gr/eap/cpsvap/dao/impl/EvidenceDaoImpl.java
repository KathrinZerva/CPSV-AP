package gr.eap.cpsvap.dao.impl;


import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.vo.criteria.EvidenceCriteria;
import java.util.List;

import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.EvidenceDAO;

@Repository
public class EvidenceDaoImpl extends AbstractGenericDaoImpl<Evidence, Integer> 
        implements EvidenceDAO {
   
    @SuppressWarnings("unchecked")
    @Override
    public List<Evidence> list(EvidenceCriteria criteria) {

        List<Evidence> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Evidence.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Ονομασία
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getName() + "%"));
            }
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description.content", criteria.getDescription() + "%"));
            }          
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<Evidence> list(EvidenceCriteria criteria, PagerResults pager) {

        List<Evidence> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Evidence.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Ονομασία
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getName() + "%"));
            }
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description.content", criteria.getDescription() + "%"));
            }          
            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @Override
    public Long getTotalItems(EvidenceCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Evidence.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Ονομασία
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getName() + "%"));
            }
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description.content", criteria.getDescription() + "%"));
            }            
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }
}
