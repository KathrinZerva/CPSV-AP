package gr.eap.cpsvap.dao.impl;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.engine.PersistenceContext;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.engine.StatefulPersistenceContext;
import org.hibernate.util.IdentityMap;

public class AbstractGenericDaoImpl<C, I extends Serializable> {

    Class<C> entityClass;

    protected SessionFactory sessionFactory;

    {
        entityClass = (Class<C>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    public List<C> list() {
        try {
            return this.sessionFactory.getCurrentSession().createCriteria(entityClass).list();
        } catch (HibernateException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public C get(I id) {
        try {
            return (C) this.sessionFactory.getCurrentSession().get(entityClass, id);
        } catch (HibernateException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void save(C object) {
        Session session = this.sessionFactory.getCurrentSession();
        try {
            session.saveOrUpdate(object);
        } catch (HibernateException e) {
            e.printStackTrace();
        }
    }

    public void delete(I id) {
        Session session = this.sessionFactory.getCurrentSession();
        try {
            C actual = get(id);
            session.delete(actual);
        } catch (HibernateException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void delete(C object) {
        Session session = this.sessionFactory.getCurrentSession();
        try {
            session.delete(object);
        } catch (HibernateException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public C merge(C object) {
        Session session = this.sessionFactory.getCurrentSession();
        try {
            return (C) session.merge(object);
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void evict(C object) {
        Session session = this.sessionFactory.getCurrentSession();
        try {
            session.evict(object);
        } catch (HibernateException e) {
            e.printStackTrace();
        }
    }

    public void dumpHibernateSession() {
        try {
            Session session = this.sessionFactory.getCurrentSession();
            SessionImplementor sessionImpl = (SessionImplementor) session;
            PersistenceContext persistenceContext = sessionImpl.getPersistenceContext();
            Field entityEntriesField = StatefulPersistenceContext.class.getDeclaredField("entityEntries");
            entityEntriesField.setAccessible(true);
            IdentityMap map = (IdentityMap) entityEntriesField.get(persistenceContext);
            System.out.println(map);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //This setter will be used by Spring context to inject the sessionFactory instance
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
