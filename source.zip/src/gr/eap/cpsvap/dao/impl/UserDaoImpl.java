package gr.eap.cpsvap.dao.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.dao.UserDAO;

import org.springframework.stereotype.Repository;

import gr.eap.cpsvap.entity.User;
import gr.eap.cpsvap.vo.criteria.UserCriteria;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

@Repository
public class UserDaoImpl extends AbstractGenericDaoImpl<User, Integer>
        implements UserDAO {

    @Override
    public List<User> list(UserCriteria criteria) {

        List<User> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(User.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Όνοματεπώνυμο
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name", criteria.getName() + "%"));
            }
            // User Name
            if (criteria.getUserName() != null && criteria.getUserName().length() > 0) {
                crit.add(Restrictions.like("userName", criteria.getUserName() + "%"));
            }
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<User> list(UserCriteria criteria, PagerResults pager) {

        List<User> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(User.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Όνοματεπώνυμο
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name", criteria.getName() + "%"));
            }
            // User Name
            if (criteria.getUserName() != null && criteria.getUserName().length() > 0) {
                crit.add(Restrictions.like("userName", criteria.getUserName() + "%"));
            }

            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());

            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public Long getTotalItems(UserCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(User.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Όνοματεπώνυμο
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name", criteria.getName() + "%"));
            }
            // User Name
            if (criteria.getUserName() != null && criteria.getUserName().length() > 0) {
                crit.add(Restrictions.like("userName", criteria.getUserName() + "%"));
            }

            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }

    //This method return list of patients in database
    @SuppressWarnings("unchecked")
    @Override
    public User getUserByCredentials(String userName, String password) {
        Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(User.class);
        crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        crit.setFetchMode("permissions", FetchMode.JOIN);
        crit.add(Restrictions.eq("userName", userName));
        crit.add(Restrictions.eq("password", password));
        User user = (User) crit.uniqueResult();
        return user;
    }

}
