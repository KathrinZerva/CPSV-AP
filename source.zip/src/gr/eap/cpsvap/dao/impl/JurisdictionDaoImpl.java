package gr.eap.cpsvap.dao.impl;


import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Jurisdiction;
import gr.eap.cpsvap.vo.criteria.JurisdictionCriteria;
import java.util.List;

import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.JurisdictionDAO;

@Repository
public class JurisdictionDaoImpl extends AbstractGenericDaoImpl<Jurisdiction, Integer> 
        implements JurisdictionDAO {
   
    @SuppressWarnings("unchecked")
    @Override
    public List<Jurisdiction> list(JurisdictionCriteria criteria) {

        List<Jurisdiction> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Jurisdiction.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
            if (criteria.getContent() != null && criteria.getContent().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getContent() + "%"));
            }
            if (criteria.getLanguage() != null && criteria.getLanguage().length() > 1) {
                crit.add(Restrictions.eq("name.language", criteria.getLanguage()));
            }         
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }
        
            try {
                list = crit.list();                
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<Jurisdiction> list(JurisdictionCriteria criteria, PagerResults pager) {

        List<Jurisdiction> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {

            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Jurisdiction.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
            
            if (criteria.getContent() != null && criteria.getContent().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getContent() + "%"));
            }
            if (criteria.getLanguage() != null && criteria.getLanguage().length() > 1) {
                crit.add(Restrictions.eq("name.language", criteria.getLanguage()));
            }           
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }
            
            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());            

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @Override
    public Long getTotalItems(JurisdictionCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Jurisdiction.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
             
            if (criteria.getContent() != null && criteria.getContent().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getContent() + "%"));
            }
            if (criteria.getLanguage() != null && criteria.getLanguage().length() > 1) {
                crit.add(Restrictions.eq("name.language", criteria.getLanguage()));
            }           
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }
            
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }
}
