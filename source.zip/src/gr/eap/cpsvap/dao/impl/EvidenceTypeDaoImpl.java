package gr.eap.cpsvap.dao.impl;


import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.EvidenceType;
import gr.eap.cpsvap.vo.criteria.EvidenceTypeCriteria;
import java.util.List;

import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.EvidenceTypeDAO;

@Repository
public class EvidenceTypeDaoImpl extends AbstractGenericDaoImpl<EvidenceType, Integer> 
        implements EvidenceTypeDAO {
   
    @SuppressWarnings("unchecked")
    @Override
    public List<EvidenceType> list(EvidenceTypeCriteria criteria) {

        List<EvidenceType> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            //     Session session = sf.openSession();
            //      Transaction tx = session.beginTransaction();
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(EvidenceType.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Description
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description", criteria.getDescription() + "%"));
            }
         
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<EvidenceType> list(EvidenceTypeCriteria criteria, PagerResults pager) {

        List<EvidenceType> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            //     Session session = sf.openSession();
            //      Transaction tx = session.beginTransaction();
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(EvidenceType.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Description
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description", criteria.getDescription() + "%"));
            }
         
            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @Override
    public Long getTotalItems(EvidenceTypeCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(EvidenceType.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Description
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description", criteria.getDescription() + "%"));
            }
              
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }
}
