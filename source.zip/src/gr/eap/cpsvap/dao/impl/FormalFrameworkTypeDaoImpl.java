package gr.eap.cpsvap.dao.impl;

import gr.eap.cpsvap.common.PagerResults;

import org.springframework.stereotype.Repository;

import gr.eap.cpsvap.entity.helper.FormalFrameworkType;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkTypeCriteria;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.FormalFrameworkTypeDAO;

@Repository
public class FormalFrameworkTypeDaoImpl extends AbstractGenericDaoImpl<FormalFrameworkType, Integer>
        implements FormalFrameworkTypeDAO {

    
    @Override
    public List<FormalFrameworkType> list(FormalFrameworkTypeCriteria criteria) {

        List<FormalFrameworkType> list = new ArrayList<>();
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(FormalFrameworkType.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Name
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name", criteria.getName() + "%"));
            }

            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<FormalFrameworkType> list(FormalFrameworkTypeCriteria criteria, PagerResults pager) {

        List<FormalFrameworkType> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(FormalFrameworkType.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Name
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name", criteria.getName() + "%"));
            }

            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());

            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public Long getTotalItems(FormalFrameworkTypeCriteria criteria) {
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(FormalFrameworkType.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
            // Name
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name", criteria.getName() + "%"));
            }

            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }

}
