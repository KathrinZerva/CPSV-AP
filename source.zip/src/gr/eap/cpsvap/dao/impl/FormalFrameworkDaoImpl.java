package gr.eap.cpsvap.dao.impl;


import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;
import java.util.List;

import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.FormalFrameworkDAO;
import gr.eap.cpsvap.entity.FormalFramework;

@Repository
public class FormalFrameworkDaoImpl extends AbstractGenericDaoImpl<FormalFramework, Integer> 
        implements FormalFrameworkDAO {
   
    @SuppressWarnings("unchecked")
    @Override
    public List<FormalFramework> list(FormalFrameworkCriteria criteria) {

        List<FormalFramework> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(FormalFramework.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Ονομασία
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getName() + "%"));
            }
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description.content", criteria.getDescription() + "%"));
            }          
            if (criteria.getNotEqualId() != null && criteria.getNotEqualId() > 0) {
                crit.add(Restrictions.ne("id", criteria.getNotEqualId()));
            }             
            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<FormalFramework> list(FormalFrameworkCriteria criteria, PagerResults pager) {

        List<FormalFramework> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(FormalFramework.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Ονομασία
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getName() + "%"));
            }
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description.content", criteria.getDescription() + "%"));
            } 
            if (criteria.getNotEqualId() != null && criteria.getNotEqualId() > 0) {
                crit.add(Restrictions.ne("id", criteria.getNotEqualId()));
            }               
            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @Override
    public Long getTotalItems(FormalFrameworkCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(FormalFramework.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Ονομασία
            if (criteria.getName() != null && criteria.getName().length() > 0) {
                crit.add(Restrictions.like("name.content", criteria.getName() + "%"));
            }
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description.content", criteria.getDescription() + "%"));
            }  
            if (criteria.getNotEqualId() != null && criteria.getNotEqualId() > 0) {
                crit.add(Restrictions.ne("id", criteria.getNotEqualId()));
            }               
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }
}
