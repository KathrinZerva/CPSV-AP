package gr.eap.cpsvap.dao.impl;

import gr.eap.cpsvap.common.PagerResults;

import org.springframework.stereotype.Repository;

import gr.eap.cpsvap.vo.criteria.PublicServiceCriteria;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.PublicServiceDAO;
import gr.eap.cpsvap.entity.PublicService;
import org.hibernate.criterion.Disjunction;

@Repository
public class PublicServiceDaoImpl extends AbstractGenericDaoImpl<PublicService, Integer>
        implements PublicServiceDAO {

    
    @Override
    public List<PublicService> list(PublicServiceCriteria criteria) {

        List<PublicService> list = new ArrayList<>();
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(PublicService.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Name
            if (criteria.getNameContent() != null && criteria.getNameContent().length() > 0) {
                crit.add(Restrictions.like("name.content", "%"+ criteria.getNameContent() + "%"));
            }
            // Language
            if (criteria.getNameLanguage() != null && criteria.getNameLanguage().length() >= 2) {
                crit.add(Restrictions.eq("name.language", criteria.getNameLanguage()));
            }
            // Status
            if (criteria.getStatusId() != null && criteria.getStatusId() > 0) {
                crit.add(Restrictions.eq("status.id", criteria.getStatusId()));
            }            
            
            if(criteria.getNotIds() != null && criteria.getNotIds().size() > 0){
                crit.add(Restrictions.not(Restrictions.in("id", criteria.getNotIds())));
            }
             // query
            if (criteria.getQuery() != null && criteria.getQuery().length() > 0) {
                Disjunction or = Restrictions.disjunction();
                or.add(Restrictions.like("name.content", "%"+ criteria.getQuery() + "%"));
                or.add(Restrictions.like("description.content", "%"+ criteria.getQuery() + "%"));                
                crit.add(or);                
            }           
            
            
            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<PublicService> list(PublicServiceCriteria criteria, PagerResults pager) {

        List<PublicService> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(PublicService.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Name
            if (criteria.getNameContent() != null && criteria.getNameContent().length() > 0) {
                crit.add(Restrictions.like("name.content", "%"+ criteria.getNameContent() + "%"));
            }
            // Language
            if (criteria.getNameLanguage() != null && criteria.getNameLanguage().length() >= 2) {
                crit.add(Restrictions.eq("name.language", criteria.getNameLanguage()));
            }
            // Status
            if (criteria.getStatusId() != null && criteria.getStatusId() > 0) {
                crit.add(Restrictions.eq("status.id", criteria.getStatusId()));
            } 
             // query
            if (criteria.getQuery() != null && criteria.getQuery().length() > 0) {
                Disjunction or = Restrictions.disjunction();
                or.add(Restrictions.like("name.content", "%"+ criteria.getQuery() + "%"));
                or.add(Restrictions.like("description.content", "%"+ criteria.getQuery() + "%"));                
                crit.add(or);                
            }              
            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());

            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public Long getTotalItems(PublicServiceCriteria criteria) {
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(PublicService.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
            // Name
            if (criteria.getNameContent() != null && criteria.getNameContent().length() > 0) {
                crit.add(Restrictions.like("name.content", "%"+ criteria.getNameContent() + "%"));
            }
            // Language
            if (criteria.getNameLanguage() != null && criteria.getNameLanguage().length() >= 2) {
                crit.add(Restrictions.eq("name.language", criteria.getNameLanguage()));
            }
            // Status
            if (criteria.getStatusId() != null && criteria.getStatusId() > 0) {
                crit.add(Restrictions.eq("status.id", criteria.getStatusId()));
            } 
             // query
            if (criteria.getQuery() != null && criteria.getQuery().length() > 0) {
                Disjunction or = Restrictions.disjunction();
                or.add(Restrictions.like("name.content", "%"+ criteria.getQuery() + "%"));
                or.add(Restrictions.like("description.content", "%"+ criteria.getQuery() + "%"));                
                crit.add(or);                
            }  
            
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }

}
