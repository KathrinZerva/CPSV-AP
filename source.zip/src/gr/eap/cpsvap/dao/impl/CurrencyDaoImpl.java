package gr.eap.cpsvap.dao.impl;

import gr.eap.cpsvap.common.PagerResults;

import org.springframework.stereotype.Repository;

import gr.eap.cpsvap.entity.helper.Currency;
import gr.eap.cpsvap.vo.criteria.CurrencyCriteria;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.CurrencyDAO;

@Repository
public class CurrencyDaoImpl extends AbstractGenericDaoImpl<Currency, Integer>
        implements CurrencyDAO {

    
    @Override
    public List<Currency> list(CurrencyCriteria criteria) {

        List<Currency> list = new ArrayList<>();
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Currency.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Description
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description", criteria.getDescription() + "%"));
            }
            // code
            if (criteria.getCode() != null && criteria.getCode().length() > 0) {
                crit.add(Restrictions.like("code", criteria.getCode() + "%"));
            }
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Currency> list(CurrencyCriteria criteria, PagerResults pager) {

        List<Currency> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Currency.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            // Description
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description", criteria.getDescription() + "%"));
            }
            // code
            if (criteria.getCode() != null && criteria.getCode().length() > 0) {
                crit.add(Restrictions.like("code", criteria.getCode() + "%"));
            }

            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());

            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public Long getTotalItems(CurrencyCriteria criteria) {
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Currency.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
            
            // Description
            if (criteria.getDescription() != null && criteria.getDescription().length() > 0) {
                crit.add(Restrictions.like("description", criteria.getDescription() + "%"));
            }
            // code
            if (criteria.getCode() != null && criteria.getCode().length() > 0) {
                crit.add(Restrictions.like("code", criteria.getCode() + "%"));
            }
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }

}
