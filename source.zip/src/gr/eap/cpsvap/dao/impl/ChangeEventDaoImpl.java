package gr.eap.cpsvap.dao.impl;


import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ChangeEvent;
import gr.eap.cpsvap.vo.criteria.ChangeEventCriteria;
import java.util.List;

import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import gr.eap.cpsvap.dao.ChangeEventDAO;

@Repository
public class ChangeEventDaoImpl extends AbstractGenericDaoImpl<ChangeEvent, Integer> 
        implements ChangeEventDAO {
   
    @SuppressWarnings("unchecked")
    @Override
    public List<ChangeEvent> list(ChangeEventCriteria criteria) {

        List<ChangeEvent> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            //     Session session = sf.openSession();
            //      Transaction tx = session.beginTransaction();
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(ChangeEvent.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);
         
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ChangeEvent> list(ChangeEventCriteria criteria, PagerResults pager) {

        List<ChangeEvent> list = new ArrayList<>();
        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            //     Session session = sf.openSession();
            //      Transaction tx = session.beginTransaction();
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(ChangeEvent.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            crit.setFirstResult((int) pager.getItemsStart());
            crit.setMaxResults((int) pager.getPageItems());            
            if ("asc".equals(criteria.getOrderType())) {
                crit.addOrder(Order.asc(criteria.getOrderField()));
            } else {
                crit.addOrder(Order.desc(criteria.getOrderField()));
            }

            try {
                list = crit.list();
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    @Override
    public Long getTotalItems(ChangeEventCriteria criteria) {

        // Έλεγχος για τιμές και αντίστοιχα δημιουργία των κριτηρίων
        if (criteria != null) {
            Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(ChangeEvent.class);
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            crit.setFetchMode("permissions", FetchMode.JOIN);

            
            crit.setProjection(Projections.rowCount());
            try {
                List result = crit.list();
                if (result != null) {
                    return (Long) result.get(0);
                }
            } catch (HibernateException e) {
                e.printStackTrace();
            }
        }
        return 0l;
    }
}
