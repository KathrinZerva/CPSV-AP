package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Duration;
import gr.eap.cpsvap.vo.criteria.DurationCriteria;

public interface DurationDAO {

    public Duration get(Integer id);
    public List<Duration> list(DurationCriteria criteria);    
    public List<Duration> list(DurationCriteria criteria,  PagerResults pager);
    public Long getTotalItems(DurationCriteria criteria);
    public void save(Duration duration);
    public void delete(Integer id);    
}
