package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.vo.criteria.EvidenceCriteria;

public interface EvidenceDAO {

    public Evidence get(Integer id);
    public List<Evidence> list(EvidenceCriteria criteria);    
    public List<Evidence> list(EvidenceCriteria criteria,  PagerResults pager);
    public Long getTotalItems(EvidenceCriteria criteria);
    public void save(Evidence evidence);
    public void delete(Integer id);    
}
