package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.helper.Currency;
import gr.eap.cpsvap.vo.criteria.CurrencyCriteria;
import java.util.List;

public interface CurrencyDAO {
    
    public Currency get(Integer id);
    public List<Currency> list(CurrencyCriteria criteria);    
    public List<Currency> list(CurrencyCriteria criteria,  PagerResults pager);
    public Long getTotalItems(CurrencyCriteria criteria);
    public void save(Currency currency);
    public void delete(Integer id);
}
