package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.DocumentReference;
import gr.eap.cpsvap.vo.criteria.DocumentReferenceCriteria;

public interface DocumentReferenceDAO {

    public DocumentReference get(Integer id);
    public List<DocumentReference> list(DocumentReferenceCriteria criteria);    
    public List<DocumentReference> list(DocumentReferenceCriteria criteria,  PagerResults pager);
    public Long getTotalItems(DocumentReferenceCriteria criteria);
    public void save(DocumentReference documentReference);
    public void delete(Integer id);    
}
