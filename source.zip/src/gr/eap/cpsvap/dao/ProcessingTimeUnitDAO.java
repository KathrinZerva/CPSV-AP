package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.helper.ProcessingTimeUnit;
import gr.eap.cpsvap.vo.criteria.ProcessingTimeUnitCriteria;
import java.util.List;

public interface ProcessingTimeUnitDAO {
    
    public ProcessingTimeUnit get(Integer id);
    public List<ProcessingTimeUnit> list(ProcessingTimeUnitCriteria criteria);    
    public List<ProcessingTimeUnit> list(ProcessingTimeUnitCriteria criteria,  PagerResults pager);
    public Long getTotalItems(ProcessingTimeUnitCriteria criteria);
    public void save(ProcessingTimeUnit processingTimeUnit);
    public void delete(Integer id);
}
