package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirementType;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementTypeCriteria;

public interface CriterionRequirementTypeDAO {

    public CriterionRequirementType get(Integer id);
    public List<CriterionRequirementType> list(CriterionRequirementTypeCriteria criteria);    
    public List<CriterionRequirementType> list(CriterionRequirementTypeCriteria criteria,  PagerResults pager);
    public Long getTotalItems(CriterionRequirementTypeCriteria criteria);
    public void save(CriterionRequirementType criterionRequirementType);
    public void delete(Integer id);    
}
