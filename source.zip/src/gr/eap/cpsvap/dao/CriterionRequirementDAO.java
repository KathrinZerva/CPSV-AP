package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementCriteria;

public interface CriterionRequirementDAO {

    public CriterionRequirement get(Integer id);
    public List<CriterionRequirement> list(CriterionRequirementCriteria criteria);    
    public List<CriterionRequirement> list(CriterionRequirementCriteria criteria,  PagerResults pager);
    public Long getTotalItems(CriterionRequirementCriteria criteria);
    public void save(CriterionRequirement criterionRequirement);
    public void delete(Integer id);    
}
