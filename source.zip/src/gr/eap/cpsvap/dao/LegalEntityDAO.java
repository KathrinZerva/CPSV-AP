package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.LegalEntity;
import gr.eap.cpsvap.vo.criteria.LegalEntityCriteria;

public interface LegalEntityDAO {

    public LegalEntity get(Integer id);
    public List<LegalEntity> list(LegalEntityCriteria criteria);    
    public List<LegalEntity> list(LegalEntityCriteria criteria,  PagerResults pager);
    public Long getTotalItems(LegalEntityCriteria criteria);
    public void save(LegalEntity legalEntity);
    public void delete(Integer id);    
}
