package gr.eap.cpsvap.dao;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicServiceDataset;
import gr.eap.cpsvap.vo.criteria.PublicServiceDatasetCriteria;
import java.util.List;

public interface PublicServiceDatasetDAO {
    
    public PublicServiceDataset get(Integer id);
    public List<PublicServiceDataset> list(PublicServiceDatasetCriteria criteria);    
    public List<PublicServiceDataset> list(PublicServiceDatasetCriteria criteria,  PagerResults pager);
    public Long getTotalItems(PublicServiceDatasetCriteria criteria);
    public void save(PublicServiceDataset publicServiceDataset);
    public void delete(Integer id);
}
