package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.vo.criteria.CriterionCriteria;

public interface CriterionDAO {

    public Criterion get(Integer id);
    public List<Criterion> list(CriterionCriteria criteria);    
    public List<Criterion> list(CriterionCriteria criteria,  PagerResults pager);
    public Long getTotalItems(CriterionCriteria criteria);
    public void save(Criterion criterion);
    public void delete(Integer id);    
}
