package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PeriodOfTime;
import gr.eap.cpsvap.vo.criteria.PeriodOfTimeCriteria;

public interface PeriodOfTimeDAO {

    public PeriodOfTime get(Integer id);
    public List<PeriodOfTime> list(PeriodOfTimeCriteria criteria);    
    public List<PeriodOfTime> list(PeriodOfTimeCriteria criteria,  PagerResults pager);
    public Long getTotalItems(PeriodOfTimeCriteria criteria);
    public void save(PeriodOfTime participation);
    public void delete(Integer id);    
}
