package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Organization;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;

public interface PublicOrganizationDAO {

    public PublicOrganization get(Integer id);
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria);    
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria,  PagerResults pager);
    public Long getTotalItems(PublicOrganizationCriteria criteria);
    public void save(PublicOrganization organization);
    public void delete(Integer id);    
}
