package gr.eap.cpsvap.dao;

import java.util.List;
import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Output;
import gr.eap.cpsvap.vo.criteria.OutputCriteria;

public interface OutputDAO {

    public Output get(Integer id);
    public List<Output> list(OutputCriteria criteria);    
    public List<Output> list(OutputCriteria criteria,  PagerResults pager);
    public Long getTotalItems(OutputCriteria criteria);
    public void save(Output output);
    public void delete(Integer id);    
}
