package gr.eap.cpsvap.vo.criteria;

public class UserCriteria extends GenericCriteria {

    String name;
    String userName;

    public UserCriteria() {
        this.orderType = "asc";
        this.orderField = "name";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }



}
