package gr.eap.cpsvap.vo.criteria;

public class ChangeEventCriteria extends GenericCriteria {


    public ChangeEventCriteria() {
        this.orderType = "asc";
        this.orderField = "id";
    }

   
}
