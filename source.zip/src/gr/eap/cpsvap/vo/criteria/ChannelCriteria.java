package gr.eap.cpsvap.vo.criteria;

public class ChannelCriteria extends GenericCriteria {
 
    String identifierContent;
     
    public ChannelCriteria() {
        this.orderType = "asc";
        this.orderField = "identifier.content";
    }

    public String getIdentifierContent() {
        return identifierContent;
    }

    public void setIdentifierContent(String identifierContent) {
        this.identifierContent = identifierContent;
    }

}
