package gr.eap.cpsvap.vo.criteria;

public class RuleCriteria extends GenericCriteria {

    String name;  

    public RuleCriteria() {
        this.orderType = "asc";
        this.orderField = "name.content";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   
}
