package gr.eap.cpsvap.vo.criteria;

public class LocationCriteria extends GenericCriteria {
    

    String nameContent;  

    public LocationCriteria() {
        this.orderType = "asc";
        this.orderField = "geographicName.content";
    }

    public String getNameContent() {
        return nameContent;
    }

    public void setNameContent(String nameContent) {
        this.nameContent = nameContent;
    }

   
}
