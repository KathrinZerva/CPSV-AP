package gr.eap.cpsvap.vo.criteria;

public class SectorCriteria extends GenericCriteria {

    String code;  

    public SectorCriteria() {
        this.orderType = "asc";
        this.orderField = "code";
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

   
}
