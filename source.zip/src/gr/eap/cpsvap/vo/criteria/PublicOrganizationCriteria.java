package gr.eap.cpsvap.vo.criteria;

import java.util.ArrayList;
import java.util.List;

public class PublicOrganizationCriteria extends GenericCriteria {

    List<Integer> notIds;
    
    public PublicOrganizationCriteria() {
        this.orderType = "asc";
        this.orderField = "id";
        notIds = new ArrayList<>(); 
    }

    public List<Integer> getNotIds() {
        return notIds;
    }

    public void setNotIds(List<Integer> notIds) {
        this.notIds = notIds;
    }



   
}
