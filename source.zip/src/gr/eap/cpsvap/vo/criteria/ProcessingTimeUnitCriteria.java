package gr.eap.cpsvap.vo.criteria;

public class ProcessingTimeUnitCriteria extends GenericCriteria {

    String name;

    public ProcessingTimeUnitCriteria() {
        this.orderType = "asc";
        this.orderField = "id";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
