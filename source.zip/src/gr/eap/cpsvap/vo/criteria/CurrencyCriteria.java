package gr.eap.cpsvap.vo.criteria;

public class CurrencyCriteria extends GenericCriteria {

    String code;
    String description;

    public CurrencyCriteria() {
        this.orderType = "asc";
        this.orderField = "code";
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}
