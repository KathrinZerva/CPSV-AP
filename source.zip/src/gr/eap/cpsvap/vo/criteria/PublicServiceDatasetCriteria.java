package gr.eap.cpsvap.vo.criteria;

public class PublicServiceDatasetCriteria extends GenericCriteria {

    String nameContent;  

    public PublicServiceDatasetCriteria() {
        this.orderType = "asc";
        this.orderField = "name.content";
    }

    public String getNameContent() {
        return nameContent;
    }

    public void setNameContent(String nameContent) {
        this.nameContent = nameContent;
    }

   
}
