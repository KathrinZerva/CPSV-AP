/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.vo.criteria;

/**
 *
 * @author Administrator
 */
public class GenericCriteria {
    protected String orderType = "asc";
    protected String orderField;

    public GenericCriteria() {
    }

    
    
    public GenericCriteria(String orderField) {
        this.orderField = orderField;
    }

    
    
    public String getOrderField() {
        return orderField;
    }

    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    
    
    @Override
    public String toString() {
        return "GenericCriteria{" + "orderType=" + orderType + ", orderField=" + orderField + '}';
    }
    
    
}
