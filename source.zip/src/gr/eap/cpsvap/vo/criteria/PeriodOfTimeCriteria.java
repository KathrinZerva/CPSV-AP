package gr.eap.cpsvap.vo.criteria;

public class PeriodOfTimeCriteria extends GenericCriteria {
    

    public PeriodOfTimeCriteria() {
        this.orderType = "asc";
        this.orderField = "startDate";
    }


   
}
