package gr.eap.cpsvap.vo.criteria;

import java.util.ArrayList;
import java.util.List;

public class PublicServiceCriteria extends GenericCriteria {

    String nameContent;
    String nameLanguage;
    Integer statusId;
    List<Integer> notIds;
    String query;

    public PublicServiceCriteria() {
        this.orderType = "asc";
        this.orderField = "name.content";
        notIds = new ArrayList<>();
    }

    public String getNameContent() {
        return nameContent;
    }

    public void setNameContent(String nameContent) {
        this.nameContent = nameContent;
    }

    public String getNameLanguage() {
        return nameLanguage;
    }

    public void setNameLanguage(String nameLanguage) {
        this.nameLanguage = nameLanguage;
    }

    public Integer getStatusId() {
        return statusId;
    }

    public void setStatusId(Integer statusId) {
        this.statusId = statusId;
    }

    public List<Integer> getNotIds() {
        return notIds;
    }

    public void setNotIds(List<Integer> notIds) {
        this.notIds = notIds;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

 
}
