package gr.eap.cpsvap.vo.criteria;

public class ProcessingTimeCriteria extends GenericCriteria {


    public ProcessingTimeCriteria() {
        this.orderType = "asc";
        this.orderField = "id";
    }


}
