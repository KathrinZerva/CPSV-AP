package gr.eap.cpsvap.vo.criteria;

public class CostCriteria extends GenericCriteria {

    String content; 
    String language;     

    public CostCriteria() {
        this.orderType = "asc";
        this.orderField = "description.content";
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

   
}
