package gr.eap.cpsvap.vo.criteria;

public class RequirementGroupCriteria extends GenericCriteria {

    String name;  

    public RequirementGroupCriteria() {
        this.orderType = "asc";
        this.orderField = "description.content";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   
}
