package gr.eap.cpsvap.vo.criteria;

public class CriterionRequirementTypeCriteria extends GenericCriteria {

    String description;  

    public CriterionRequirementTypeCriteria() {
        this.orderType = "asc";
        this.orderField = "description";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


   
}
