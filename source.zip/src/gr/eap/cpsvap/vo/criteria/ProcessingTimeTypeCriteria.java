package gr.eap.cpsvap.vo.criteria;

public class ProcessingTimeTypeCriteria extends GenericCriteria {

    String name;

    public ProcessingTimeTypeCriteria() {
        this.orderType = "asc";
        this.orderField = "name";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
