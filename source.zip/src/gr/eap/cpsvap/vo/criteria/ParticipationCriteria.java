package gr.eap.cpsvap.vo.criteria;

public class ParticipationCriteria extends GenericCriteria {

    String content; 
    String language;     

    public ParticipationCriteria() {
        this.orderType = "asc";
        this.orderField = "description.content";
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

   
}
