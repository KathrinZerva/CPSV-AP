package gr.eap.cpsvap.vo.criteria;

public class EvidenceTypeCriteria extends GenericCriteria {

    String description;  

    public EvidenceTypeCriteria() {
        this.orderType = "asc";
        this.orderField = "description";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


   
}
