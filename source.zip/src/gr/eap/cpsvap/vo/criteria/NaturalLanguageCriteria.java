package gr.eap.cpsvap.vo.criteria;

public class NaturalLanguageCriteria extends GenericCriteria {

    String code;
    String name;

    public NaturalLanguageCriteria() {
        this.orderType = "asc";
        this.orderField = "name";
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
