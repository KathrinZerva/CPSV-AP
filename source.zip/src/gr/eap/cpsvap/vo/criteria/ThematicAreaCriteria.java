package gr.eap.cpsvap.vo.criteria;

public class ThematicAreaCriteria extends GenericCriteria {

    String description;  

    public ThematicAreaCriteria() {
        this.orderType = "asc";
        this.orderField = "description";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


   
}
