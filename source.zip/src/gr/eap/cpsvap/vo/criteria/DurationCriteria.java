package gr.eap.cpsvap.vo.criteria;

public class DurationCriteria extends GenericCriteria {

   public DurationCriteria() {
        this.orderType = "asc";
        this.orderField = "id";
    }

}
