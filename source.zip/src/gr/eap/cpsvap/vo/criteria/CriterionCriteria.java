package gr.eap.cpsvap.vo.criteria;

public class CriterionCriteria extends GenericCriteria {

    String name;  

    public CriterionCriteria() {
        this.orderType = "asc";
        this.orderField = "name.content";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   
}
