package gr.eap.cpsvap.vo.criteria;

public class JurisdictionCriteria extends GenericCriteria {

    String content; 
    String language;     

    public JurisdictionCriteria() {
        this.orderType = "asc";
        this.orderField = "name.content";
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

   
}
