package gr.eap.cpsvap.vo.criteria;

public class ContactPointCriteria extends GenericCriteria {

    String name;  

    public ContactPointCriteria() {
        this.orderType = "asc";
        this.orderField = "name";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   
}
