package gr.eap.cpsvap.vo.criteria;

public class DocumentReferenceCriteria extends GenericCriteria {

    String description;

    public DocumentReferenceCriteria() {
        this.orderType = "asc";
        this.orderField = "description.content";
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

   
}
