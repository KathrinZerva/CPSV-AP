package gr.eap.cpsvap.vo.criteria;

public class PublicServiceTypeCriteria extends GenericCriteria {

    String description;  

    public PublicServiceTypeCriteria() {
        this.orderType = "asc";
        this.orderField = "description";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


   
}
