package gr.eap.cpsvap.vo.criteria;

public class ChannelTypeCriteria extends GenericCriteria {

    String description;  

    public ChannelTypeCriteria() {
        this.orderType = "asc";
        this.orderField = "description";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


   
}
