package gr.eap.cpsvap.vo.criteria;

public class FormalFrameworkCriteria extends GenericCriteria {

    String name; 
    String description;   
    Integer notEqualId;

    public FormalFrameworkCriteria() {
        this.orderType = "asc";
        this.orderField = "name.content";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getNotEqualId() {
        return notEqualId;
    }

    public void setNotEqualId(Integer notEqualId) {
        this.notEqualId = notEqualId;
    }

}
