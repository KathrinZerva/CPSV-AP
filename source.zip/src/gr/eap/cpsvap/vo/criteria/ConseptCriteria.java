package gr.eap.cpsvap.vo.criteria;

public class ConseptCriteria extends GenericCriteria {

    String prefLabel; 

    public ConseptCriteria() {
        this.orderType = "asc";
        this.orderField = "prefLabel.content";
    }

    public String getPrefLabel() {
        return prefLabel;
    }

    public void setPrefLabel(String prefLabel) {
        this.prefLabel = prefLabel;
    }



}
