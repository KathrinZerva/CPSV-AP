/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.eap.cpsvap.vo;

/**
 *
 * @author Katerina Zerva
 */
public class RealEstateVO {
    Integer year;
    Float mainHouseArea;
    Float auxilarySpaceArea;
    Integer months = 12;
    Float percent = 100f;
    Boolean detachedHouse = Boolean.TRUE;
    Boolean mainHouse = Boolean.TRUE; 
    Float incrementPercent;

    public RealEstateVO() {
    }

    public RealEstateVO(Integer year, Float mainHouseArea, Float auxilarySpaceArea) {
        this.year = year;
        this.mainHouseArea = mainHouseArea;
        this.auxilarySpaceArea = auxilarySpaceArea;
    }
    
     public RealEstateVO(Integer year, Float mainHouseArea, Float auxilarySpaceArea, Boolean detachedHouse) {
       this(year, mainHouseArea, auxilarySpaceArea);
       this.detachedHouse = detachedHouse;
    }
     
     public RealEstateVO(Integer year, Float mainHouseArea, Float auxilarySpaceArea, Boolean detachedHouse, Integer months) {
       this(year, mainHouseArea, auxilarySpaceArea, detachedHouse);
       this.months = months;
    }
     public RealEstateVO(Integer year, Float mainHouseArea, Float auxilarySpaceArea, Boolean detachedHouse,
             Integer months, Float percent) {
       this(year, mainHouseArea, auxilarySpaceArea, detachedHouse, months);
       this.percent = percent;
    }          
     public RealEstateVO(Integer year, Float mainHouseArea, Float auxilarySpaceArea, Boolean detachedHouse,
             Integer months, Float percent, Boolean mainHouse) {
       this(year, mainHouseArea, auxilarySpaceArea, detachedHouse, months, percent);
       this.mainHouse = mainHouse;
    }          
     public RealEstateVO(Integer year, Float mainHouseArea, Float auxilarySpaceArea, Boolean detachedHouse,
             Integer months, Float percent, Boolean mainHouse, Float incrementPercent) {
       this(year, mainHouseArea, auxilarySpaceArea, detachedHouse, months, percent, mainHouse);
       this.incrementPercent = incrementPercent;
    }  
     
    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }
 
     
    public Float getMainHouseArea() {
        return mainHouseArea;
    }

    public void setMainHouseArea(Float mainHouseArea) {
        this.mainHouseArea = mainHouseArea;
    }

    public Float getAuxilarySpaceArea() {
        return auxilarySpaceArea;
    }

    public void setAuxilarySpaceArea(Float auxilarySpaceArea) {
        this.auxilarySpaceArea = auxilarySpaceArea;
    }

    public Boolean getDetachedHouse() {
        return detachedHouse;
    }

    public void setDetachedHouse(Boolean detachedHouse) {
        this.detachedHouse = detachedHouse;
    }

    public Integer getMonths() {
        return months;
    }

    public void setMonths(Integer months) {
        this.months = months;
    }

    public Float getPercent() {
        return percent;
    }

    public void setPercent(Float percent) {
        this.percent = percent;
    }

    public Boolean getMainHouse() {
        return mainHouse;
    }

    public void setMainHouse(Boolean mainHouse) {
        this.mainHouse = mainHouse;
    }

    public Float getIncrementPercent() {
        return incrementPercent;
    }

    public void setIncrementPercent(Float incrementPercent) {
        this.incrementPercent = incrementPercent;
    }
    
    
    
}
