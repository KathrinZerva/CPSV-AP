package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;
import java.util.List;



public interface RequirementResponceManager {

    public RequirementResponce get(Integer id);
    public List<RequirementResponce> list(RequirementResponceCriteria criteria);    
    public List<RequirementResponce> list(RequirementResponceCriteria criteria, PagerResults pager);
    public Long getTotalItems(RequirementResponceCriteria criteria);
    public void save(RequirementResponce requirementResponce);
    public void delete(Integer id);    
}
