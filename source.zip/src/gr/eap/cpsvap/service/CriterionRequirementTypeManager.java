package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirementType;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementTypeCriteria;
import java.util.List;



public interface CriterionRequirementTypeManager {

    public CriterionRequirementType get(Integer id);
    public List<CriterionRequirementType> list(CriterionRequirementTypeCriteria criteria);    
    public List<CriterionRequirementType> list(CriterionRequirementTypeCriteria criteria, PagerResults pager);
    public Long getTotalItems(CriterionRequirementTypeCriteria criteria);
    public void save(CriterionRequirementType criterionRequirementType);
    public void delete(Integer id);    
}
