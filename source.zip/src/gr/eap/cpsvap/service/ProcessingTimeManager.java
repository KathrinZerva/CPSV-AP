package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ProcessingTime;
import gr.eap.cpsvap.vo.criteria.ProcessingTimeCriteria;
import java.util.List;

public interface ProcessingTimeManager {

    public ProcessingTime get(Integer id);

    public List<ProcessingTime> list(ProcessingTimeCriteria criteria);

    public List<ProcessingTime> list(ProcessingTimeCriteria criteria, PagerResults pager);

    public Long getTotalItems(ProcessingTimeCriteria criteria);

    public void save(ProcessingTime processingTime);

    public void delete(Integer id);
}
