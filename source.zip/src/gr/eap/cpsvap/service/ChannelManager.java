package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Channel;
import gr.eap.cpsvap.vo.criteria.ChannelCriteria;
import java.util.List;



public interface ChannelManager {

    public Channel get(Integer id);
    public List<Channel> list(ChannelCriteria criteria);    
    public List<Channel> list(ChannelCriteria criteria, PagerResults pager);
    public Long getTotalItems(ChannelCriteria criteria);
    public void save(Channel channel);
    public void delete(Integer id);    
}
