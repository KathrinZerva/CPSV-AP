package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Cost;
import gr.eap.cpsvap.vo.criteria.CostCriteria;
import java.util.List;



public interface CostManager {

    public Cost get(Integer id);
    public List<Cost> list(CostCriteria criteria);    
    public List<Cost> list(CostCriteria criteria, PagerResults pager);
    public Long getTotalItems(CostCriteria criteria);
    public void save(Cost cost);
    public void delete(Integer id);    
}
