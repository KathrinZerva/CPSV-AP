package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicServiceStatus;
import gr.eap.cpsvap.vo.criteria.PublicServiceStatusCriteria;
import java.util.List;



public interface PublicServiceStatusManager {

    public PublicServiceStatus get(Integer id);
    public List<PublicServiceStatus> list(PublicServiceStatusCriteria criteria);    
    public List<PublicServiceStatus> list(PublicServiceStatusCriteria criteria, PagerResults pager);
    public Long getTotalItems(PublicServiceStatusCriteria criteria);
    public void save(PublicServiceStatus publicServiceStatus);
    public void delete(Integer id);    
}
