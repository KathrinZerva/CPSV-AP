package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;
import java.util.List;



public interface FormalFrameworkManager {

    public FormalFramework get(Integer id);
    public List<FormalFramework> list(FormalFrameworkCriteria criteria);    
    public List<FormalFramework> list(FormalFrameworkCriteria criteria, PagerResults pager);
    public Long getTotalItems(FormalFrameworkCriteria criteria);
    public void save(FormalFramework formalFramework);
    public void delete(Integer id);  
    public FormalFramework merge(FormalFramework formalFramework); 
    public void evict(FormalFramework formalFramework);  
    
    public void dumpHibernateSession(); 
    
}
