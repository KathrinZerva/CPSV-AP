package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Consept;
import gr.eap.cpsvap.vo.criteria.ConseptCriteria;
import java.util.List;



public interface ConseptManager {

    public Consept get(Integer id);
    public List<Consept> list(ConseptCriteria criteria);    
    public List<Consept> list(ConseptCriteria criteria, PagerResults pager);
    public Long getTotalItems(ConseptCriteria criteria);
    public void save(Consept consept);
    public void delete(Integer id);    
}
