package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.EvidenceType;
import gr.eap.cpsvap.vo.criteria.EvidenceTypeCriteria;
import java.util.List;



public interface EvidenceTypeManager {

    public EvidenceType get(Integer id);
    public List<EvidenceType> list(EvidenceTypeCriteria criteria);    
    public List<EvidenceType> list(EvidenceTypeCriteria criteria, PagerResults pager);
    public Long getTotalItems(EvidenceTypeCriteria criteria);
    public void save(EvidenceType evidenceType);
    public void delete(Integer id);    
}
