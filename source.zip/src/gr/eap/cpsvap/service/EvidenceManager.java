package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.vo.criteria.EvidenceCriteria;
import java.util.List;



public interface EvidenceManager {

    public Evidence get(Integer id);
    public List<Evidence> list(EvidenceCriteria criteria);    
    public List<Evidence> list(EvidenceCriteria criteria, PagerResults pager);
    public Long getTotalItems(EvidenceCriteria criteria);
    public void save(Evidence evidence);
    public void delete(Integer id);    
}
