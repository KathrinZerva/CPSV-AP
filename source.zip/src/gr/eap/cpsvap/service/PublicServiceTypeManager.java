package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicServiceType;
import gr.eap.cpsvap.vo.criteria.PublicServiceTypeCriteria;
import java.util.List;



public interface PublicServiceTypeManager {

    public PublicServiceType get(Integer id);
    public List<PublicServiceType> list(PublicServiceTypeCriteria criteria);    
    public List<PublicServiceType> list(PublicServiceTypeCriteria criteria, PagerResults pager);
    public Long getTotalItems(PublicServiceTypeCriteria criteria);
    public void save(PublicServiceType publicServiceType);
    public void delete(Integer id);    
}
