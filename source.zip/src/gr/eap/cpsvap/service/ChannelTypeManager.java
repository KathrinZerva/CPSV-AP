package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ChannelType;
import gr.eap.cpsvap.vo.criteria.ChannelTypeCriteria;
import java.util.List;



public interface ChannelTypeManager {

    public ChannelType get(Integer id);
    public List<ChannelType> list(ChannelTypeCriteria criteria);    
    public List<ChannelType> list(ChannelTypeCriteria criteria, PagerResults pager);
    public Long getTotalItems(ChannelTypeCriteria criteria);
    public void save(ChannelType channelType);
    public void delete(Integer id);    
}
