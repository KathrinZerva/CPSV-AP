package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Sector;
import gr.eap.cpsvap.vo.criteria.SectorCriteria;
import java.util.List;



public interface SectorManager {

    public Sector get(Integer id);
    public List<Sector> list(SectorCriteria criteria);    
    public List<Sector> list(SectorCriteria criteria, PagerResults pager);
    public Long getTotalItems(SectorCriteria criteria);
    public void save(Sector sector);
    public void delete(Integer id);    
}
