package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PeriodOfTime;
import gr.eap.cpsvap.vo.criteria.PeriodOfTimeCriteria;
import java.util.List;



public interface PeriodOfTimeManager {

    public PeriodOfTime get(Integer id);
    public List<PeriodOfTime> list(PeriodOfTimeCriteria criteria);    
    public List<PeriodOfTime> list(PeriodOfTimeCriteria criteria, PagerResults pager);
    public Long getTotalItems(PeriodOfTimeCriteria criteria);
    public void save(PeriodOfTime periodOfTime);
    public void delete(Integer id);    
}
