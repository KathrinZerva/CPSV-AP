package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Jurisdiction;
import gr.eap.cpsvap.vo.criteria.JurisdictionCriteria;
import java.util.List;



public interface JurisdictionManager {

    public Jurisdiction get(Integer id);
    public List<Jurisdiction> list(JurisdictionCriteria criteria);    
    public List<Jurisdiction> list(JurisdictionCriteria criteria, PagerResults pager);
    public Long getTotalItems(JurisdictionCriteria criteria);
    public void save(Jurisdiction jurisdiction);
    public void delete(Integer id);    
}
