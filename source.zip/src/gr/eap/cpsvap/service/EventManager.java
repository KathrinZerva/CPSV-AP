package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Event;
import gr.eap.cpsvap.vo.criteria.EventCriteria;
import java.util.List;



public interface EventManager {

    public Event get(Integer id);
    public List<Event> list(EventCriteria criteria);    
    public List<Event> list(EventCriteria criteria, PagerResults pager);
    public Long getTotalItems(EventCriteria criteria);
    public void save(Event event);
    public void delete(Integer id);    
}
