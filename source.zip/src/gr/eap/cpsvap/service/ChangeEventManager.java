package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ChangeEvent;
import gr.eap.cpsvap.vo.criteria.ChangeEventCriteria;
import java.util.List;



public interface ChangeEventManager {

    public ChangeEvent get(Integer id);
    public List<ChangeEvent> list(ChangeEventCriteria criteria);    
    public List<ChangeEvent> list(ChangeEventCriteria criteria, PagerResults pager);
    public Long getTotalItems(ChangeEventCriteria criteria);
    public void save(ChangeEvent changeEvent);
    public void delete(Integer id);    
}
