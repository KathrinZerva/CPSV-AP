package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.BusinessEvent;
import gr.eap.cpsvap.vo.criteria.BusinessEventCriteria;
import java.util.List;



public interface BusinessEventManager {

    public BusinessEvent get(Integer id);
    public List<BusinessEvent> list(BusinessEventCriteria criteria);    
    public List<BusinessEvent> list(BusinessEventCriteria criteria, PagerResults pager);
    public Long getTotalItems(BusinessEventCriteria criteria);
    public void save(BusinessEvent businessEvent);
    public void delete(Integer id);    
}
