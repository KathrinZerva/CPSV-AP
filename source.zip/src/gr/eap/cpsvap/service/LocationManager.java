package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Location;
import gr.eap.cpsvap.vo.criteria.LocationCriteria;
import java.util.List;



public interface LocationManager {

    public Location get(Integer id);
    public List<Location> list(LocationCriteria criteria);    
    public List<Location> list(LocationCriteria criteria, PagerResults pager);
    public Long getTotalItems(LocationCriteria criteria);
    public void save(Location location);
    public void delete(Integer id);    
}
