package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;
import java.util.List;



public interface PublicOrganizationManager {

    public PublicOrganization get(Integer id);
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria);    
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria, PagerResults pager);
    public Long getTotalItems(PublicOrganizationCriteria criteria);
    public void save(PublicOrganization pubicOrganization);
    public void delete(Integer id);    
}
