package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.helper.ProcessingTimeType;
import gr.eap.cpsvap.vo.criteria.ProcessingTimeTypeCriteria;
import java.util.List;

public interface ProcessingTimeTypeManager {

    public ProcessingTimeType get(Integer id);

    public List<ProcessingTimeType> list(ProcessingTimeTypeCriteria criteria);

    public List<ProcessingTimeType> list(ProcessingTimeTypeCriteria criteria, PagerResults pager);

    public Long getTotalItems(ProcessingTimeTypeCriteria criteria);

    public void save(ProcessingTimeType processingTimeType);

    public void delete(Integer id);
}
