package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ThematicArea;
import gr.eap.cpsvap.vo.criteria.ThematicAreaCriteria;
import java.util.List;



public interface ThematicAreaManager {

    public ThematicArea get(Integer id);
    public List<ThematicArea> list(ThematicAreaCriteria criteria);    
    public List<ThematicArea> list(ThematicAreaCriteria criteria, PagerResults pager);
    public Long getTotalItems(ThematicAreaCriteria criteria);
    public void save(ThematicArea thematicArea);
    public void delete(Integer id);    
}
