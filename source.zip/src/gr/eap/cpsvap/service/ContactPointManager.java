package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ContactPoint;
import gr.eap.cpsvap.vo.criteria.ContactPointCriteria;
import java.util.List;



public interface ContactPointManager {

    public ContactPoint get(Integer id);
    public List<ContactPoint> list(ContactPointCriteria criteria);    
    public List<ContactPoint> list(ContactPointCriteria criteria, PagerResults pager);
    public Long getTotalItems(ContactPointCriteria criteria);
    public void save(ContactPoint contactPoint);
    public void delete(Integer id);    
}
