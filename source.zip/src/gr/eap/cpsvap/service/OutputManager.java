package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Output;
import gr.eap.cpsvap.vo.criteria.OutputCriteria;
import java.util.List;



public interface OutputManager {

    public Output get(Integer id);
    public List<Output> list(OutputCriteria criteria);    
    public List<Output> list(OutputCriteria criteria, PagerResults pager);
    public Long getTotalItems(OutputCriteria criteria);
    public void save(Output output);
    public void delete(Integer id);    
}
