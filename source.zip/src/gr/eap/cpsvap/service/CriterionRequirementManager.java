package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementCriteria;
import java.util.List;



public interface CriterionRequirementManager {

    public CriterionRequirement get(Integer id);
    public List<CriterionRequirement> list(CriterionRequirementCriteria criteria);    
    public List<CriterionRequirement> list(CriterionRequirementCriteria criteria, PagerResults pager);
    public Long getTotalItems(CriterionRequirementCriteria criteria);
    public void save(CriterionRequirement criterionRequirement);
    public void delete(Integer id);    
}
