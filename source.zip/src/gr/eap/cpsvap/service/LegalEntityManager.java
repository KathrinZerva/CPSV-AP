package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.LegalEntity;
import gr.eap.cpsvap.vo.criteria.LegalEntityCriteria;
import java.util.List;



public interface LegalEntityManager {

    public LegalEntity get(Integer id);
    public List<LegalEntity> list(LegalEntityCriteria criteria);    
    public List<LegalEntity> list(LegalEntityCriteria criteria, PagerResults pager);
    public Long getTotalItems(LegalEntityCriteria criteria);
    public void save(LegalEntity legalEntity);
    public void delete(Integer id);    
}
