package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Agent;
import gr.eap.cpsvap.vo.criteria.AgentCriteria;
import java.util.List;



public interface AgentManager {

    public Agent get(Integer id);
    public List<Agent> list(AgentCriteria criteria);    
    public List<Agent> list(AgentCriteria criteria, PagerResults pager);
    public Long getTotalItems(AgentCriteria criteria);
    public void save(Agent agent);
    public void delete(Integer id);    
}
