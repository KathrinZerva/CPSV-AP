package gr.eap.cpsvap.service;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import java.util.List;

public interface NaturalLanguageManager {

    public NaturalLanguage get(Integer id);

    public List<NaturalLanguage> list(NaturalLanguageCriteria criteria);

    public List<NaturalLanguage> list(NaturalLanguageCriteria criteria, PagerResults pager);

    public Long getTotalItems(NaturalLanguageCriteria criteria);

    public void save(NaturalLanguage naturalLanguage);

    public void delete(Integer id);
}
