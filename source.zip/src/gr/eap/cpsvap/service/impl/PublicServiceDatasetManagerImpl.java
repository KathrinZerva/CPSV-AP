package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.PublicServiceDatasetDAO;
import gr.eap.cpsvap.entity.PublicServiceDataset;
import gr.eap.cpsvap.service.PublicServiceDatasetManager;
import gr.eap.cpsvap.vo.criteria.PublicServiceDatasetCriteria;
import java.util.List;

public class PublicServiceDatasetManagerImpl implements PublicServiceDatasetManager {
    //Patient dao injected by Spring context

    private PublicServiceDatasetDAO publicServiceDatasetDAO;


    @Override
    @Transactional
    public PublicServiceDataset get(Integer id) {
        return publicServiceDatasetDAO.get(id);
    }

    @Override
    @Transactional
    public List<PublicServiceDataset> list(PublicServiceDatasetCriteria criteria) {
        return publicServiceDatasetDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<PublicServiceDataset> list(PublicServiceDatasetCriteria criteria, PagerResults pager) {
        return publicServiceDatasetDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PublicServiceDatasetCriteria criteria) {
        return publicServiceDatasetDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(PublicServiceDataset PublicServiceDataset) {
        publicServiceDatasetDAO.save(PublicServiceDataset);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        publicServiceDatasetDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPublicServiceDatasetDAO(PublicServiceDatasetDAO publicServiceDatasetDAO) {
        this.publicServiceDatasetDAO = publicServiceDatasetDAO;
    }

}
