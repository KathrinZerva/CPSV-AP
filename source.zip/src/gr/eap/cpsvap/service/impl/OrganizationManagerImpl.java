package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Organization;
import gr.eap.cpsvap.vo.criteria.OrganizationCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.OrganizationDAO;
import gr.eap.cpsvap.service.OrganizationManager;



public class OrganizationManagerImpl implements OrganizationManager {
    //Organization dao injected by Spring context

    private OrganizationDAO organizationDAO;

    @Override
    @Transactional
    public Organization get(Integer id) {
        return organizationDAO.get(id);
    }
    @Override
    @Transactional
    public List<Organization> list(OrganizationCriteria criteria) {
        return organizationDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Organization> list(OrganizationCriteria criteria, PagerResults pager) {
        return organizationDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(OrganizationCriteria criteria) {
        return organizationDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Organization organization) {
        organizationDAO.save(organization);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        organizationDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setOrganizationDAO(OrganizationDAO organizationDAO) {
        this.organizationDAO = organizationDAO;
    }
}
