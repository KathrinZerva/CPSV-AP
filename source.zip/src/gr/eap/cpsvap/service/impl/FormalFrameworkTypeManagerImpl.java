package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.FormalFrameworkTypeDAO;
import gr.eap.cpsvap.entity.helper.FormalFrameworkType;
import gr.eap.cpsvap.service.FormalFrameworkTypeManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkTypeCriteria;
import java.util.List;

public class FormalFrameworkTypeManagerImpl implements FormalFrameworkTypeManager {
    //Patient dao injected by Spring context

    private FormalFrameworkTypeDAO formalFrameworkTypeDAO;


    @Override
    @Transactional
    public FormalFrameworkType get(Integer id) {
        return formalFrameworkTypeDAO.get(id);
    }

    @Override
    @Transactional
    public List<FormalFrameworkType> list(FormalFrameworkTypeCriteria criteria) {
        return formalFrameworkTypeDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<FormalFrameworkType> list(FormalFrameworkTypeCriteria criteria, PagerResults pager) {
        return formalFrameworkTypeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(FormalFrameworkTypeCriteria criteria) {
        return formalFrameworkTypeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(FormalFrameworkType FormalFrameworkType) {
        formalFrameworkTypeDAO.save(FormalFrameworkType);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        formalFrameworkTypeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setFormalFrameworkTypeDAO(FormalFrameworkTypeDAO formalFrameworkTypeDAO) {
        this.formalFrameworkTypeDAO = formalFrameworkTypeDAO;
    }

}
