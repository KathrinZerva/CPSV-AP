package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.BusinessEvent;
import gr.eap.cpsvap.vo.criteria.BusinessEventCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.BusinessEventDAO;
import gr.eap.cpsvap.service.BusinessEventManager;



public class BusinessEventManagerImpl implements BusinessEventManager {
    //BusinessEvent dao injected by Spring context

    private BusinessEventDAO businessEventDAO;

    @Override
    @Transactional
    public BusinessEvent get(Integer id) {
        return businessEventDAO.get(id);
    }
    @Override
    @Transactional
    public List<BusinessEvent> list(BusinessEventCriteria criteria) {
        return businessEventDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<BusinessEvent> list(BusinessEventCriteria criteria, PagerResults pager) {
        return businessEventDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(BusinessEventCriteria criteria) {
        return businessEventDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(BusinessEvent businessEvent) {
        businessEventDAO.save(businessEvent);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        businessEventDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setBusinessEventDAO(BusinessEventDAO businessEventDAO) {
        this.businessEventDAO = businessEventDAO;
    }
}
