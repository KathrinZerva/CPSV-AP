package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Output;
import gr.eap.cpsvap.vo.criteria.OutputCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.OutputDAO;
import gr.eap.cpsvap.service.OutputManager;



public class OutputManagerImpl implements OutputManager {
    //Output dao injected by Spring context

    private OutputDAO outputDAO;

    @Override
    @Transactional
    public Output get(Integer id) {
        return outputDAO.get(id);
    }
    @Override
    @Transactional
    public List<Output> list(OutputCriteria criteria) {
        return outputDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Output> list(OutputCriteria criteria, PagerResults pager) {
        return outputDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(OutputCriteria criteria) {
        return outputDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Output output) {
        outputDAO.save(output);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        outputDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setOutputDAO(OutputDAO outputDAO) {
        this.outputDAO = outputDAO;
    }
}
