package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicServiceStatus;
import gr.eap.cpsvap.vo.criteria.PublicServiceStatusCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.PublicServiceStatusDAO;
import gr.eap.cpsvap.service.PublicServiceStatusManager;



public class PublicServiceStatusManagerImpl implements PublicServiceStatusManager {
    //PublicServiceStatus dao injected by Spring context

    private PublicServiceStatusDAO publicServiceStatusDAO;

    @Override
    @Transactional
    public PublicServiceStatus get(Integer id) {
        return publicServiceStatusDAO.get(id);
    }
    @Override
    @Transactional
    public List<PublicServiceStatus> list(PublicServiceStatusCriteria criteria) {
        return publicServiceStatusDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<PublicServiceStatus> list(PublicServiceStatusCriteria criteria, PagerResults pager) {
        return publicServiceStatusDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PublicServiceStatusCriteria criteria) {
        return publicServiceStatusDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(PublicServiceStatus publicServiceStatus) {
        publicServiceStatusDAO.save(publicServiceStatus);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        publicServiceStatusDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPublicServiceStatusDAO(PublicServiceStatusDAO publicServiceStatusDAO) {
        this.publicServiceStatusDAO = publicServiceStatusDAO;
    }
}
