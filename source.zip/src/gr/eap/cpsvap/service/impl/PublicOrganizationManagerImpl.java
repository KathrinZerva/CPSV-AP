package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.vo.criteria.PublicOrganizationCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.PublicOrganizationDAO;
import gr.eap.cpsvap.entity.PublicOrganization;
import gr.eap.cpsvap.service.PublicOrganizationManager;



public class PublicOrganizationManagerImpl implements PublicOrganizationManager {
    //PublicOrganization dao injected by Spring context

    private PublicOrganizationDAO publicOrganizationDAO;

    @Override
    @Transactional
    public PublicOrganization get(Integer id) {
        return publicOrganizationDAO.get(id);
    }
    @Override
    @Transactional
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria) {
        return publicOrganizationDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<PublicOrganization> list(PublicOrganizationCriteria criteria, PagerResults pager) {
        return publicOrganizationDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PublicOrganizationCriteria criteria) {
        return publicOrganizationDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(PublicOrganization publicOrganization) {
        publicOrganizationDAO.save(publicOrganization);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        publicOrganizationDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPublicOrganizationDAO(PublicOrganizationDAO publicOrganizationDAO) {
        this.publicOrganizationDAO = publicOrganizationDAO;
    }
}
