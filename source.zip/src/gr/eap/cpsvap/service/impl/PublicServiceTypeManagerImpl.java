package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PublicServiceType;
import gr.eap.cpsvap.vo.criteria.PublicServiceTypeCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.PublicServiceTypeDAO;
import gr.eap.cpsvap.service.PublicServiceTypeManager;



public class PublicServiceTypeManagerImpl implements PublicServiceTypeManager {
    //PublicServiceType dao injected by Spring context

    private PublicServiceTypeDAO publicServiceTypeDAO;

    @Override
    @Transactional
    public PublicServiceType get(Integer id) {
        return publicServiceTypeDAO.get(id);
    }
    @Override
    @Transactional
    public List<PublicServiceType> list(PublicServiceTypeCriteria criteria) {
        return publicServiceTypeDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<PublicServiceType> list(PublicServiceTypeCriteria criteria, PagerResults pager) {
        return publicServiceTypeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PublicServiceTypeCriteria criteria) {
        return publicServiceTypeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(PublicServiceType publicServiceType) {
        publicServiceTypeDAO.save(publicServiceType);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        publicServiceTypeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPublicServiceTypeDAO(PublicServiceTypeDAO publicServiceTypeDAO) {
        this.publicServiceTypeDAO = publicServiceTypeDAO;
    }
}
