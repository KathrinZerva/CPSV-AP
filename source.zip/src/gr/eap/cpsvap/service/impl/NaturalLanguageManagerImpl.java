package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.NaturalLanguageDAO;
import gr.eap.cpsvap.entity.helper.NaturalLanguage;
import gr.eap.cpsvap.service.NaturalLanguageManager;
import gr.eap.cpsvap.vo.criteria.NaturalLanguageCriteria;
import java.util.List;

public class NaturalLanguageManagerImpl implements NaturalLanguageManager {
    //Patient dao injected by Spring context

    private NaturalLanguageDAO naturalLanguageDAO;


    @Override
    @Transactional
    public NaturalLanguage get(Integer id) {
        return naturalLanguageDAO.get(id);
    }

    @Override
    @Transactional
    public List<NaturalLanguage> list(NaturalLanguageCriteria criteria) {
        return naturalLanguageDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<NaturalLanguage> list(NaturalLanguageCriteria criteria, PagerResults pager) {
        return naturalLanguageDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(NaturalLanguageCriteria criteria) {
        return naturalLanguageDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(NaturalLanguage NaturalLanguage) {
        naturalLanguageDAO.save(NaturalLanguage);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        naturalLanguageDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setNaturalLanguageDAO(NaturalLanguageDAO naturalLanguageDAO) {
        this.naturalLanguageDAO = naturalLanguageDAO;
    }

}
