package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ChannelType;
import gr.eap.cpsvap.vo.criteria.ChannelTypeCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.ChannelTypeDAO;
import gr.eap.cpsvap.service.ChannelTypeManager;



public class ChannelTypeManagerImpl implements ChannelTypeManager {
    //ChannelType dao injected by Spring context

    private ChannelTypeDAO channelTypeDAO;

    @Override
    @Transactional
    public ChannelType get(Integer id) {
        return channelTypeDAO.get(id);
    }
    @Override
    @Transactional
    public List<ChannelType> list(ChannelTypeCriteria criteria) {
        return channelTypeDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<ChannelType> list(ChannelTypeCriteria criteria, PagerResults pager) {
        return channelTypeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ChannelTypeCriteria criteria) {
        return channelTypeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ChannelType channelType) {
        channelTypeDAO.save(channelType);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        channelTypeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setChannelTypeDAO(ChannelTypeDAO channelTypeDAO) {
        this.channelTypeDAO = channelTypeDAO;
    }
}
