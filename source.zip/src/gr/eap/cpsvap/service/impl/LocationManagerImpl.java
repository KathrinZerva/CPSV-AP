package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Location;
import gr.eap.cpsvap.vo.criteria.LocationCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.LocationDAO;
import gr.eap.cpsvap.service.LocationManager;



public class LocationManagerImpl implements LocationManager {
    //Location dao injected by Spring context

    private LocationDAO locationDAO;

    @Override
    @Transactional
    public Location get(Integer id) {
        return locationDAO.get(id);
    }
    @Override
    @Transactional
    public List<Location> list(LocationCriteria criteria) {
        return locationDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Location> list(LocationCriteria criteria, PagerResults pager) {
        return locationDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(LocationCriteria criteria) {
        return locationDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Location location) {
        locationDAO.save(location);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        locationDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setLocationDAO(LocationDAO locationDAO) {
        this.locationDAO = locationDAO;
    }
}
