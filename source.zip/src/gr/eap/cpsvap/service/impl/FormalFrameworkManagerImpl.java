package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.FormalFramework;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.service.FormalFrameworkManager;
import gr.eap.cpsvap.dao.FormalFrameworkDAO;
public class FormalFrameworkManagerImpl implements FormalFrameworkManager {
    //FormalFramework dao injected by Spring context

    private FormalFrameworkDAO formalFrameworkDAO;

    @Override
    @Transactional
    public FormalFramework get(Integer id) {
        return formalFrameworkDAO.get(id);
    }
    @Override
    @Transactional
    public List<FormalFramework> list(FormalFrameworkCriteria criteria) {
        return formalFrameworkDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<FormalFramework> list(FormalFrameworkCriteria criteria, PagerResults pager) {
        return formalFrameworkDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(FormalFrameworkCriteria criteria) {
        return formalFrameworkDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(FormalFramework formalFramework) {
        formalFrameworkDAO.save(formalFramework);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        formalFrameworkDAO.delete(id);
    }

    @Override
    @Transactional
    public FormalFramework merge(FormalFramework formalFramework) {
        return formalFrameworkDAO.merge(formalFramework);
    }    
    

    @Override
    @Transactional
    public void evict(FormalFramework formalFramework) {
        formalFrameworkDAO.evict(formalFramework);
    }    
    
    @Override
    @Transactional
    public void dumpHibernateSession() {
        formalFrameworkDAO.dumpHibernateSession();
    }     
    
    
    //This setter will be used by Spring context to inject the dao's instance
    public void setFormalFrameworkDAO(FormalFrameworkDAO formalFrameworkDAO) {
        this.formalFrameworkDAO = formalFrameworkDAO;
    }
}
