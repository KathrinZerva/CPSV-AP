package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ChangeEvent;
import gr.eap.cpsvap.vo.criteria.ChangeEventCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.ChangeEventDAO;
import gr.eap.cpsvap.service.ChangeEventManager;



public class ChangeEventManagerImpl implements ChangeEventManager {
    //ChangeEvent dao injected by Spring context

    private ChangeEventDAO changeEventDAO;

    @Override
    @Transactional
    public ChangeEvent get(Integer id) {
        return changeEventDAO.get(id);
    }
    @Override
    @Transactional
    public List<ChangeEvent> list(ChangeEventCriteria criteria) {
        return changeEventDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<ChangeEvent> list(ChangeEventCriteria criteria, PagerResults pager) {
        return changeEventDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ChangeEventCriteria criteria) {
        return changeEventDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ChangeEvent changeEvent) {
        changeEventDAO.save(changeEvent);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        changeEventDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setChangeEventDAO(ChangeEventDAO changeEventDAO) {
        this.changeEventDAO = changeEventDAO;
    }
}
