package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.PublicServiceDAO;
import gr.eap.cpsvap.entity.PublicService;
import gr.eap.cpsvap.service.PublicServiceManager;
import gr.eap.cpsvap.vo.criteria.PublicServiceCriteria;
import java.util.List;

public class PublicServiceManagerImpl implements PublicServiceManager {
    //Patient dao injected by Spring context

    private PublicServiceDAO publicServiceDAO;


    @Override
    @Transactional
    public PublicService get(Integer id) {
        return publicServiceDAO.get(id);
    }

    @Override
    @Transactional
    public List<PublicService> list(PublicServiceCriteria criteria) {
        return publicServiceDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<PublicService> list(PublicServiceCriteria criteria, PagerResults pager) {
        return publicServiceDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PublicServiceCriteria criteria) {
        return publicServiceDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(PublicService PublicService) {
        publicServiceDAO.save(PublicService);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        publicServiceDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPublicServiceDAO(PublicServiceDAO publicServiceDAO) {
        this.publicServiceDAO = publicServiceDAO;
    }

}
