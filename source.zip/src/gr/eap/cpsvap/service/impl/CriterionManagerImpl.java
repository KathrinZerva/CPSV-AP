package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Criterion;
import gr.eap.cpsvap.vo.criteria.CriterionCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.CriterionDAO;
import gr.eap.cpsvap.service.CriterionManager;



public class CriterionManagerImpl implements CriterionManager {
    //Criterion dao injected by Spring context

    private CriterionDAO criterionDAO;

    @Override
    @Transactional
    public Criterion get(Integer id) {
        return criterionDAO.get(id);
    }
    @Override
    @Transactional
    public List<Criterion> list(CriterionCriteria criteria) {
        return criterionDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Criterion> list(CriterionCriteria criteria, PagerResults pager) {
        return criterionDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(CriterionCriteria criteria) {
        return criterionDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Criterion criterion) {
        criterionDAO.save(criterion);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        criterionDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setCriterionDAO(CriterionDAO criterionDAO) {
        this.criterionDAO = criterionDAO;
    }
}
