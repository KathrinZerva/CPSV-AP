package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.vo.criteria.DocumentReferenceCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.DocumentReferenceDAO;
import gr.eap.cpsvap.entity.DocumentReference;
import gr.eap.cpsvap.service.DocumentReferenceManager;



public class DocumentReferenceManagerImpl implements DocumentReferenceManager {
    //DocumentReference dao injected by Spring context

    private DocumentReferenceDAO documentReferenceDAO;

    @Override
    @Transactional
    public DocumentReference get(Integer id) {
        return documentReferenceDAO.get(id);
    }
    @Override
    @Transactional
    public List<DocumentReference> list(DocumentReferenceCriteria criteria) {
        return documentReferenceDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<DocumentReference> list(DocumentReferenceCriteria criteria, PagerResults pager) {
        return documentReferenceDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(DocumentReferenceCriteria criteria) {
        return documentReferenceDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(DocumentReference documentReference) {
        documentReferenceDAO.save(documentReference);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        documentReferenceDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setDocumentReferenceDAO(DocumentReferenceDAO documentReferenceDAO) {
        this.documentReferenceDAO = documentReferenceDAO;
    }
}
