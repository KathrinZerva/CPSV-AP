package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Evidence;
import gr.eap.cpsvap.vo.criteria.EvidenceCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.service.EvidenceManager;
import gr.eap.cpsvap.dao.EvidenceDAO;
public class EvidenceManagerImpl implements EvidenceManager {
    //Evidence dao injected by Spring context

    private EvidenceDAO evidenceDAO;

    @Override
    @Transactional
    public Evidence get(Integer id) {
        return evidenceDAO.get(id);
    }
    @Override
    @Transactional
    public List<Evidence> list(EvidenceCriteria criteria) {
        return evidenceDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Evidence> list(EvidenceCriteria criteria, PagerResults pager) {
        return evidenceDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(EvidenceCriteria criteria) {
        return evidenceDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Evidence evidence) {
        evidenceDAO.save(evidence);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        evidenceDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setEvidenceDAO(EvidenceDAO evidenceDAO) {
        this.evidenceDAO = evidenceDAO;
    }
}
