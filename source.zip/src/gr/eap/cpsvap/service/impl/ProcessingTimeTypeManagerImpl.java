package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.ProcessingTimeTypeDAO;
import gr.eap.cpsvap.entity.helper.ProcessingTimeType;
import gr.eap.cpsvap.service.ProcessingTimeTypeManager;
import gr.eap.cpsvap.vo.criteria.ProcessingTimeTypeCriteria;
import java.util.List;

public class ProcessingTimeTypeManagerImpl implements ProcessingTimeTypeManager {
    //Patient dao injected by Spring context

    private ProcessingTimeTypeDAO processingTimeTypeDAO;


    @Override
    @Transactional
    public ProcessingTimeType get(Integer id) {
        return processingTimeTypeDAO.get(id);
    }

    @Override
    @Transactional
    public List<ProcessingTimeType> list(ProcessingTimeTypeCriteria criteria) {
        return processingTimeTypeDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<ProcessingTimeType> list(ProcessingTimeTypeCriteria criteria, PagerResults pager) {
        return processingTimeTypeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ProcessingTimeTypeCriteria criteria) {
        return processingTimeTypeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ProcessingTimeType ProcessingTimeType) {
        processingTimeTypeDAO.save(ProcessingTimeType);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        processingTimeTypeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setProcessingTimeTypeDAO(ProcessingTimeTypeDAO processingTimeTypeDAO) {
        this.processingTimeTypeDAO = processingTimeTypeDAO;
    }

}
