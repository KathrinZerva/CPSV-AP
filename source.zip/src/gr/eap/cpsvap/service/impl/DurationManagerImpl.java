package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Duration;
import gr.eap.cpsvap.vo.criteria.DurationCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.DurationDAO;
import gr.eap.cpsvap.service.DurationManager;



public class DurationManagerImpl implements DurationManager {
    //Duration dao injected by Spring context

    private DurationDAO durationDAO;

    @Override
    @Transactional
    public Duration get(Integer id) {
        return durationDAO.get(id);
    }
    @Override
    @Transactional
    public List<Duration> list(DurationCriteria criteria) {
        return durationDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Duration> list(DurationCriteria criteria, PagerResults pager) {
        return durationDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(DurationCriteria criteria) {
        return durationDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Duration duration) {
        durationDAO.save(duration);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        durationDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setDurationDAO(DurationDAO durationDAO) {
        this.durationDAO = durationDAO;
    }
}
