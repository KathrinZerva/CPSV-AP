package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Jurisdiction;
import gr.eap.cpsvap.vo.criteria.JurisdictionCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.JurisdictionDAO;
import gr.eap.cpsvap.service.JurisdictionManager;



public class JurisdictionManagerImpl implements JurisdictionManager {
    //Jurisdiction dao injected by Spring context

    private JurisdictionDAO jurisdictionDAO;

    @Override
    @Transactional
    public Jurisdiction get(Integer id) {
        return jurisdictionDAO.get(id);
    }
    @Override
    @Transactional
    public List<Jurisdiction> list(JurisdictionCriteria criteria) {
        return jurisdictionDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Jurisdiction> list(JurisdictionCriteria criteria, PagerResults pager) {
        return jurisdictionDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(JurisdictionCriteria criteria) {
        return jurisdictionDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Jurisdiction jurisdiction) {
        jurisdictionDAO.save(jurisdiction);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        jurisdictionDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setJurisdictionDAO(JurisdictionDAO jurisdictionDAO) {
        this.jurisdictionDAO = jurisdictionDAO;
    }
}
