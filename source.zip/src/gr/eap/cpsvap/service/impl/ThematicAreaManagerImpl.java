package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ThematicArea;
import gr.eap.cpsvap.vo.criteria.ThematicAreaCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.ThematicAreaDAO;
import gr.eap.cpsvap.service.ThematicAreaManager;



public class ThematicAreaManagerImpl implements ThematicAreaManager {
    //ThematicArea dao injected by Spring context

    private ThematicAreaDAO thematicAreaDAO;

    @Override
    @Transactional
    public ThematicArea get(Integer id) {
        return thematicAreaDAO.get(id);
    }
    @Override
    @Transactional
    public List<ThematicArea> list(ThematicAreaCriteria criteria) {
        return thematicAreaDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<ThematicArea> list(ThematicAreaCriteria criteria, PagerResults pager) {
        return thematicAreaDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ThematicAreaCriteria criteria) {
        return thematicAreaDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ThematicArea thematicArea) {
        thematicAreaDAO.save(thematicArea);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        thematicAreaDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setThematicAreaDAO(ThematicAreaDAO thematicAreaDAO) {
        this.thematicAreaDAO = thematicAreaDAO;
    }
}
