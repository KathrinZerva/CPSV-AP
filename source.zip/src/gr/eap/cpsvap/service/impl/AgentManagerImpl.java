package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Agent;
import gr.eap.cpsvap.vo.criteria.AgentCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.AgentDAO;
import gr.eap.cpsvap.service.AgentManager;



public class AgentManagerImpl implements AgentManager {
    //Agent dao injected by Spring context

    private AgentDAO agentDAO;

    @Override
    @Transactional
    public Agent get(Integer id) {
        return agentDAO.get(id);
    }
    @Override
    @Transactional
    public List<Agent> list(AgentCriteria criteria) {
        return agentDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Agent> list(AgentCriteria criteria, PagerResults pager) {
        return agentDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(AgentCriteria criteria) {
        return agentDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Agent agent) {
        agentDAO.save(agent);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        agentDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setAgentDAO(AgentDAO agentDAO) {
        this.agentDAO = agentDAO;
    }
}
