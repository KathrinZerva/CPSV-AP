package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Cost;
import gr.eap.cpsvap.vo.criteria.CostCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.CostDAO;
import gr.eap.cpsvap.service.CostManager;



public class CostManagerImpl implements CostManager {
    //Cost dao injected by Spring context

    private CostDAO costDAO;

    @Override
    @Transactional
    public Cost get(Integer id) {
        return costDAO.get(id);
    }
    @Override
    @Transactional
    public List<Cost> list(CostCriteria criteria) {
        return costDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Cost> list(CostCriteria criteria, PagerResults pager) {
        return costDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(CostCriteria criteria) {
        return costDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Cost cost) {
        costDAO.save(cost);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        costDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setCostDAO(CostDAO costDAO) {
        this.costDAO = costDAO;
    }
}
