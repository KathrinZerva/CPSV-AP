package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.LifeEvent;
import gr.eap.cpsvap.vo.criteria.LifeEventCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.LifeEventDAO;
import gr.eap.cpsvap.service.LifeEventManager;



public class LifeEventManagerImpl implements LifeEventManager {
    //LifeEvent dao injected by Spring context

    private LifeEventDAO lifeEventDAO;

    @Override
    @Transactional
    public LifeEvent get(Integer id) {
        return lifeEventDAO.get(id);
    }
    @Override
    @Transactional
    public List<LifeEvent> list(LifeEventCriteria criteria) {
        return lifeEventDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<LifeEvent> list(LifeEventCriteria criteria, PagerResults pager) {
        return lifeEventDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(LifeEventCriteria criteria) {
        return lifeEventDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(LifeEvent lifeEvent) {
        lifeEventDAO.save(lifeEvent);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        lifeEventDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setLifeEventDAO(LifeEventDAO lifeEventDAO) {
        this.lifeEventDAO = lifeEventDAO;
    }
}
