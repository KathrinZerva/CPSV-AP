package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.LegalEntity;
import gr.eap.cpsvap.vo.criteria.LegalEntityCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.LegalEntityDAO;
import gr.eap.cpsvap.service.LegalEntityManager;



public class LegalEntityManagerImpl implements LegalEntityManager {
    //LegalEntity dao injected by Spring context

    private LegalEntityDAO legalEntityDAO;

    @Override
    @Transactional
    public LegalEntity get(Integer id) {
        return legalEntityDAO.get(id);
    }
    @Override
    @Transactional
    public List<LegalEntity> list(LegalEntityCriteria criteria) {
        return legalEntityDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<LegalEntity> list(LegalEntityCriteria criteria, PagerResults pager) {
        return legalEntityDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(LegalEntityCriteria criteria) {
        return legalEntityDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(LegalEntity legalEntity) {
        legalEntityDAO.save(legalEntity);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        legalEntityDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setLegalEntityDAO(LegalEntityDAO legalEntityDAO) {
        this.legalEntityDAO = legalEntityDAO;
    }
}
