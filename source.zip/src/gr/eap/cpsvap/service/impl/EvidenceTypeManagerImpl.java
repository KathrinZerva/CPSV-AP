package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.EvidenceType;
import gr.eap.cpsvap.vo.criteria.EvidenceTypeCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.EvidenceTypeDAO;
import gr.eap.cpsvap.service.EvidenceTypeManager;



public class EvidenceTypeManagerImpl implements EvidenceTypeManager {
    //EvidenceType dao injected by Spring context

    private EvidenceTypeDAO evidenceTypeDAO;

    @Override
    @Transactional
    public EvidenceType get(Integer id) {
        return evidenceTypeDAO.get(id);
    }
    @Override
    @Transactional
    public List<EvidenceType> list(EvidenceTypeCriteria criteria) {
        return evidenceTypeDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<EvidenceType> list(EvidenceTypeCriteria criteria, PagerResults pager) {
        return evidenceTypeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(EvidenceTypeCriteria criteria) {
        return evidenceTypeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(EvidenceType evidenceType) {
        evidenceTypeDAO.save(evidenceType);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        evidenceTypeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setEvidenceTypeDAO(EvidenceTypeDAO evidenceTypeDAO) {
        this.evidenceTypeDAO = evidenceTypeDAO;
    }
}
