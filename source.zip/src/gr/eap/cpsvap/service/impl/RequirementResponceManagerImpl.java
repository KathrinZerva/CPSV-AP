package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.RequirementResponce;
import gr.eap.cpsvap.vo.criteria.RequirementResponceCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.RequirementResponceDAO;
import gr.eap.cpsvap.service.RequirementResponceManager;



public class RequirementResponceManagerImpl implements RequirementResponceManager {
    //RequirementResponce dao injected by Spring context

    private RequirementResponceDAO requirementResponceDAO;

    @Override
    @Transactional
    public RequirementResponce get(Integer id) {
        return requirementResponceDAO.get(id);
    }
    @Override
    @Transactional
    public List<RequirementResponce> list(RequirementResponceCriteria criteria) {
        return requirementResponceDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<RequirementResponce> list(RequirementResponceCriteria criteria, PagerResults pager) {
        return requirementResponceDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(RequirementResponceCriteria criteria) {
        return requirementResponceDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(RequirementResponce requirementResponce) {
        requirementResponceDAO.save(requirementResponce);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        requirementResponceDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setRequirementResponceDAO(RequirementResponceDAO requirementResponceDAO) {
        this.requirementResponceDAO = requirementResponceDAO;
    }
}
