package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Consept;
import gr.eap.cpsvap.vo.criteria.ConseptCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.service.ConseptManager;
import gr.eap.cpsvap.dao.ConseptDAO;
public class ConseptManagerImpl implements ConseptManager {
    //Consept dao injected by Spring context

    private ConseptDAO conseptDAO;

    @Override
    @Transactional
    public Consept get(Integer id) {
        return conseptDAO.get(id);
    }
    @Override
    @Transactional
    public List<Consept> list(ConseptCriteria criteria) {
        return conseptDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Consept> list(ConseptCriteria criteria, PagerResults pager) {
        return conseptDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ConseptCriteria criteria) {
        return conseptDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Consept consept) {
        conseptDAO.save(consept);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        conseptDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setConseptDAO(ConseptDAO conseptDAO) {
        this.conseptDAO = conseptDAO;
    }
}
