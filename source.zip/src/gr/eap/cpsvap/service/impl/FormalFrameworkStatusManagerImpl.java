package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.FormalFrameworkStatusDAO;
import gr.eap.cpsvap.entity.helper.FormalFrameworkStatus;
import gr.eap.cpsvap.service.FormalFrameworkStatusManager;
import gr.eap.cpsvap.vo.criteria.FormalFrameworkStatusCriteria;
import java.util.List;

public class FormalFrameworkStatusManagerImpl implements FormalFrameworkStatusManager {
    //Patient dao injected by Spring context

    private FormalFrameworkStatusDAO formalFrameworkStatusDAO;


    @Override
    @Transactional
    public FormalFrameworkStatus get(Integer id) {
        return formalFrameworkStatusDAO.get(id);
    }

    @Override
    @Transactional
    public List<FormalFrameworkStatus> list(FormalFrameworkStatusCriteria criteria) {
        return formalFrameworkStatusDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<FormalFrameworkStatus> list(FormalFrameworkStatusCriteria criteria, PagerResults pager) {
        return formalFrameworkStatusDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(FormalFrameworkStatusCriteria criteria) {
        return formalFrameworkStatusDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(FormalFrameworkStatus FormalFrameworkStatus) {
        formalFrameworkStatusDAO.save(FormalFrameworkStatus);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        formalFrameworkStatusDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setFormalFrameworkStatusDAO(FormalFrameworkStatusDAO formalFrameworkStatusDAO) {
        this.formalFrameworkStatusDAO = formalFrameworkStatusDAO;
    }

}
