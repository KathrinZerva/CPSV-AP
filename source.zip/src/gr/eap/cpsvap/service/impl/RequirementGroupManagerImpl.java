package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.RequirementGroup;
import gr.eap.cpsvap.vo.criteria.RequirementGroupCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.RequirementGroupDAO;
import gr.eap.cpsvap.service.RequirementGroupManager;



public class RequirementGroupManagerImpl implements RequirementGroupManager {
    //RequirementGroup dao injected by Spring context

    private RequirementGroupDAO requirementGroupDAO;

    @Override
    @Transactional
    public RequirementGroup get(Integer id) {
        return requirementGroupDAO.get(id);
    }
    @Override
    @Transactional
    public List<RequirementGroup> list(RequirementGroupCriteria criteria) {
        return requirementGroupDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<RequirementGroup> list(RequirementGroupCriteria criteria, PagerResults pager) {
        return requirementGroupDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(RequirementGroupCriteria criteria) {
        return requirementGroupDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(RequirementGroup requirementGroup) {
        requirementGroupDAO.save(requirementGroup);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        requirementGroupDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setRequirementGroupDAO(RequirementGroupDAO requirementGroupDAO) {
        this.requirementGroupDAO = requirementGroupDAO;
    }
}
