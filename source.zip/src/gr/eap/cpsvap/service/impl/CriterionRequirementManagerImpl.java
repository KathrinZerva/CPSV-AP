package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirement;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.CriterionRequirementDAO;
import gr.eap.cpsvap.service.CriterionRequirementManager;



public class CriterionRequirementManagerImpl implements CriterionRequirementManager {
    //CriterionRequirement dao injected by Spring context

    private CriterionRequirementDAO criterionRequirementDAO;

    @Override
    @Transactional
    public CriterionRequirement get(Integer id) {
        return criterionRequirementDAO.get(id);
    }
    @Override
    @Transactional
    public List<CriterionRequirement> list(CriterionRequirementCriteria criteria) {
        return criterionRequirementDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<CriterionRequirement> list(CriterionRequirementCriteria criteria, PagerResults pager) {
        return criterionRequirementDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(CriterionRequirementCriteria criteria) {
        return criterionRequirementDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(CriterionRequirement criterionRequirement) {
        criterionRequirementDAO.save(criterionRequirement);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        criterionRequirementDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setCriterionRequirementDAO(CriterionRequirementDAO criterionRequirementDAO) {
        this.criterionRequirementDAO = criterionRequirementDAO;
    }
}
