package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Participation;
import gr.eap.cpsvap.vo.criteria.ParticipationCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.ParticipationDAO;
import gr.eap.cpsvap.service.ParticipationManager;



public class ParticipationManagerImpl implements ParticipationManager {
    //Participation dao injected by Spring context

    private ParticipationDAO participationDAO;

    @Override
    @Transactional
    public Participation get(Integer id) {
        return participationDAO.get(id);
    }
    @Override
    @Transactional
    public List<Participation> list(ParticipationCriteria criteria) {
        return participationDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Participation> list(ParticipationCriteria criteria, PagerResults pager) {
        return participationDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ParticipationCriteria criteria) {
        return participationDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Participation participation) {
        participationDAO.save(participation);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        participationDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setParticipationDAO(ParticipationDAO participationDAO) {
        this.participationDAO = participationDAO;
    }
}
