package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.CriterionRequirementType;
import gr.eap.cpsvap.vo.criteria.CriterionRequirementTypeCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.CriterionRequirementTypeDAO;
import gr.eap.cpsvap.service.CriterionRequirementTypeManager;



public class CriterionRequirementTypeManagerImpl implements CriterionRequirementTypeManager {
    //CriterionRequirementType dao injected by Spring context

    private CriterionRequirementTypeDAO criterionRequirementTypeDAO;

    @Override
    @Transactional
    public CriterionRequirementType get(Integer id) {
        return criterionRequirementTypeDAO.get(id);
    }
    @Override
    @Transactional
    public List<CriterionRequirementType> list(CriterionRequirementTypeCriteria criteria) {
        return criterionRequirementTypeDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<CriterionRequirementType> list(CriterionRequirementTypeCriteria criteria, PagerResults pager) {
        return criterionRequirementTypeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(CriterionRequirementTypeCriteria criteria) {
        return criterionRequirementTypeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(CriterionRequirementType criterionRequirementType) {
        criterionRequirementTypeDAO.save(criterionRequirementType);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        criterionRequirementTypeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setCriterionRequirementTypeDAO(CriterionRequirementTypeDAO criterionRequirementTypeDAO) {
        this.criterionRequirementTypeDAO = criterionRequirementTypeDAO;
    }
}
