package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.ProcessingTimeUnitDAO;
import gr.eap.cpsvap.entity.helper.ProcessingTimeUnit;
import gr.eap.cpsvap.service.ProcessingTimeUnitManager;
import gr.eap.cpsvap.vo.criteria.ProcessingTimeUnitCriteria;
import java.util.List;

public class ProcessingTimeUnitManagerImpl implements ProcessingTimeUnitManager {
    //Patient dao injected by Spring context

    private ProcessingTimeUnitDAO processingTimeUnitDAO;


    @Override
    @Transactional
    public ProcessingTimeUnit get(Integer id) {
        return processingTimeUnitDAO.get(id);
    }

    @Override
    @Transactional
    public List<ProcessingTimeUnit> list(ProcessingTimeUnitCriteria criteria) {
        return processingTimeUnitDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<ProcessingTimeUnit> list(ProcessingTimeUnitCriteria criteria, PagerResults pager) {
        return processingTimeUnitDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ProcessingTimeUnitCriteria criteria) {
        return processingTimeUnitDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ProcessingTimeUnit ProcessingTimeUnit) {
        processingTimeUnitDAO.save(ProcessingTimeUnit);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        processingTimeUnitDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setProcessingTimeUnitDAO(ProcessingTimeUnitDAO processingTimeUnitDAO) {
        this.processingTimeUnitDAO = processingTimeUnitDAO;
    }

}
