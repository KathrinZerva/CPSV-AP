package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Rule;
import gr.eap.cpsvap.vo.criteria.RuleCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.RuleDAO;
import gr.eap.cpsvap.service.RuleManager;



public class RuleManagerImpl implements RuleManager {
    //Rule dao injected by Spring context

    private RuleDAO ruleDAO;

    @Override
    @Transactional
    public Rule get(Integer id) {
        return ruleDAO.get(id);
    }
    @Override
    @Transactional
    public List<Rule> list(RuleCriteria criteria) {
        return ruleDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Rule> list(RuleCriteria criteria, PagerResults pager) {
        return ruleDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(RuleCriteria criteria) {
        return ruleDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Rule rule) {
        ruleDAO.save(rule);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        ruleDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setRuleDAO(RuleDAO ruleDAO) {
        this.ruleDAO = ruleDAO;
    }
}
