package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Channel;
import gr.eap.cpsvap.vo.criteria.ChannelCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.ChannelDAO;
import gr.eap.cpsvap.service.ChannelManager;



public class ChannelManagerImpl implements ChannelManager {
    //Channel dao injected by Spring context

    private ChannelDAO channelDAO;

    @Override
    @Transactional
    public Channel get(Integer id) {
        return channelDAO.get(id);
    }
    @Override
    @Transactional
    public List<Channel> list(ChannelCriteria criteria) {
        return channelDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Channel> list(ChannelCriteria criteria, PagerResults pager) {
        return channelDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ChannelCriteria criteria) {
        return channelDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Channel channel) {
        channelDAO.save(channel);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        channelDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setChannelDAO(ChannelDAO channelDAO) {
        this.channelDAO = channelDAO;
    }
}
