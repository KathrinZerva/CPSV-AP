package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.UserDAO;
import gr.eap.cpsvap.entity.User;
import gr.eap.cpsvap.service.UserManager;
import gr.eap.cpsvap.vo.criteria.UserCriteria;
import java.util.List;

public class UserManagerImpl implements UserManager {
    //Patient dao injected by Spring context

    private UserDAO userDAO;

    //This method return User from database
    @Override
    @Transactional
    public User getUserByCredentials(String userId, String password) {
        return userDAO.getUserByCredentials(userId, password);
    }


    @Override
    @Transactional
    public User get(Integer id) {
        return userDAO.get(id);
    }

    @Override
    @Transactional
    public List<User> list(UserCriteria criteria) {
        return userDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<User> list(UserCriteria criteria, PagerResults pager) {
        return userDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(UserCriteria criteria) {
        return userDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(User User) {
        userDAO.save(User);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        userDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setUserDAO(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

}
