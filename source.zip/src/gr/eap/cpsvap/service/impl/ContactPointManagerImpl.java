package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.ContactPoint;
import gr.eap.cpsvap.vo.criteria.ContactPointCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.ContactPointDAO;
import gr.eap.cpsvap.service.ContactPointManager;



public class ContactPointManagerImpl implements ContactPointManager {
    //ContactPoint dao injected by Spring context

    private ContactPointDAO contactPointDAO;

    @Override
    @Transactional
    public ContactPoint get(Integer id) {
        return contactPointDAO.get(id);
    }
    @Override
    @Transactional
    public List<ContactPoint> list(ContactPointCriteria criteria) {
        return contactPointDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<ContactPoint> list(ContactPointCriteria criteria, PagerResults pager) {
        return contactPointDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ContactPointCriteria criteria) {
        return contactPointDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ContactPoint contactPoint) {
        contactPointDAO.save(contactPoint);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        contactPointDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setContactPointDAO(ContactPointDAO contactPointDAO) {
        this.contactPointDAO = contactPointDAO;
    }
}
