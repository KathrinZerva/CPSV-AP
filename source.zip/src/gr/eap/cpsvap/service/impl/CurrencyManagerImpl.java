package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.CurrencyDAO;
import gr.eap.cpsvap.entity.helper.Currency;
import gr.eap.cpsvap.service.CurrencyManager;
import gr.eap.cpsvap.vo.criteria.CurrencyCriteria;
import java.util.List;

public class CurrencyManagerImpl implements CurrencyManager {
    //Patient dao injected by Spring context

    private CurrencyDAO currencyDAO;


    @Override
    @Transactional
    public Currency get(Integer id) {
        return currencyDAO.get(id);
    }

    @Override
    @Transactional
    public List<Currency> list(CurrencyCriteria criteria) {
        return currencyDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<Currency> list(CurrencyCriteria criteria, PagerResults pager) {
        return currencyDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(CurrencyCriteria criteria) {
        return currencyDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Currency Currency) {
        currencyDAO.save(Currency);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        currencyDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setCurrencyDAO(CurrencyDAO currencyDAO) {
        this.currencyDAO = currencyDAO;
    }

}
