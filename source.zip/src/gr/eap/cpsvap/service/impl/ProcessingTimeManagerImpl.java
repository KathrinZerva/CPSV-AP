package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import org.springframework.transaction.annotation.Transactional;

import gr.eap.cpsvap.dao.ProcessingTimeDAO;
import gr.eap.cpsvap.entity.ProcessingTime;
import gr.eap.cpsvap.service.ProcessingTimeManager;
import gr.eap.cpsvap.vo.criteria.ProcessingTimeCriteria;
import java.util.List;

public class ProcessingTimeManagerImpl implements ProcessingTimeManager {
    //Patient dao injected by Spring context

    private ProcessingTimeDAO processingTimeDAO;


    @Override
    @Transactional
    public ProcessingTime get(Integer id) {
        return processingTimeDAO.get(id);
    }

    @Override
    @Transactional
    public List<ProcessingTime> list(ProcessingTimeCriteria criteria) {
        return processingTimeDAO.list(criteria);
    }

    @Override
    @Transactional
    public List<ProcessingTime> list(ProcessingTimeCriteria criteria, PagerResults pager) {
        return processingTimeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(ProcessingTimeCriteria criteria) {
        return processingTimeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(ProcessingTime ProcessingTime) {
        processingTimeDAO.save(ProcessingTime);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        processingTimeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setProcessingTimeDAO(ProcessingTimeDAO processingTimeDAO) {
        this.processingTimeDAO = processingTimeDAO;
    }

}
