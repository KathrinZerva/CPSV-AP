package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Sector;
import gr.eap.cpsvap.vo.criteria.SectorCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.SectorDAO;
import gr.eap.cpsvap.service.SectorManager;



public class SectorManagerImpl implements SectorManager {
    //Sector dao injected by Spring context

    private SectorDAO sectorDAO;

    @Override
    @Transactional
    public Sector get(Integer id) {
        return sectorDAO.get(id);
    }
    @Override
    @Transactional
    public List<Sector> list(SectorCriteria criteria) {
        return sectorDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Sector> list(SectorCriteria criteria, PagerResults pager) {
        return sectorDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(SectorCriteria criteria) {
        return sectorDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Sector sector) {
        sectorDAO.save(sector);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        sectorDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setSectorDAO(SectorDAO sectorDAO) {
        this.sectorDAO = sectorDAO;
    }
}
