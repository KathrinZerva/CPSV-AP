package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.PeriodOfTime;
import gr.eap.cpsvap.vo.criteria.PeriodOfTimeCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.PeriodOfTimeDAO;
import gr.eap.cpsvap.service.PeriodOfTimeManager;



public class PeriodOfTimeManagerImpl implements PeriodOfTimeManager {
    //PeriodOfTime dao injected by Spring context

    private PeriodOfTimeDAO periodOfTimeDAO;

    @Override
    @Transactional
    public PeriodOfTime get(Integer id) {
        return periodOfTimeDAO.get(id);
    }
    @Override
    @Transactional
    public List<PeriodOfTime> list(PeriodOfTimeCriteria criteria) {
        return periodOfTimeDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<PeriodOfTime> list(PeriodOfTimeCriteria criteria, PagerResults pager) {
        return periodOfTimeDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PeriodOfTimeCriteria criteria) {
        return periodOfTimeDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(PeriodOfTime periodOfTime) {
        periodOfTimeDAO.save(periodOfTime);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        periodOfTimeDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPeriodOfTimeDAO(PeriodOfTimeDAO periodOfTimeDAO) {
        this.periodOfTimeDAO = periodOfTimeDAO;
    }
}
