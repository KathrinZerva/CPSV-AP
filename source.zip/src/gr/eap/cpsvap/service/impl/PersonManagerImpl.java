package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Person;
import gr.eap.cpsvap.vo.criteria.PersonCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.PersonDAO;
import gr.eap.cpsvap.service.PersonManager;



public class PersonManagerImpl implements PersonManager {
    //Person dao injected by Spring context

    private PersonDAO personDAO;

    @Override
    @Transactional
    public Person get(Integer id) {
        return personDAO.get(id);
    }
    @Override
    @Transactional
    public List<Person> list(PersonCriteria criteria) {
        return personDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Person> list(PersonCriteria criteria, PagerResults pager) {
        return personDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(PersonCriteria criteria) {
        return personDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Person person) {
        personDAO.save(person);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        personDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setPersonDAO(PersonDAO personDAO) {
        this.personDAO = personDAO;
    }
}
