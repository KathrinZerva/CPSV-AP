package gr.eap.cpsvap.service.impl;

import gr.eap.cpsvap.common.PagerResults;
import gr.eap.cpsvap.entity.Event;
import gr.eap.cpsvap.vo.criteria.EventCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import gr.eap.cpsvap.dao.EventDAO;
import gr.eap.cpsvap.service.EventManager;



public class EventManagerImpl implements EventManager {
    //Event dao injected by Spring context

    private EventDAO eventDAO;

    @Override
    @Transactional
    public Event get(Integer id) {
        return eventDAO.get(id);
    }
    @Override
    @Transactional
    public List<Event> list(EventCriteria criteria) {
        return eventDAO.list(criteria);
    }
    
    @Override
    @Transactional
    public List<Event> list(EventCriteria criteria, PagerResults pager) {
        return eventDAO.list(criteria, pager);
    }

    @Override
    @Transactional
    public Long getTotalItems(EventCriteria criteria) {
        return eventDAO.getTotalItems(criteria);
    }

    @Override
    @Transactional
    public void save(Event event) {
        eventDAO.save(event);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        eventDAO.delete(id);
    }

    //This setter will be used by Spring context to inject the dao's instance
    public void setEventDAO(EventDAO eventDAO) {
        this.eventDAO = eventDAO;
    }
}
